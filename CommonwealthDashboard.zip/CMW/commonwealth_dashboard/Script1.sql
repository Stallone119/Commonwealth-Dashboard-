-- Create the database
CREATE DATABASE commonwealth_dashboard;
USE commonwealth_dashboard;

-- Countries table (metadata for Commonwealth countries)
CREATE TABLE countries (
    iso_code VARCHAR(3) PRIMARY KEY, -- ISO 3166-1 alpha-3 code
    name VARCHAR(100) NOT NULL, -- Country name
    region VARCHAR(50) NOT NULL, -- e.g., Africa, Asia, Caribbean
    is_sids BOOLEAN DEFAULT FALSE -- Indicates if the country is a Small Island Developing State
);

-- Users table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL, -- Hashed password
    role ENUM('System Admin', 'Thematic Admin', 'Program Manager', 'Field Officer', 'Data Analyst', 'Partner') NOT NULL,
    country VARCHAR(3) NOT NULL, -- ISO code or 'all'
    theme VARCHAR(20) NOT NULL, -- 'all', 'economic', 'sids', 'climate', 'youth', 'education', 'health'
    email VARCHAR(100) UNIQUE NOT NULL,
    phone VARCHAR(20) NOT NULL,
    mode ENUM('light', 'dark') DEFAULT 'light',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (country) REFERENCES countries(iso_code) ON DELETE RESTRICT
);

-- User activity table (tracks user actions and locations)
CREATE TABLE user_activity (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    activity TEXT NOT NULL, -- e.g., "Navigated to economic.php", "Uploaded document"
    latitude DECIMAL(9,6) NULL,
    longitude DECIMAL(9,6) NULL,
    ip_address VARCHAR(45) NULL, -- Supports IPv4 and IPv6
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Forum posts table
CREATE TABLE forum_posts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    dashboard VARCHAR(20) NOT NULL, -- 'all', 'economic', 'sids', 'climate', 'youth', 'education', 'health'
    country VARCHAR(3) NOT NULL, -- ISO code or 'all'
    content TEXT NOT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (country) REFERENCES countries(iso_code) ON DELETE RESTRICT
);

-- Projects table (for Gantt charts)
CREATE TABLE projects (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    dashboard VARCHAR(20) NOT NULL, -- Theme associated with the project
    project_name VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    country VARCHAR(3) NOT NULL, -- ISO code or 'all'
    status ENUM('Planned', 'In Progress', 'Completed', 'Delayed') DEFAULT 'Planned',
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (country) REFERENCES countries(iso_code) ON DELETE RESTRICT
);

-- KPI data table (for charts and KPIs)
CREATE TABLE kpi_data (
    id INT AUTO_INCREMENT PRIMARY KEY,
    dashboard VARCHAR(20) NOT NULL, -- 'economic', 'sids', 'climate', 'youth', 'education', 'health'
    metric VARCHAR(50) NOT NULL, -- e.g., 'poverty', 'emissions', 'literacy'
    country VARCHAR(3) NOT NULL, -- ISO code or 'all'
    year INT NOT NULL,
    value DECIMAL(10,2) NOT NULL,
    target DECIMAL(10,2) NOT NULL, -- Target value for the metric
    baseline DECIMAL(10,2) NOT NULL, -- Baseline value for the metric
    target_year INT NOT NULL, -- Year for target (e.g., 2030)
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (country) REFERENCES countries(iso_code) ON DELETE RESTRICT
);

-- Documents table (for uploaded files)
CREATE TABLE documents (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    dashboard VARCHAR(20) NOT NULL,
    data_type VARCHAR(50) NOT NULL, -- e.g., 'poverty', 'emissions'
    country VARCHAR(3) NOT NULL, -- ISO code or 'all'
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_size BIGINT NOT NULL, -- Size in bytes
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (country) REFERENCES countries(iso_code) ON DELETE RESTRICT
);

-- Notifications table (for alerts and system messages)
CREATE TABLE notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    dashboard VARCHAR(20) NOT NULL,
    message TEXT NOT NULL, -- e.g., "KPI below target", "New document uploaded"
    type ENUM('Alert', 'Info', 'Warning') NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Audit logs table (for tracking system changes)
CREATE TABLE audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    action VARCHAR(100) NOT NULL, -- e.g., "Updated user", "Deleted KPI data"
    entity_type VARCHAR(50) NOT NULL, -- e.g., 'users', 'kpi_data', 'documents'
    entity_id INT NOT NULL, -- ID of the affected entity
    details TEXT NOT NULL, -- JSON or text description of the change
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Insert sample data for countries (selected Commonwealth countries)
INSERT INTO countries (iso_code, name, region, is_sids) VALUES
('AUS', 'Australia', 'Pacific', FALSE),
('KEN', 'Kenya', 'Africa', FALSE),
('FJI', 'Fiji', 'Pacific', TRUE),
('IND', 'India', 'Asia', FALSE),
('JAM', 'Jamaica', 'Caribbean', TRUE),
('all', 'All Countries', 'Global', FALSE);

-- Insert sample users
INSERT INTO users (username, password, role, country, theme, email, phone, mode) VALUES
('admin', '$2y$10$examplehash', 'System Admin', 'all', 'all', 'admin@commonwealth.org', '+1234567890', 'light'),
('economic_admin', '$2y$10$examplehash', 'Thematic Admin', 'all', 'economic', 'econ@commonwealth.org', '+1234567891', 'light'),
('field_officer_ken', '$2y$10$examplehash', 'Field Officer', 'KEN', 'economic', 'field_ken@commonwealth.org', '+1234567892', 'dark'),
('climate_analyst', '$2y$10$examplehash', 'Data Analyst', 'FJI', 'climate', 'climate_fji@commonwealth.org', '+1234567893', 'light');

-- Insert sample projects
INSERT INTO projects (user_id, dashboard, project_name, start_date, end_date, country, status) VALUES
(1, 'economic', 'Poverty Reduction Initiative', '2025-01-01', '2025-12-31', 'all', 'In Progress'),
(1, 'sids', 'Coastal Adaptation Project', '2025-03-01', '2026-06-30', 'FJI', 'Planned'),
(1, 'climate', 'Renewable Energy Program', '2025-06-01', '2027-12-31', 'all', 'Planned'),
(1, 'youth', 'Youth Employment Scheme', '2025-02-01', '2026-12-31', 'KEN', 'In Progress'),
(1, 'education', 'STEM Education Program', '2025-04-01', '2026-03-31', 'IND', 'Planned'),
(1, 'health', 'Maternal Health Initiative', '2025-05-01', '2027-12-31', 'JAM', 'Planned');

-- Insert sample KPI data
INSERT INTO kpi_data (dashboard, metric, country, year, value, target, baseline, target_year) VALUES
('economic', 'poverty', 'all', 2025, 22.0, 30.0, 0.0, 2030),
('economic', 'exports', 'all', 2025, 7.5, 10.0, 0.0, 2029),
('economic', 'fdi', 'all', 2025, 38.0, 50.0, 0.0, 2028),
('sids', 'adaptation', 'FJI', 2025, 20.0, 50.0, 0.0, 2030),
('sids', 'mitigation', 'FJI', 2025, 40.0, 100.0, 0.0, 2030),
('sids', 'resilience', 'FJI', 2025, 60.0, 80.0, 0.0, 2030),
('climate', 'emissions', 'all', 2025, 20.0, 50.0, 0.0, 2030),
('climate', 'renewables', 'all', 2025, 25.0, 40.0, 0.0, 2030),
('climate', 'climateFinance', 'all', 2025, 90.0, 200.0, 0.0, 2030),
('youth', 'youthEmployment', 'KEN', 2025, 50.0, 70.0, 0.0, 2030),
('youth', 'enrollment', 'KEN', 2025, 70.0, 90.0, 0.0, 2030),
('youth', 'participation', 'KEN', 2025, 30.0, 50.0, 0.0, 2030),
('education', 'literacy', 'IND', 2025, 80.0, 95.0, 0.0, 2030),
('education', 'stem', 'IND', 2025, 40000.0, 100000.0, 0.0, 2030),
('education', 'digitalLearning', 'IND', 2025, 60.0, 80.0, 0.0, 2030),
('health', 'maternal', 'JAM', 2025, 20.0, 50.0, 0.0, 2030),
('health', 'vaccination', 'JAM', 2025, 70.0, 90.0, 0.0, 2030),
('health', 'healthcare', 'JAM', 2025, 65.0, 85.0, 0.0, 2030);

-- Insert sample forum posts
INSERT INTO forum_posts (user_id, dashboard, country, content) VALUES
(1, 'economic', 'all', 'Discussion on poverty reduction strategies for 2025.'),
(2, 'sids', 'FJI', 'New coastal adaptation project launched.'),
(3, 'climate', 'all', 'Renewable energy targets need urgent attention.');

-- Insert sample notifications
INSERT INTO notifications (user_id, dashboard, message, type) VALUES
(1, 'economic', 'Poverty KPI below 90% target', 'Alert'),
(2, 'sids', 'New document uploaded for Fiji', 'Info'),
(3, 'climate', 'Emissions reduction lagging', 'Warning');

-- Insert sample audit logs
INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details) VALUES
(1, 'Created user', 'users', 2, 'Created user economic_admin'),
(1, 'Updated KPI', 'kpi_data', 1, 'Updated poverty value to 22.0 for 2025'),
(1, 'Uploaded document', 'documents', 1, 'Uploaded poverty report for all countries');-- Write your own SQL object definition here, and it'll be included in your package.
