<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "governance_peace";

try {
    $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $post_content = $_POST['post_content'];
        $post_content = htmlspecialchars($post_content);
        $stmt = $conn->prepare("INSERT INTO forum_posts (content, created_at) VALUES (:content, NOW())");
        $stmt->bindParam(':content', $post_content);
        $stmt->execute();
        echo "Post submitted successfully!";
    }
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
?>