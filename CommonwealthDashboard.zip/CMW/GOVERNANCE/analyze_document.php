<?php
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['document'])) {
    $file = $_FILES['document'];
    $filename = basename($file['name']);
    $fileType = pathinfo($filename, PATHINFO_EXTENSION);
    $targetDir = "uploads/";
    $targetPath = $targetDir . $filename;

    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    if (in_array($fileType, ['docx', 'pdf', 'txt'])) {
        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            // Mock analysis logic
            $analysis = [
                'filename' => $filename,
                'governanceMentions' => rand(10, 50),
                'peaceMentions' => rand(5, 30),
                'sdgAlignment' => 'Goal 16: Peace, Justice and Strong Institutions'
            ];
            echo json_encode($analysis);
        } else {
            echo json_encode(['error' => 'Failed to upload file']);
        }
    } else {
        echo json_encode(['error' => 'Unsupported file type']);
    }
} else {
    echo json_encode(['error' => 'No file uploaded']);
}
?>