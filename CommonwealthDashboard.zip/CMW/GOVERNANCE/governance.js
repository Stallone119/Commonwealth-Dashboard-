// Commonwealth countries list
const commonwealthCountries = [
    "Antigua and Barbuda", "Australia", "Bahamas", "Bangladesh", "Barbados", "Belize", "Botswana", "Brunei",
    "Cameroon", "Canada", "Cyprus", "Dominica", "Eswatini", "Fiji", "Gabon", "Gambia", "Ghana", "Grenada",
    "Guyana", "India", "Jamaica", "Kenya", "Kiribati", "Lesotho", "Malawi", "Malaysia", "Maldives", "Malta",
    "Mauritius", "Mozambique", "Namibia", "Nauru", "New Zealand", "Nigeria", "Pakistan", "Papua New Guinea",
    "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "Seychelles",
    "Sierra Leone", "Singapore", "Solomon Islands", "South Africa", "Sri Lanka", "Tanzania", "Togo", "Tonga",
    "Trinidad and Tobago", "Tuvalu", "Uganda", "United Kingdom", "Vanuatu", "Zambia"
];

// Mock data for charts
const electoralData = {
    labels: ['2023', '2024', '2025', '2026', '2028'],
    datasets: [{
        label: 'Countries Supported',
        data: [2, 4, 6, 8, 10],
        backgroundColor: '#FFD700',
        borderColor: '#1E3A8A',
        borderWidth: 2
    }]
};

const conflictData = {
    labels: ['2023', '2024', '2025', '2026', '2029'],
    datasets: [{
        label: 'Conflict Reduction (%)',
        data: [2, 4, 6, 8, 10],
        backgroundColor: '#3B82F6',
        borderColor: '#1E3A8A',
        borderWidth: 2
    }]
};

const womenData = {
    labels: ['2023', '2024', '2025', '2026', '2028'],
    datasets: [{
        label: 'Women Participation (%)',
        data: [5, 10, 15, 18, 20],
        backgroundColor: '#F0F8FF',
        borderColor: '#1E3A8A',
        borderWidth: 2
    }]
};

// Initialize Line Charts
const ctx1 = document.getElementById('electoralChart').getContext('2d');
new Chart(ctx1, {
    type: 'line',
    data: electoralData,
    options: { responsive: true }
});

const ctx2 = document.getElementById('conflictChart').getContext('2d');
new Chart(ctx2, {
    type: 'line',
    data: conflictData,
    options: { responsive: true }
});

const ctx3 = document.getElementById('womenChart').getContext('2d');
new Chart(ctx3, {
    type: 'line',
    data: womenData,
    options: { responsive: true }
});

// KPI Calculations
function calculateKPI(data, target, baseline, targetYear, currentYear) {
    const progress = ((data[data.length - 1] - baseline) / (target - baseline)) * 100;
    const yearsLeft = targetYear - currentYear;
    const annualProgressNeeded = (target - data[data.length - 1]) / yearsLeft;
    return { progress: progress.toFixed(2), annualProgressNeeded: annualProgressNeeded.toFixed(2) };
}

// Mock KPI Data Fetching
function fetchKPI() {
    const country = document.getElementById('countryFilter').value;
    const kpiDashboard = document.getElementById('kpiDashboard');
    
    // Mock data (replace with Smartsheet/DHIS2 API)
    const mockData = {
        electoral: [2, 4, 6],
        conflict: [2, 4, 6],
        women: [5, 10, 15],
        reformTasks: 50,
        peaceMeetings: 20
    };

    const electoralKPI = calculateKPI(mockData.electoral, 10, 0, 2028, 2025);
    const conflictKPI = calculateKPI(mockData.conflict, 10, 0, 2029, 2025);
    const womenKPI = calculateKPI(mockData.women, 20, 0, 2028, 2025);

    kpiDashboard.innerHTML = `
        <p><strong>${country === 'all' ? 'All Countries' : country}</strong></p>
        <p>Electoral Reforms: ${mockData.electoral[mockData.electoral.length - 1]} countries 
           (Progress: ${electoralKPI.progress}% of target, ${electoralKPI.annualProgressNeeded} countries/year needed)</p>
        <p>Conflict Reduction: ${mockData.conflict[mockData.conflict.length - 1]}% 
           (Progress: ${conflictKPI.progress}% of target, ${conflictKPI.annualProgressNeeded}%/year needed)</p>
        <p>Women's Participation: ${mockData.women[mockData.women.length - 1]}% 
           (Progress: ${womenKPI.progress}% of target, ${womenKPI.annualProgressNeeded}%/year needed)</p>
        <p>Reform Tasks Completed: ${mockData.reformTasks} (Smartsheet)</p>
        <p>Peace Meetings Held: ${mockData.peaceMeetings} (DHIS2)</p>
    `;

    // Simulate ClearPoint Strategy alert for KPI deviations
    if (electoralKPI.progress < 90 || conflictKPI.progress < 90 || womenKPI.progress < 90) {
        alert('KPI Alert: One or more metrics are below target (ClearPoint Strategy)');
    }
}

// Gantt Chart for Implementation Roadmap
function drawGanttChart() {
    const ctxGantt = document.getElementById('ganttChart').getContext('2d');
    new Chart(ctxGantt, {
        type: 'gantt',
        data: {
            datasets: [{
                label: 'Implementation Roadmap',
                data: [
                    { x: '2025-01-01', x2: '2025-06-30', y: 'Core Platform', taskName: 'Core Platform' },
                    { x: '2025-07-01', x2: '2026-06-30', y: 'Module Development', taskName: 'Module Development' },
                    { x: '2026-07-01', x2: '2026-12-31', y: 'Pilot Testing', taskName: 'Pilot Testing' },
                    { x: '2027-01-01', x2: '2027-12-31', y: 'Full Deployment', taskName: 'Full Deployment' }
                ],
                backgroundColor: '#3B82F6',
                borderColor: '#1E3A8A',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    type: 'time',
                    time: { unit: 'month' }
                }
            }
        }
    });
}

// Pie Chart for KPI Distribution
function drawPieChart(type) {
    const ctxPie = document.getElementById('pieChart').getContext('2d');
    const data = type === 'electoral' ? {
        labels: ['Africa', 'Asia', 'Caribbean', 'Pacific'],
        datasets: [{
            data: [4, 3, 2, 1],
            backgroundColor: ['#FFD700', '#1E3A8A', '#3B82F6', '#F0F8FF']
        }]
    } : type === 'conflict' ? {
        labels: ['Africa', 'Asia', 'Caribbean', 'Pacific'],
        datasets: [{
            data: [5, 3, 1, 1],
            backgroundColor: ['#FFD700', '#1E3A8A', '#3B82F6', '#F0F8FF']
        }]
    } : {
        labels: ['Africa', 'Asia', 'Caribbean', 'Pacific'],
        datasets: [{
            data: [8, 5, 4, 3],
            backgroundColor: ['#FFD700', '#1E3A8A', '#3B82F6', '#F0F8FF']
        }]
    };

    new Chart(ctxPie, {
        type: 'pie',
        data: data,
        options: { responsive: true }
    });
}

// Heat Map for KPI Progress
function drawHeatMap() {
    const svg = d3.select('#heatMap').selectAll('*').remove();
    const svgElement = d3.select('#heatMap')
        .append('svg')
        .attr('width', 600)
        .attr('height', 400);

    const mockHeatMapData = commonwealthCountries.slice(0, 10).map(country => ({
        country,
        electoral: Math.random() * 10,
        conflict: Math.random() * 10,
        women: Math.random() * 20
    }));

    const xScale = d3.scaleBand()
        .domain(mockHeatMapData.map(d => d.country))
        .range([0, 600])
        .padding(0.05);

    const yScale = d3.scaleBand()
        .domain(['Electoral', 'Conflict', 'Women'])
        .range([0, 400])
        .padding(0.05);

    const colorScale = d3.scaleSequential(d3.interpolateBlues)
        .domain([0, 20]);

    svgElement.selectAll('rect')
        .data(mockHeatMapData.flatMap(d => [
            { country: d.country, metric: 'Electoral', value: d.electoral },
            { country: d.country, metric: 'Conflict', value: d.conflict },
            { country: d.country, metric: 'Women', value: d.women }
        ]))
        .enter()
        .append('rect')
        .attr('x', d => xScale(d.country))
        .attr('y', d => yScale(d.metric))
        .attr('width', xScale.bandwidth())
        .attr('height', yScale.bandwidth())
        .attr('fill', d => colorScale(d.value));

    svgElement.selectAll('text')
        .data(mockHeatMapData.flatMap(d => [
            { country: d.country, metric: 'Electoral', value: d.electoral },
            { country: d.country, metric: 'Conflict', value: d.conflict },
            { country: d.country, metric: 'Women', value: d.women }
        ]))
        .enter()
        .append('text')
        .attr('x', d => xScale(d.country) + xScale.bandwidth() / 2)
        .attr('y', d => yScale(d.metric) + yScale.bandwidth() / 2)
        .attr('text-anchor', 'middle')
        .attr('dy', '0.35em')
        .text(d => d.value.toFixed(1))
        .attr('fill', '#fff');
}

// Sankey Diagram
function drawSankeyDiagram(type) {
    d3.select('#sankeyDiagram').selectAll('*').remove();
    const svg = d3.select('#sankeyDiagram')
        .append('svg')
        .attr('width', 600)
        .attr('height', 400);

    const sankeyData = type === 'electoral' ? {
        nodes: [{ name: 'Reforms' }, { name: 'Implementation' }, { name: 'Elections' }],
        links: [{ source: 0, target: 1, value: 30 }, { source: 1, target: 2, value: 20 }]
    } : type === 'conflict' ? {
        nodes: [{ name: 'Conflicts' }, { name: 'Interventions' }, { name: 'Reduction' }],
        links: [{ source: 0, target: 1, value: 25 }, { source: 1, target: 2, value: 15 }]
    } : {
        nodes: [{ name: 'Women' }, { name: 'Training' }, { name: 'Peace Agreements' }],
        links: [{ source: 0, target: 1, value: 35 }, { source: 1, target: 2, value: 20 }]
    };

    const sankey = d3.sankey()
        .nodeWidth(15)
        .nodePadding(10)
        .extent([[1, 1], [600 - 1, 400 - 6]]);

    const { nodes, links } = sankey(sankeyData);

    svg.append('g')
        .selectAll('rect')
        .data(nodes)
        .enter()
        .append('rect')
        .attr('x', d => d.x0)
        .attr('y', d => d.y0)
        .attr('height', d => d.y1 - d.y0)
        .attr('width', d => d.x1 - d.x0)
        .attr('fill', '#3B82F6');

    svg.append('g')
        .selectAll('path')
        .data(links)
        .enter()
        .append('path')
        .attr('d', d3.sankeyLinkHorizontal())
        .attr('stroke', '#FFD700')
        .attr('stroke-width', d => Math.max(1, d.width))
        .attr('fill', 'none')
        .attr('opacity', 0.5);

    svg.append('g')
        .selectAll('text')
        .data(nodes)
        .enter()
        .append('text')
        .attr('x', d => d.x0 - 6)
        .attr('y', d => (d.y1 + d.y0) / 2)
        .attr('dy', '0.35em')
        .attr('text-anchor', 'end')
        .text(d => d.name)
        .attr('fill', '#1E3A8A');
}

// Report Generation
function generateReport(type) {
    const reportOutput = document.getElementById('reportOutput');
    const chartType = document.getElementById('chartType').value;
    
    document.getElementById('ganttChart').style.display = 'none';
    document.getElementById('pieChart').style.display = 'none';
    document.getElementById('heatMap').style.display = 'none';
    document.getElementById('sankeyDiagram').style.display = 'none';

    let reportContent = '';
    switch (type) {
        case 'electoral':
            reportContent = 'Electoral Reforms Report: 6 countries supported in 2025 (ClearPoint Strategy)';
            break;
        case 'conflict':
            reportContent = 'Conflict Reduction Report: 6% reduction achieved in 2025 (ClearPoint Strategy)';
            break;
        case 'women':
            reportContent = 'Women Participation Report: 15% participation in 2025 (ClearPoint Strategy)';
            break;
    }
    reportOutput.innerHTML = `<p>${reportContent}</p>`;

    if (chartType === 'gantt') {
        document.getElementById('ganttChart').style.display = 'block';
        drawGanttChart();
    } else if (chartType === 'pie') {
        document.getElementById('pieChart').style.display = 'block';
        drawPieChart(type);
    } else if (chartType === 'heatmap') {
        document.getElementById('heatMap').style.display = 'block';
        drawHeatMap();
    } else if (chartType === 'sankey') {
        document.getElementById('sankeyDiagram').style.display = 'block';
        drawSankeyDiagram(type);
    }
}

// Document Analysis
document.getElementById('documentUploadForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const fileInput = document.getElementById('documentInput');
    const file = fileInput.files[0];
    const documentAnalysis = document.getElementById('documentAnalysis');

    if (file) {
        const formData = new FormData();
        formData.append('document', file);

        fetch('analyze_document.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                documentAnalysis.innerHTML = `<p>Error: ${data.error}</p>`;
            } else {
                documentAnalysis.innerHTML = `
                    <p>Document Analysis (TolaData):</p>
                    <p>File: ${data.filename}</p>
                    <p>Governance Mentions: ${data.governanceMentions}</p>
                    <p>Peace Mentions: ${data.peaceMentions}</p>
                    <p>SDG Alignment: ${data.sdgAlignment}</p>
                `;
                drawPieChartWithDocumentData(data);
            }
        })
        .catch(error => {
            documentAnalysis.innerHTML = `<p>Error analyzing document: ${error.message}</p>`;
        });
    } else {
        documentAnalysis.innerHTML = '<p>Please select a file to analyze.</p>';
    }
});

// Pie Chart for Document Analysis
function drawPieChartWithDocumentData(data) {
    const ctxPie = document.getElementById('pieChart').getContext('2d');
    new Chart(ctxPie, {
        type: 'pie',
        data: {
            labels: ['Governance Mentions', 'Peace Mentions'],
            datasets: [{
                data: [data.governanceMentions, data.peaceMentions],
                backgroundColor: ['#FFD700', '#3B82F6']
            }]
        },
        options: { responsive: true }
    });
    document.getElementById('pieChart').style.display = 'block';
}

// Load Forum Posts
function loadForumPosts() {
    const forumPosts = document.getElementById('forumPosts');
    forumPosts.innerHTML = `
        <p>Post 1: Discussing electoral reform strategies (Miro)</p>
        <p>Post 2: Peace agreement collaboration ideas (Miro)</p>
    `;
}

document.getElementById('forumPostForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('submit_post.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        alert(data);
        loadForumPosts();
    });
});

window.onload = loadForumPosts;