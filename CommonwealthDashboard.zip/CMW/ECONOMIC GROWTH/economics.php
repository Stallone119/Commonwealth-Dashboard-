<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Economic Development, Trade and Investment Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/PapaParse/5.3.0/papaparse.min.js"></script>
</head>
<body>
    <div class="dashboard-container">
        <header class="dashboard-header">
            <div class="logo-container">
                <img src="icon.jpg" alt="Commonwealth Logo" class="logo">
                <h1>Economic Development, Trade and Investment</h1>
            </div>
            <nav class="main-nav">
                <ul>
                    <li><a href="#" class="active" data-section="overview"><i class="fas fa-home"></i> Overview</a></li>
                    <li><a href="#" data-section="trade-analytics"><i class="fas fa-chart-line"></i> Trade Analytics</a></li>
                    <li><a href="#" data-section="investment-matching"><i class="fas fa-handshake"></i> Investment Matching</a></li>
                    <li><a href="#" data-section="poverty-tracker"><i class="fas fa-users"></i> Poverty Tracker</a></li>
                    <li><a href="#" data-section="value-chains"><i class="fas fa-project-diagram"></i> Value Chains</a></li>
                    <li><a href="#" data-section="enterprise-portal"><i class="fas fa-building"></i> Enterprise Portal</a></li>
                </ul>
            </nav>
        </header>

        <main class="dashboard-main">
            <section id="overview" class="dashboard-section active">
                <div class="kpi-container">
                    <div class="kpi-card">
                        <h3>Extreme Poverty Reduction</h3>
                        <div class="kpi-value">25%</div>
                        <div class="kpi-target">Target: 30% by 2030</div>
                        <div class="kpi-progress">
                            <div class="progress-bar" style="width: 83%"></div>
                        </div>
                        <button class="btn-details" data-kpi="poverty">View Details</button>
                    </div>
                    
                    <div class="kpi-card">
                        <h3>LDC Exports Increase</h3>
                        <div class="kpi-value">7.5%</div>
                        <div class="kpi-target">Target: 10% by 2029</div>
                        <div class="kpi-progress">
                            <div class="progress-bar" style="width: 75%"></div>
                        </div>
                        <button class="btn-details" data-kpi="exports">View Details</button>
                    </div>
                    
                    <div class="kpi-card">
                        <h3>FDI Attraction</h3>
                        <div class="kpi-value">$38B</div>
                        <div class="kpi-target">Target: $50B by 2028</div>
                        <div class="kpi-progress">
                            <div class="progress-bar" style="width: 76%"></div>
                        </div>
                        <button class="btn-details" data-kpi="fdi">View Details</button>
                    </div>
                </div>

                <div class="chart-container">
                    <div class="chart-card">
                        <h3>Poverty Reduction vs Vocational Training</h3>
                        <canvas id="povertyTrainingChart"></canvas>
                    </div>
                    <div class="chart-card">
                        <h3>Export Volume vs Trade Barrier Removals</h3>
                        <canvas id="exportBarrierChart"></canvas>
                    </div>
                    <div class="chart-card">
                        <h3>FDI Pipeline by Stage</h3>
                        <div id="fdiPipelineChart"></div>
                    </div>
                    <div class="chart-card">
                        <h3>Value Chain Development Timeline</h3>
                        <div id="valueChainGantt"></div>
                    </div>
                </div>
            </section>

            <section id="trade-analytics" class="dashboard-section">
                <h2>Trade Analytics Platform</h2>
                <div class="tool-container">
                    <div class="tool-card">
                        <h3>Real-time Trade Barrier Monitoring</h3>
                        <div class="map-container" id="tradeBarrierMap"></div>
                        <div class="tool-actions">
                            <button class="btn-primary" id="refreshTradeData"><i class="fas fa-sync-alt"></i> Refresh Data</button>
                            <button class="btn-secondary" id="exportTradeData"><i class="fas fa-download"></i> Export</button>
                        </div>
                    </div>
                    <div class="tool-card">
                        <h3>Dynamic Tariff Calculator</h3>
                        <div class="form-group">
                            <label for="exportCountry">Exporting Country:</label>
                            <select id="exportCountry" class="form-control">
                                <?php foreach ($countries as $country): ?>
                                    <option value="<?= $country['code'] ?>"><?= $country['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="importCountry">Importing Country:</label>
                            <select id="importCountry" class="form-control">
                                <?php foreach ($countries as $country): ?>
                                    <option value="<?= $country['code'] ?>"><?= $country['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="productCode">Product Code (HS):</label>
                            <input type="text" id="productCode" class="form-control" placeholder="e.g. 0801.31">
                        </div>
                        <button class="btn-primary" id="calculateTariff">Calculate Tariff</button>
                        <div id="tariffResult" class="result-container"></div>
                    </div>
                </div>
                
                <div class="data-upload-container">
                    <h3>Upload Trade Data for Analysis</h3>
                    <form id="tradeDataUploadForm" enctype="multipart/form-data">
                        <div class="form-group">
                            <label for="tradeDataFile">Select File (CSV, Excel):</label>
                            <input type="file" id="tradeDataFile" name="tradeDataFile" accept=".csv,.xlsx,.xls" required>
                        </div>
                        <div class="form-group">
                            <label for="dataType">Data Type:</label>
                            <select id="dataType" name="dataType" class="form-control" required>
                                <option value="">Select data type</option>
                                <option value="export">Export Data</option>
                                <option value="import">Import Data</option>
                                <option value="tariff">Tariff Data</option>
                                <option value="barrier">Trade Barrier Data</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="countrySelect">Country:</label>
                            <select id="countrySelect" name="country" class="form-control" required>
                                <option value="">Select country</option>
                                <?php foreach ($countries as $country): ?>
                                    <option value="<?= $country['code'] ?>"><?= $country['name'] ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="submit" class="btn-primary"><i class="fas fa-upload"></i> Upload & Analyze</button>
                    </form>
                    <div id="uploadResult" class="result-container"></div>
                </div>
            </section>

            <section id="investment-matching" class="dashboard-section">
                <h2>Investment Matching System</h2>
                <div class="tool-container">
                    <div class="tool-card">
                        <h3>Investor Dashboard</h3>
                        <div class="filter-container">
                            <div class="form-group">
                                <label for="investmentRegion">Region:</label>
                                <select id="investmentRegion" class="form-control">
                                    <option value="">All Regions</option>
                                    <option value="africa">Africa</option>
                                    <option value="asia">Asia</option>
                                    <option value="americas">Americas</option>
                                    <option value="europe">Europe</option>
                                    <option value="pacific">Pacific</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="investmentSector">Sector:</label>
                                <select id="investmentSector" class="form-control">
                                    <option value="">All Sectors</option>
                                    <option value="agriculture">Agriculture</option>
                                    <option value="manufacturing">Manufacturing</option>
                                    <option value="infrastructure">Infrastructure</option>
                                    <option value="renewables">Renewable Energy</option>
                                    <option value="technology">Technology</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="investmentAmount">Investment Range ($M):</label>
                                <select id="investmentAmount" class="form-control">
                                    <option value="">Any Amount</option>
                                    <option value="1-10">1-10</option>
                                    <option value="10-50">10-50</option>
                                    <option value="50-100">50-100</option>
                                    <option value="100+">100+</option>
                                </select>
                            </div>
                            <button class="btn-primary" id="filterInvestments">Filter Projects</button>
                        </div>
                        <div class="project-list" id="investmentProjects">
                            <!-- Projects will be loaded here via AJAX -->
                        </div>
                    </div>
                    <div class="tool-card">
                        <h3>Investment Opportunity Heatmap</h3>
                        <div id="investmentHeatmap"></div>
                        <div class="legend-container">
                            <div class="legend-item"><span class="legend-color high"></span> High Potential</div>
                            <div class="legend-item"><span class="legend-color medium"></span> Medium Potential</div>
                            <div class="legend-item"><span class="legend-color low"></span> Low Potential</div>
                        </div>
                    </div>
                </div>
                
                <div class="data-upload-container">
                    <h3>Submit Investment Opportunity</h3>
                    <form id="investmentSubmissionForm">
                        <div class="form-row">
                            <div class="form-group">
                                <label for="projectName">Project Name:</label>
                                <input type="text" id="projectName" class="form-control" required>
                            </div>
                            <div class="form-group">
                                <label for="projectCountry">Country:</label>
                                <select id="projectCountry" class="form-control" required>
                                    <option value="">Select country</option>
                                    <?php foreach ($countries as $country): ?>
                                        <option value="<?= $country['code'] ?>"><?= $country['name'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group">
                                <label for="projectSector">Sector:</label>
                                <select id="projectSector" class="form-control" required>
                                    <option value="">Select sector</option>
                                    <option value="agriculture">Agriculture</option>
                                    <option value="manufacturing">Manufacturing</option>
                                    <option value="infrastructure">Infrastructure</option>
                                    <option value="renewables">Renewable Energy</option>
                                    <option value="technology">Technology</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="projectAmount">Required Investment ($M):</label>
                                <input type="number" id="projectAmount" class="form-control" min="0.1" step="0.1" required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="projectDescription">Project Description:</label>
                            <textarea id="projectDescription" class="form-control" rows="4" required></textarea>
                        </div>
                        <div class="form-group">
                            <label for="projectDocuments">Supporting Documents:</label>
                            <input type="file" id="projectDocuments" name="projectDocuments[]" multiple>
                        </div>
                        <button type="submit" class="btn-primary">Submit for Matching</button>
                    </form>
                </div>
            </section>

            <!-- Additional sections for Poverty Tracker, Value Chains, and Enterprise Portal would follow similar patterns -->
            
        </main>

        <footer class="dashboard-footer">
            <div class="footer-content">
                <div class="footer-section">
                    <h4>Integrated Tools</h4>
                    <ul>
                        <li><i class="fab fa-microsoft"></i> Microsoft Project</li>
                        <li><i class="fab fa-asana"></i> Asana</li>
                        <li><i class="fab fa-salesforce"></i> Salesforce Nonprofit Cloud</li>
                        <li><i class="fas fa-chart-bar"></i> Power BI</li>
                        <li><i class="fas fa-clock"></i> Clockify</li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="#">Documentation</a></li>
                        <li><a href="#">Training Materials</a></li>
                        <li><a href="#">API Documentation</a></li>
                        <li><a href="#">Support</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h4>Contact</h4>
                    <p>Commonwealth Secretariat</p>
                    <p>Economic Development Division</p>
                    <p>Email: econdev@commonwealth.int</p>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; <?= date('Y') ?> Commonwealth Secretariat. All rights reserved.</p>
            </div>
        </footer>
    </div>

    <script src="script.js"></script>
    <script>
        // Initialize dashboard with sample data
        document.addEventListener('DOMContentLoaded', function() {
            initDashboard();
            loadCommonwealthCountries();
            setupEventListeners();
        });
    </script>
</body>
</html>