<?php
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['document']) && isset($_POST['dataType']) && isset($_POST['country'])) {
    $file = $_FILES['document'];
    $dataType = $_POST['dataType'];
    $country = $_POST['country'];
    $fileType = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));

    if (!in_array($fileType, ['csv', 'xlsx', 'xls'])) {
        echo json_encode(['error' => 'Only CSV, XLSX, XLS allowed']);
        exit;
    }

    $targetDir = "uploads/";
    if (!is_dir($targetDir)) mkdir($targetDir, 0777, true);
    $targetFile = $targetDir . basename($file['name']);

    if (move_uploaded_file($file['tmp_name'], $targetFile)) {
        echo json_encode([
            'file' => $file['name'],
            'type' => $dataType,
            'country' => $country,
            'poverty' => rand(10, 50),
            'exports' => rand(5, 30),
            'fdi' => rand(5, 20)
        ]);
    } else {
        echo json_encode(['error' => 'Upload failed']);
    }
} else {
    echo json_encode(['error' => 'Missing file, type, or country']);
}
?>