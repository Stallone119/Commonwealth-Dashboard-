<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$host = 'localhost';
$username = 'root';
$password = ''; // Empty for XAMPP default
$database = 'commonwealth_dashboard';

$conn = new mysqli($host, $username, $password, $database="commonwealth_dashboard");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>