<?php
// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'commonwealth_econ_dev');

// Create database connection
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Function to sanitize input data
function sanitizeInput($data) {
    global $conn;
    return htmlspecialchars(strip_tags($conn->real_escape_string($data)));
}

// Function to handle file uploads
function handleFileUpload($file, $uploadDir = 'uploads/') {
    $targetFile = $uploadDir . basename($file['name']);
    $fileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));
    
    // Check if file already exists
    if (file_exists($targetFile)) {
        return ['success' => false, 'message' => 'File already exists.'];
    }
    
    // Check file size (5MB max)
    if ($file['size'] > 5000000) {
        return ['success' => false, 'message' => 'File is too large.'];
    }
    
    // Allow certain file formats
    $allowedTypes = ['csv', 'xlsx', 'xls'];
    if (!in_array($fileType, $allowedTypes)) {
        return ['success' => false, 'message' => 'Only CSV, XLSX, XLS files are allowed.'];
    }
    
    // Try to upload file
    if (move_uploaded_file($file['tmp_name'], $targetFile)) {
        return ['success' => true, 'file_path' => $targetFile];
    } else {
        return ['success' => false, 'message' => 'Error uploading file.'];
    }
}

// Function to process trade data file
function processTradeDataFile($filePath, $dataType, $country) {
    // This function would parse the file and insert data into the database
    // For now, we'll just return a success message with file info
    
    return [
        'success' => true,
        'data_type' => $dataType,
        'country' => $country,
        'file_name' => basename($filePath),
        'records_processed' => rand(50, 500) // Simulate processing some records
    ];
}
?>