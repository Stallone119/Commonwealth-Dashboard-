<?php
require_once 'db.php';

// Function to get Commonwealth countries
function getCommonwealthCountries() {
    global $conn;
    
    $countries = [];
    $query = "SELECT * FROM countries ORDER BY name";
    $result = $conn->query($query);
    
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $countries[] = $row;
        }
    }
    
    return $countries;
}

// Function to get KPI data
function getKPIData($kpi) {
    global $conn;
    
    $query = "SELECT * FROM kpis WHERE kpi_type = ? ORDER BY year";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("s", $kpi);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $data = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    
    return $data;
}

// Function to get trade data
function getTradeData($country, $type) {
    global $conn;
    
    $query = "SELECT * FROM trade_data WHERE country_code = ? AND data_type = ? ORDER BY year";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $country, $type);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $data = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $data[] = $row;
        }
    }
    
    return $data;
}

// Function to get investment projects
function getInvestmentProjects($filters = []) {
    global $conn;
    
    $query = "SELECT * FROM investment_projects WHERE 1=1";
    $types = "";
    $params = [];
    
    if (!empty($filters['region'])) {
        $query .= " AND region = ?";
        $types .= "s";
        $params[] = $filters['region'];
    }
    
    if (!empty($filters['sector'])) {
        $query .= " AND sector = ?";
        $types .= "s";
        $params[] = $filters['sector'];
    }
    
    if (!empty($filters['amount'])) {
        $amountRange = explode("-", $filters['amount']);
        if (count($amountRange) === 2) {
            $query .= " AND amount BETWEEN ? AND ?";
            $types .= "dd";
            $params[] = $amountRange[0];
            $params[] = $amountRange[1];
        }
    }
    
    $query .= " ORDER BY potential DESC";
    $stmt = $conn->prepare($query);
    
    if (!empty($types)) {
        $stmt->bind_param($types, ...$params);
    }
    
    $stmt->execute();
    $result = $stmt->get_result();
    
    $projects = [];
    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $projects[] = $row;
        }
    }
    
    return $projects;
}

// Function to submit investment project
function submitInvestmentProject($projectData) {
    global $conn;
    
    $query = "INSERT INTO investment_projects (name, country_code, region, sector, amount, description, potential) 
              VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    
    // Calculate potential based on sector and country (simplified)
    $potential = calculateInvestmentPotential($projectData['country_code'], $projectData['sector']);
    
    $stmt->bind_param("ssssdsi", 
        $projectData['name'],
        $projectData['country_code'],
        $projectData['region'],
        $projectData['sector'],
        $projectData['amount'],
        $projectData['description'],
        $potential
    );
    
    return $stmt->execute();
}

// Helper function to calculate investment potential
function calculateInvestmentPotential($countryCode, $sector) {
    // This is a simplified calculation - in reality this would use more complex logic
    $countryFactors = [
        'KEN' => 0.8,
        'GHA' => 0.7,
        'JAM' => 0.75,
        'FJI' => 0.65,
        'BGD' => 0.6,
        'default' => 0.5
    ];
    
    $sectorFactors = [
        'renewables' => 0.9,
        'technology' => 0.85,
        'agriculture' => 0.7,
        'infrastructure' => 0.75,
        'manufacturing' => 0.65,
        'default' => 0.6
    ];
    
    $countryFactor = $countryFactors[$countryCode] ?? $countryFactors['default'];
    $sectorFactor = $sectorFactors[$sector] ?? $sectorFactors['default'];
    
    return (int) (($countryFactor + $sectorFactor) / 2 * 100);
}
?>