<?php
$conn = new PDO("mysql:host=localhost;dbname=econ_dev", "root", "");
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $post = htmlspecialchars($_POST['post']);
    $stmt = $conn->prepare("INSERT INTO forum_posts (content, created_at) VALUES (:content, NOW())");
    $stmt->bindParam(':content', $post);
    $stmt->execute();
    echo "Post submitted!";
} else {
    echo "Error: Invalid request";
}
$conn = null;
?>