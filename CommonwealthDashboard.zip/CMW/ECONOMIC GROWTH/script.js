// Sample Commonwealth Countries (Replace with actual data source)
const commonwealthCountries = [
    { code: 'UK', name: 'United Kingdom' },
    { code: 'CA', name: 'Canada' },
    { code: 'AU', name: 'Australia' },
    { code: 'IN', name: 'India' },
    { code: 'ZA', name: 'South Africa' },
    // Add more Commonwealth countries as needed
];

// Initialize Dashboard
function initDashboard() {
    initCharts();
    loadCommonwealthCountries();
    setupEventListeners();
    initAdditionalSections();
}

// Initialize Charts
function initCharts() {
    initPovertyTrainingChart();
    initExportBarrierChart();
    initFdiPipelineChart();
    initValueChainGantt();
    initTradeBarrierMap();
    initInvestmentHeatmap();
}

function initPovertyTrainingChart() {
    const ctx = document.getElementById('povertyTrainingChart')?.getContext('2d');
    if (!ctx) return console.error('Poverty Training Chart canvas not found');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['2018', '2019', '2020', '2021', '2022', '2023', '2024'],
            datasets: [
                {
                    label: 'Poverty Reduction (%)',
                    data: [30, 28, 27, 26, 25, 24, 23],
                    borderColor: '#003087',
                    backgroundColor: 'rgba(0, 48, 135, 0.2)',
                    fill: true,
                },
                {
                    label: 'Vocational Training (Thousands)',
                    data: [50, 60, 65, 70, 80, 85, 90],
                    borderColor: '#FFD700',
                    backgroundColor: 'rgba(255, 215, 0, 0.2)',
                    fill: true,
                },
            ],
        },
        options: {
            responsive: true,
            scales: { y: { beginAtZero: true } },
        },
    });
}

function initExportBarrierChart() {
    const ctx = document.getElementById('exportBarrierChart')?.getContext('2d');
    if (!ctx) return console.error('Export Barrier Chart canvas not found');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['2018', '2019', '2020', '2021', '2022', '2023', '2024'],
            datasets: [
                {
                    label: 'Export Volume ($B)',
                    data: [100, 110, 105, 115, 120, 130, 140],
                    backgroundColor: '#003087',
                },
                {
                    label: 'Trade Barriers Removed',
                    data: [5, 8, 10, 12, 15, 18, 20],
                    backgroundColor: '#FFD700',
                },
            ],
        },
        options: {
            responsive: true,
            scales: { y: { beginAtZero: true } },
        },
    });
}

function initFdiPipelineChart() {
    const chartElement = document.querySelector('#fdiPipelineChart');
    if (!chartElement) return console.error('FDI Pipeline Chart element not found');
    const options = {
        series: [{ name: 'FDI ($B)', data: [10, 15, 20, 25, 30] }],
        chart: { type: 'bar', height: 300 },
        colors: ['#003087'],
        xaxis: { categories: ['Prospect', 'Negotiation', 'Agreement', 'Implementation', 'Completed'] },
        dataLabels: { enabled: false },
    };
    new ApexCharts(chartElement, options).render();
}

function initValueChainGantt() {
    const chartElement = document.querySelector('#valueChainGantt');
    if (!chartElement) return console.error('Value Chain Gantt element not found');
    const options = {
        series: [
            {
                name: 'Value Chain Development',
                data: [
                    { x: 'Planning', y: [new Date('2023-01-01').getTime(), 0, new Date('2023-06-01').getTime()] },
                    { x: 'Implementation', y: [new Date('2023-06-01').getTime(), 0, new Date('2024-01-01').getTime()] },
                    { x: 'Scaling', y: [new Date('2024-01-01').getTime(), 0, new Date('2024-12-01').getTime()] },
                ],
            },
        ],
        chart: { type: 'rangeBar', height: 300 },
        plotOptions: { bar: { horizontal: true } },
        colors: ['#FFD700'],
        xaxis: { type: 'datetime' },
        dataLabels: { enabled: false },
    };
    new ApexCharts(chartElement, options).render();
}

function initTradeBarrierMap() {
    const mapContainer = document.getElementById('tradeBarrierMap');
    if (!mapContainer) return console.error('Trade Barrier Map element not found');
    mapContainer.innerHTML = '<p>Interactive Trade Barrier Map (Use Leaflet/Google Maps API)</p>';
}

function initInvestmentHeatmap() {
    const chartElement = document.querySelector('#investmentHeatmap');
    if (!chartElement) return console.error('Investment Heatmap element not found');
    const options = {
        series: [
            {
                name: 'Investment Potential',
                data: [
                    { x: 'Africa', y: 80 },
                    { x: 'Asia', y: 60 },
                    { x: 'Americas', y: 50 },
                    { x: 'Europe', y: 30 },
                    { x: 'Pacific', y: 20 },
                ],
            },
        ],
        chart: { type: 'heatmap', height: 300 },
        colors: ['#FFD700', '#005B9A', '#F5F6F5'],
        dataLabels: { enabled: false },
    };
    new ApexCharts(chartElement, options).render();
}

// Initialize Additional Sections (Poverty Tracker, Value Chains, Enterprise Portal)
function initAdditionalSections() {
    // Poverty Tracker (Placeholder)
    const povertyTrackerSection = document.getElementById('poverty-tracker');
    if (povertyTrackerSection) {
        povertyTrackerSection.innerHTML = `
            <h2>Poverty Tracker Platform</h2>
            <div class="tool-container">
                <div class="tool-card">
                    <h3>Poverty Metrics Dashboard</h3>
                    <div id="povertyMetricsChart" style="height: 300px;"></div>
                </div>
                <div class="tool-card">
                    <h3>Data Upload for Poverty Analysis</h3>
                    <form id="povertyDataUploadForm">
                        <div class="form-group">
                            <label for="povertyDataFile">Select File (CSV):</label>
                            <input type="file" id="povertyDataFile" accept=".csv" required>
                        </div>
                        <button type="submit" class="btn-primary"><i class="fas fa-upload"></i> Upload</button>
                    </form>
                    <div id="povertyUploadResult" class="result-container"></div>
                </div>
            </div>
        `;
        initPovertyMetricsChart();
    }

    // Value Chains (Placeholder)
    const valueChainsSection = document.getElementById('value-chains');
    if (valueChainsSection) {
        valueChainsSection.innerHTML = `
            <h2>Value Chains Analysis</h2>
            <div class="tool-container">
                <div class="tool-card">
                    <h3>Supply Chain Network</h3>
                    <div id="supplyChainNetwork" style="height: 300px;"></div>
                </div>
                <div class="tool-card">
                    <h3>Analyze Value Chain Data</h3>
                    <form id="valueChainForm">
                        <div class="form-group">
                            <label for="chainSector">Sector:</label>
                            <select id="chainSector" class="form-control">
                                <option value="">Select sector</option>
                                <option value="agriculture">Agriculture</option>
                                <option value="manufacturing">Manufacturing</option>
                            </select>
                        </div>
                        <button type="submit" class="btn-primary">Analyze</button>
                    </form>
                    <div id="valueChainResult" class="result-container"></div>
                </div>
            </div>
        `;
        initSupplyChainNetwork();
    }

    // Enterprise Portal (Placeholder)
    const enterprisePortalSection = document.getElementById('enterprise-portal');
    if (enterprisePortalSection) {
        enterprisePortalSection.innerHTML = `
            <h2>Enterprise Portal</h2>
            <div class="tool-container">
                <div class="tool-card">
                    <h3>Enterprise Directory</h3>
                    <div id="enterpriseList"></div>
                    <button class="btn-primary" id="loadEnterprises">Load Enterprises</button>
                </div>
                <div class="tool-card">
                    <h3>Register New Enterprise</h3>
                    <form id="enterpriseRegisterForm">
                        <div class="form-group">
                            <label for="enterpriseName">Enterprise Name:</label>
                            <input type="text" id="enterpriseName" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <label for="enterpriseCountry">Country:</label>
                            <select id="enterpriseCountry" class="form-control"></select>
                        </div>
                        <button type="submit" class="btn-primary">Register</button>
                    </form>
                    <div id="enterpriseRegisterResult" class="result-container"></div>
                </div>
            </div>
        `;
        loadCommonwealthCountries('enterpriseCountry');
        initEnterpriseList();
    }
}

function initPovertyMetricsChart() {
    const chartElement = document.querySelector('#povertyMetricsChart');
    if (!chartElement) return console.error('Poverty Metrics Chart element not found');
    const options = {
        series: [{ name: 'Poverty Rate (%)', data: [15, 14, 13, 12, 11] }],
        chart: { type: 'line', height: 300 },
        colors: ['#003087'],
        xaxis: { categories: ['2020', '2021', '2022', '2023', '2024'] },
        dataLabels: { enabled: false },
    };
    new ApexCharts(chartElement, options).render();
}

function initSupplyChainNetwork() {
    const chartElement = document.querySelector('#supplyChainNetwork');
    if (!chartElement) return console.error('Supply Chain Network element not found');
    chartElement.innerHTML = '<p>Supply Chain Network Visualization (Use D3.js or similar)</p>';
}

function initEnterpriseList() {
    const enterpriseList = document.getElementById('enterpriseList');
    if (!enterpriseList) return console.error('Enterprise List element not found');
    enterpriseList.innerHTML = '<p>Enterprise Directory Placeholder</p>';
}

// Load Commonwealth Countries
function loadCommonwealthCountries(selectId = null) {
    const selects = selectId
        ? [document.getElementById(selectId)]
        : document.querySelectorAll('select[id$="Country"], #countrySelect, #enterpriseCountry');
    selects.forEach(select => {
        if (select) {
            select.innerHTML = '<option value="">Select country</option>' +
                commonwealthCountries.map(country => `<option value="${country.code}">${country.name}</option>`).join('');
        }
    });
}

// Event Listeners
function setupEventListeners() {
    // Navigation
    document.querySelectorAll('.main-nav a').forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            document.querySelectorAll('.main-nav a').forEach(l => l.classList.remove('active'));
            link.classList.add('active');
            document.querySelectorAll('.dashboard-section').forEach(section => section.classList.remove('active'));
            const section = document.getElementById(link.dataset.section);
            if (section) section.classList.add('active');
        });
    });

    // KPI Details
    document.querySelectorAll('.btn-details').forEach(button => {
        button.addEventListener('click', () => {
            alert(`Details for ${button.dataset.kpi} will be shown in a modal.`);
        });
    });

    // Trade Data Upload
    const tradeDataForm = document.getElementById('tradeDataUploadForm');
    if (tradeDataForm) {
        tradeDataForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const fileInput = document.getElementById('tradeDataFile');
            const file = fileInput.files[0];
            const resultDiv = document.getElementById('uploadResult');
            if (!file) {
                resultDiv.innerHTML = '<p>Error: No file selected.</p>';
                return;
            }
            if (file.name.endsWith('.csv')) {
                Papa.parse(file, {
                    complete: (result) => {
                        resultDiv.innerHTML = '<p>CSV Data Parsed Successfully!</p>';
                        console.log(result.data);
                    },
                    error: () => {
                        resultDiv.innerHTML = '<p>Error parsing CSV file.</p>';
                    },
                    header: true,
                });
            } else {
                resultDiv.innerHTML = '<p>Please upload a valid CSV file.</p>';
            }
        });
    }

    // Tariff Calculator
    const calculateTariffBtn = document.getElementById('calculateTariff');
    if (calculateTariffBtn) {
        calculateTariffBtn.addEventListener('click', () => {
            const exportCountry = document.getElementById('exportCountry').value;
            const importCountry = document.getElementById('importCountry').value;
            const productCode = document.getElementById('productCode').value;
            const resultDiv = document.getElementById('tariffResult');
            if (!exportCountry || !importCountry || !productCode) {
                resultDiv.innerHTML = '<p>Please fill all fields.</p>';
                return;
            }
            resultDiv.innerHTML = `<p>Tariff for ${productCode} from ${exportCountry} to ${importCountry}: 5% (Placeholder)</p>`;
        });
    }

    // Investment Filter
    const filterInvestmentsBtn = document.getElementById('filterInvestments');
    if (filterInvestmentsBtn) {
        filterInvestmentsBtn.addEventListener('click', () => {
            const region = document.getElementById('investmentRegion').value;
            const sector = document.getElementById('investmentSector').value;
            const amount = document.getElementById('investmentAmount').value;
            const projectList = document.getElementById('investmentProjects');
            projectList.innerHTML = `<p>Filtered Projects: Region=${region || 'All'}, Sector=${sector || 'All'}, Amount=${amount || 'Any'}</p>`;
        });
    }

    // Investment Submission
    const investmentForm = document.getElementById('investmentSubmissionForm');
    if (investmentForm) {
        investmentForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const projectName = document.getElementById('projectName').value;
            if (!projectName) {
                alert('Please enter a project name.');
                return;
            }
            alert(`Investment Opportunity "${projectName}" submitted successfully!`);
        });
    }

    // Trade Data Actions
    const refreshTradeDataBtn = document.getElementById('refreshTradeData');
    if (refreshTradeDataBtn) {
        refreshTradeDataBtn.addEventListener('click', () => {
            document.getElementById('tradeBarrierMap').innerHTML = '<p>Trade Data Refreshed!</p>';
        });
    }

    const exportTradeDataBtn = document.getElementById('exportTradeData');
    if (exportTradeDataBtn) {
        exportTradeDataBtn.addEventListener('click', () => {
            alert('Exporting trade data as CSV...');
        });
    }

    // Poverty Data Upload
    const povertyDataForm = document.getElementById('povertyDataUploadForm');
    if (povertyDataForm) {
        povertyDataForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const fileInput = document.getElementById('povertyDataFile');
            const file = fileInput.files[0];
            const resultDiv = document.getElementById('povertyUploadResult');
            if (!file) {
                resultDiv.innerHTML = '<p>Error: No file selected.</p>';
                return;
            }
            if (file.name.endsWith('.csv')) {
                Papa.parse(file, {
                    complete: (result) => {
                        resultDiv.innerHTML = '<p>Poverty Data Parsed Successfully!</p>';
                        console.log(result.data);
                    },
                    error: () => {
                        resultDiv.innerHTML = '<p>Error parsing CSV file.</p>';
                    },
                    header: true,
                });
            } else {
                resultDiv.innerHTML = '<p>Please upload a valid CSV file.</p>';
            }
        });
    }

    // Value Chain Analysis
    const valueChainForm = document.getElementById('valueChainForm');
    if (valueChainForm) {
        valueChainForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const sector = document.getElementById('chainSector').value;
            const resultDiv = document.getElementById('valueChainResult');
            if (!sector) {
                resultDiv.innerHTML = '<p>Please select a sector.</p>';
                return;
            }
            resultDiv.innerHTML = `<p>Analysis for ${sector} value chain completed (Placeholder).</p>`;
        });
    }

    // Enterprise Registration
    const enterpriseRegisterForm = document.getElementById('enterpriseRegisterForm');
    if (enterpriseRegisterForm) {
        enterpriseRegisterForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const enterpriseName = document.getElementById('enterpriseName').value;
            const resultDiv = document.getElementById('enterpriseRegisterResult');
            if (!enterpriseName) {
                resultDiv.innerHTML = '<p>Please enter an enterprise name.</p>';
                return;
            }
            resultDiv.innerHTML = `<p>Enterprise "${enterpriseName}" registered successfully!</p>`;
        });
    }

    // Load Enterprises
    const loadEnterprisesBtn = document.getElementById('loadEnterprises');
    if (loadEnterprisesBtn) {
        loadEnterprisesBtn.addEventListener('click', () => {
            document.getElementById('enterpriseList').innerHTML = '<p>Loaded Enterprises (Placeholder)</p>';
        });
    }
}

// Initialize on DOM Load
document.addEventListener('DOMContentLoaded', initDashboard);