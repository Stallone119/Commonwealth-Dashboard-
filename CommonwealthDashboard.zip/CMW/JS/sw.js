self.addEventListener('install', (event) => {
    event.waitUntil(
        caches.open('commonwealth-dashboard-v1').then((cache) => {
            return cache.addAll([
                '/',
                '/create_admin.php',
                '/index.php',
                '/ECONOMIC GROWTH/economics.php',
                '/SMALL CITIES/sids.html',
                '/CLIMATE/climate.html',
                '/YOUTH/youth.html',
                '/GOVERNANCE/governance.html',
                '/EDUCATION/education.php',
                '/HEALTH/health.php',
                '/SETTINGS/settings.php',
                '/style.css',
                '/script.js',
                '/manifest.json',
                '/icon.png'
            ]);
        })
    );
});

self.addEventListener('fetch', (event) => {
    event.respondWith(
        caches.match(event.request).then((response) => {
            return response || fetch(event.request);
        })
    );
});