module.exports = {
    globDirectory: '.',
    globPatterns: ['*.{html,css,js}', '*.php'],
    swDest: 'sw.js'
};