document.addEventListener('DOMContentLoaded', function() {
    // Initialize charts
    initCharts();
    
    // Set up navigation
    setupNavigation();
    
    // Set up form submissions
    setupForms();
    
    // Show first section by default
    showSection('overview');
});

function initCharts() {
    // Maternal Mortality Chart
    const maternalCtx = document.getElementById('maternalChart').getContext('2d');
    new Chart(maternalCtx, {
        type: 'bar',
        data: {
            labels: ['2015', '2020', '2025', '2030 Target'],
            datasets: [{
                label: 'Deaths per 100,000',
                data: [150, 120, 90, 75],
                backgroundColor: '#002366',
                borderColor: '#FFD700',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Vaccination Chart
    const vaccineCtx = document.getElementById('vaccinationChart').getContext('2d');
    new Chart(vaccineCtx, {
        type: 'line',
        data: {
            labels: ['2015', '2020', '2025', '2030 Target'],
            datasets: [{
                label: 'Coverage %',
                data: [65, 75, 82, 90],
                backgroundColor: 'rgba(0, 35, 102, 0.2)',
                borderColor: '#002366',
                borderWidth: 2,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100
                }
            }
        }
    });

    // Healthcare Access Chart
    const healthCtx = document.getElementById('healthcareChart').getContext('2d');
    new Chart(healthCtx, {
        type: 'doughnut',
        data: {
            labels: ['Current', 'Remaining to Target'],
            datasets: [{
                data: [65, 20],
                backgroundColor: ['#002366', '#FFD700'],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            cutout: '70%'
        }
    });
}

function setupNavigation() {
    // You can add click handlers for navigation items here
    // For example, to switch between sections
}

function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Show selected section
    document.getElementById(sectionId).classList.add('active');
}

function setupForms() {
    // Forum form submission
    document.getElementById('forumForm').addEventListener('submit', function(e) {
        e.preventDefault();
        const postContent = this.elements.post.value;
        if (postContent.trim()) {
            addForumPost(postContent);
            this.reset();
        }
    });
    
    // Upload form submission
    document.getElementById('uploadForm').addEventListener('submit', function(e) {
        e.preventDefault();
        // In a real app, you would handle file upload here
        document.getElementById('analysisResults').innerHTML = `
            <div class="card">
                <h3>Analysis Started</h3>
                <p>Your document is being processed. This would connect to Salesforce in a real implementation.</p>
            </div>
        `;
    });
}

function addForumPost(content) {
    const postsContainer = document.getElementById('forumPosts');
    const postElement = document.createElement('div');
    postElement.className = 'card';
    postElement.innerHTML = `
        <p><strong>New Post:</strong> ${content}</p>
        <small>Posted just now</small>
    `;
    postsContainer.prepend(postElement);
}

function fetchKPI() {
    const country = document.getElementById('countryFilter').value;
    // Example fetch call
    fetch(`/api/kpi?country=${country}`)
        .then(response => response.json())
        .then(data => {
            document.getElementById('kpiDashboard').innerHTML = data.html; // Adjust based on your API response
        })
        .catch(error => console.error('Error fetching KPI:', error));
}


function fetchKPI() {
    const country = document.getElementById('countryFilter').value;
    // Simulate API call
    setTimeout(() => {
        document.getElementById('kpiDashboard').innerHTML = `
            <div class="cards">
                <div class="card">
                    <h3>${country === 'all' ? 'Average' : country} Health KPIs</h3>
                    <p>Life Expectancy: 72 years</p>
                    <p>Doctor per 10,000: 24</p>
                    <p>Hospital Beds per 1,000: 3.2</p>
                </div>
                <div class="card">
                    <h3>Progress</h3>
                    <div style="background: #f0f0f0; height: 20px; border-radius: 10px;">
                        <div style="background: #002366; width: 65%; height: 100%; border-radius: 10px;"></div>
                    </div>
                    <p>65% of 2030 targets achieved</p>
                </div>
            </div>
        `;
    }, 500);
}

function generateReport(type) {
    const chartType = document.getElementById('chartType').value;
    const ctx = document.getElementById('reportChart').getContext('2d');
    
    // Destroy previous chart if it exists
    if (window.reportChart) {
        window.reportChart.destroy();
    }
    
    let data, label, backgroundColor;
    
    switch(type) {
        case 'maternal':
            label = 'Maternal Mortality';
            data = [45, 30, 25, 15];
            backgroundColor = 'rgba(0, 35, 102, 0.6)';
            break;
        case 'vaccination':
            label = 'Vaccination Coverage';
            data = [75, 82, 88, 90];
            backgroundColor = 'rgba(255, 215, 0, 0.6)';
            break;
        case 'healthcare':
            label = 'Healthcare Access';
            data = [60, 70, 80, 85];
            backgroundColor = 'rgba(0, 35, 102, 0.4)';
            break;
    }
    
    window.reportChart = new Chart(ctx, {
        type: chartType,
        data: {
            labels: ['2015', '2020', '2025', '2030 Target'],
            datasets: [{
                label: label,
                data: data,
                backgroundColor: backgroundColor,
                borderColor: '#002366',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: chartType === 'pie' ? {} : {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}