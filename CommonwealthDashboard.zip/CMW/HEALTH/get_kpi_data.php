<?php
header('Content-Type: application/json');

// Database connection
$servername = "localhost";
$username = "your_username";
$password = "your_password";
$dbname = "commonwealth_health";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Connection failed: ' . $conn->connect_error]));
}

// Get country filter
$country = $_GET['country'] ?? 'all';

// Query database for KPIs
if ($country === 'all') {
    $sql = "SELECT 
            AVG(life_expectancy) as life_expectancy,
            AVG(doctors_per_10k) as doctors_per_10k,
            AVG(hospital_beds_per_1k) as hospital_beds,
            AVG(progress_to_target) as progress
            FROM country_kpis";
} else {
    $country = $conn->real_escape_string($country);
    $sql = "SELECT 
            life_expectancy,
            doctors_per_10k,
            hospital_beds_per_1k as hospital_beds,
            progress_to_target as progress
            FROM country_kpis 
            WHERE country_name = '$country'";
}

$result = $conn->query($sql);

if ($result && $result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode([
        'success' => true,
        'data' => [
            'life_expectancy' => round($row['life_expectancy'], 1),
            'doctors_per_10k' => round($row['doctors_per_10k'], 1),
            'hospital_beds' => round($row['hospital_beds'], 1),
            'progress' => round($row['progress'], 1)
        ]
    ]);
} else {
    echo json_encode([
        'success' => false,
        'message' => 'No data found',
        'data' => [
            'life_expectancy' => 72,
            'doctors_per_10k' => 24,
            'hospital_beds' => 3.2,
            'progress' => 65
        ]
    ]);
}

$conn->close();
?>