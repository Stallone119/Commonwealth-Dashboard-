<?php
$countries = [ 
     ['code' => 'ATG', 'name' => 'Antigua and Barbuda'], ['code' => 'AUS', 'name' => 'Australia'],
    ['code' => 'BHS', 'name' => 'Bahamas'], ['code' => 'BGD', 'name' => 'Bangladesh'],
    ['code' => 'BRB', 'name' => 'Barbados'], ['code' => 'BLZ', 'name' => 'Belize'],
    ['code' => 'BWA', 'name' => 'Botswana'], ['code' => 'BRN', 'name' => 'Brunei'],
    ['code' => 'CMR', 'name' => 'Cameroon'], ['code' => 'CAN', 'name' => 'Canada'],
    ['code' => 'CYP', 'name' => 'Cyprus'], ['code' => 'DMA', 'name' => 'Dominica'],
    ['code' => 'SWZ', 'name' => 'Eswatini'], ['code' => 'FJI', 'name' => 'Fiji'],
    ['code' => 'GAB', 'name' => 'Gabon'], ['code' => 'GMB', 'name' => 'Gambia'],
    ['code' => 'GHA', 'name' => 'Ghana'], ['code' => 'GRD', 'name' => 'Grenada'],
    ['code' => 'GUY', 'name' => 'Guyana'], ['code' => 'IND', 'name' => 'India'],
    ['code' => 'JAM', 'name' => 'Jamaica'], ['code' => 'KEN', 'name' => 'Kenya'],
    ['code' => 'KIR', 'name' => 'Kiribati'], ['code' => 'LSO', 'name' => 'Lesotho'],
    ['code' => 'MWI', 'name' => 'Malawi'], ['code' => 'MYS', 'name' => 'Malaysia'],
    ['code' => 'MDV', 'name' => 'Maldives'], ['code' => 'MLT', 'name' => 'Malta'],
    ['code' => 'MUS', 'name' => 'Mauritius'], ['code' => 'MOZ', 'name' => 'Mozambique'],
    ['code' => 'NAM', 'name' => 'Namibia'], ['code' => 'NRU', 'name' => 'Nauru'],
    ['code' => 'NZL', 'name' => 'New Zealand'], ['code' => 'NGA', 'name' => 'Nigeria'],
    ['code' => 'PAK', 'name' => 'Pakistan'], ['code' => 'PNG', 'name' => 'Papua New Guinea'],
    ['code' => 'RWA', 'name' => 'Rwanda'], ['code' => 'KNA', 'name' => 'Saint Kitts and Nevis'],
    ['code' => 'LCA', 'name' => 'Saint Lucia'], ['code' => 'VCT', 'name' => 'Saint Vincent and the Grenadines'],
    ['code' => 'WSM', 'name' => 'Samoa'], ['code' => 'SYC', 'name' => 'Seychelles'],
    ['code' => 'SLE', 'name' => 'Sierra Leone'], ['code' => 'SGP', 'name' => 'Singapore'],
    ['code' => 'SLB', 'name' => 'Solomon Islands'], ['code' => 'ZAF', 'name' => 'South Africa'],
    ['code' => 'LKA', 'name' => 'Sri Lanka'], ['code' => 'TZA', 'name' => 'Tanzania'],
    ['code' => 'TGO', 'name' => 'Togo'], ['code' => 'TON', 'name' => 'Tonga'],
    ['code' => 'TTO', 'name' => 'Trinidad and Tobago'], ['code' => 'TUV', 'name' => 'Tuvalu'],
    ['code' => 'UGA', 'name' => 'Uganda'], ['code' => 'GBR', 'name' => 'United Kingdom'],
    ['code' => 'VUT', 'name' => 'Vanuatu'], ['code' => 'ZMB', 'name' => 'Zambia']
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Health Dashboard</title>
    <link rel="stylesheet" href="health.css">
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-chart-gantt"></script>
    <script src="https://cdn.workbox.googleapis.com/v6.5.4/workbox-sw.js"></script>
</head>
<body>
    <div class="container">
         <div class="logo-container">
        <img src="icon.jpg" alt="Commonwealth Logo" class="logo">
        </div>
            <h1>Health Dashboard</h1>
            <nav>
                <a href="../ECONOMIC GROWTH/economics.php">Economic Development</a>
                <a href="../SMALL CITIES/sids.html">SIDS</a>
                <a href="../CLIMATE/climate.html">Climate And Oceans</a>
                <a href="../YOUTH/youth.html">Youth And Gender</a>
                <a href="../GOVERNANCE/governance.html">Governance and Peace</a>
                <a href="../EDUCATION/education.php">Education</a>
            </nav>
        </header>

        <section id="overview" class="section active">
            <h2>Overview</h2>
            <div class="cards">
                <div class="card">
                    <h3>Maternal Mortality</h3>
                    <p>Target: 50% reduction by 2030</p>
                    <canvas id="maternalChart"></canvas>
                </div>
                <div class="card">
                    <h3>Vaccination Coverage</h3>
                    <p>Target: 90% by 2030</p>
                    <canvas id="vaccinationChart"></canvas>
                </div>
                <div class="card">
                    <h3>Healthcare Access</h3>
                    <p>Target: 85% by 2030</p>
                    <canvas id="healthcareChart"></canvas>
                </div>
            </div>
        </section>

        <section id="kpi" class="section">
            <h2>KPI Tracking</h2>
            <div class="kpi-controls">
                <select id="countryFilter">
                    <option value="all">All Countries</option>
                    <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                    <option value="Australia">Australia</option>
                    <option value="Bahamas">Bahamas</option>
                    <option value="Bangladesh">Bangladesh</option>
                    <option value="Barbados">Barbados</option>
                    <option value="Belize">Belize</option>
                    <option value="Botswana">Botswana</option>
                    <option value="Brunei">Brunei</option>
                    <option value="Cameroon">Cameroon</option>
                    <option value="Canada">Canada</option>
                    <option value="Cyprus">Cyprus</option>
                    <option value="Dominica">Dominica</option>
                    <option value="Eswatini">Eswatini</option>
                    <option value="Fiji">Fiji</option>
                    <option value="Gabon">Gabon</option>
                    <option value="Gambia">Gambia</option>
                    <option value="Ghana">Ghana</option>
                    <option value="Grenada">Grenada</option>
                    <option value="Guyana">Guyana</option>
                    <option value="India">India</option>
                    <option value="Jamaica">Jamaica</option>
                    <option value="Kenya">Kenya</option>
                    <option value="Kiribati">Kiribati</option>
                    <option value="Lesotho">Lesotho</option>
                    <option value="Malawi">Malawi</option>
                    <option value="Malaysia">Malaysia</option>
                    <option value="Maldives">Maldives</option>
                    <option value="Malta">Malta</option>
                    <option value="Mauritius">Mauritius</option>
                    <option value="Mozambique">Mozambique</option>
                    <option value="Namibia">Namibia</option>
                    <option value="Nauru">Nauru</option>
                    <option value="New Zealand">New Zealand</option>
                    <option value="Nigeria">Nigeria</option>
                    <option value="Pakistan">Pakistan</option>
                    <option value="Papua New Guinea">Papua New Guinea</option>
                    <option value="Rwanda">Rwanda</option>
                    <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                    <option value="Saint Lucia">Saint Lucia</option>
                    <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                    <option value="Samoa">Samoa</option>
                    <option value="Seychelles">Seychelles</option>
                    <option value="Sierra Leone">Sierra Leone</option>
                    <option value="Singapore">Singapore</option>
                    <option value="Solomon Islands">Solomon Islands</option>
                    <option value="South Africa">South Africa</option>
                    <option value="Sri Lanka">Sri Lanka</option>
                    <option value="Tanzania">Tanzania</option>
                    <option value="Togo">Togo</option>
                    <option value="Tonga">Tonga</option>
                    <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                    <option value="Tuvalu">Tuvalu</option>
                    <option value="Uganda">Uganda</option>
                    <option value="United Kingdom">United Kingdom</option>
                    <option value="Vanuatu">Vanuatu</option>
                    <option value="Zambia">Zambia</option>
                </select>
                <button onclick="fetchKPI()">Refresh KPIs</button>
            </div>
            <div id="kpiDashboard"></div>
        </section>

        <section id="reports" class="section">
            <h2>Reports</h2>
            <div class="report-controls">
                <select id="chartType">
                    <option value="pie">Pie Chart</option>
                    <option value="heatmap">Heat Map</option>
                    <option value="sankey">Sankey Diagram</option>
                </select>
                <button onclick="generateReport('maternal')">Maternal Report</button>
                <button onclick="generateReport('vaccination')">Vaccination Report</button>
                <button onclick="generateReport('healthcare')">Healthcare Report</button>
            </div>
            <div id="reportOutput"></div>
            <canvas id="pieChart" style="display: none;"></canvas>
            <div id="heatMap" style="display: none;"></div>
            <div id="sankeyDiagram" style="display: none;"></div>
        </section>

        <section id="collaboration" class="section">
            <h2>Collaboration (Asana)</h2>
            <form id="forumForm" action="submit_post.php" method="POST">
                <textarea name="post" placeholder="Share ideas..."></textarea>
                <button type="submit">Post</button>
            </form>
            <div id="forumPosts"></div>
        </section>

        <section id="documents" class="section">
            <h2>Document Analysis (Salesforce)</h2>
            <form id="uploadForm" enctype="multipart/form-data">
                <input type="file" name="document" accept=".csv,.xlsx,.xls" required>
                <select name="dataType" required>
                    <option value="">Select Type</option>
                    <option value="maternal">Maternal Data</option>
                    <option value="vaccination">Vaccination Data</option>
                    <option value="healthcare">Healthcare Data</option>
                </select>
                <select name="country" required>
                    <option value="">Select Country</option>
                    <?php foreach ($countries as $country): ?>
                        <option value="<?= $country['code'] ?>"><?= $country['name'] ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="hidden" name="dashboard" value="health">
                <button type="submit">Analyze</button>
            </form>
            <div id="analysisResults"></div>
        </section>

        <footer>
            <p>Powered by Microsoft Project, Asana, Salesforce, Power BI, Clockify</p>
        </footer>
    </div>
    <script src="health.js"></script>
</body>
</html>