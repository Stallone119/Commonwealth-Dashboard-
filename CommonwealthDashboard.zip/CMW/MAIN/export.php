<?php
session_start();
require_once 'db_connect.php';

if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] !== 'System Admin' && $_SESSION['user']['theme'] !== 'all')) {
    http_response_code(403);
    exit;
}

$dataType = $_GET['dataType'] ?? '';
$country = $_GET['country'] ?? 'all';
$dashboardMap = [
    'poverty' => 'economic', 'exports' => 'economic', 'fdi' => 'economic',
    'adaptation' => 'sids', 'mitigation' => 'sids', 'resilience' => 'sids',
    'emissions' => 'climate', 'renewables' => 'climate', 'climateFinance' => 'climate',
    'youthEmployment' => 'youth', 'enrollment' => 'youth', 'participation' => 'youth',
    'literacy' => 'education', 'stem' => 'education', 'digitalLearning' => 'education',
    'maternal' => 'health', 'vaccination' => 'health', 'healthcare' => 'health'
];

if (!isset($dashboardMap[$dataType])) {
    http_response_code(400);
    exit;
}

$dashboard = $dashboardMap[$dataType];
$sql = $country === 'all' ?
    "SELECT metric, value FROM kpi_data WHERE dashboard = ? AND metric = ?" :
    "SELECT metric, value FROM kpi_data WHERE dashboard = ? AND metric = ? AND country = ?";
$stmt = $conn->prepare($sql);
if ($country === 'all') {
    $stmt->bind_param('ss', $dashboard, $dataType);
} else {
    $stmt->bind_param('sss', $dashboard, $dataType, $country);
}
$stmt->execute();
$result = $stmt->get_result();

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename="' . $dataType . '.csv"');
echo "Metric,Value\n";
while ($row = $result->fetch_assoc()) {
    echo '"' . $row['metric'] . '","' . $row['value'] . "\"\n";
}
$stmt->close();
$conn->close();
?>