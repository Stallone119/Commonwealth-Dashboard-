<?php
session_start();
require_once 'db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] !== 'System Admin' && $_SESSION['user']['theme'] !== 'all')) {
    echo json_encode(['status' => 'error', 'error' => 'Access Denied']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $content = $_POST['content'] ?? '';
    $country = $_POST['country'] ?? 'all';
    $dashboard = $_POST['dashboard'] ?? 'all';
    $username = $_SESSION['user']['username'];

    if (!$content) {
        echo json_encode(['status' => 'error', 'error' => 'Content required']);
        exit;
    }

    $sql = "INSERT INTO forum_posts (username, content, country_code, dashboard) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssss', $username, $content, $country, $dashboard);
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => 'Post submitted']);
    } else {
        echo json_encode(['status' => 'error', 'error' => 'Failed to submit post']);
    }
    $stmt->close();
} elseif ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $country = $_GET['country'] ?? 'all';
    $dashboard = $_GET['dashboard'] ?? 'all';
    $sql = "SELECT username, content, country_code, created_at FROM forum_posts WHERE dashboard = ? AND country_code = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ss', $dashboard, $country);
    $stmt->execute();
    $result = $stmt->get_result();
    $posts = [];
    while ($row = $result->fetch_assoc()) {
        $posts[] = $row;
    }
    echo json_encode($posts);
    $stmt->close();
}
$conn->close();
?>