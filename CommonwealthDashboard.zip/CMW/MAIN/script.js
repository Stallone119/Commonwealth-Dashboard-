// Initialize charts and dashboard
document.addEventListener('DOMContentLoaded', function() {
    // Initialize dashboard based on user role
    initDashboard();
    
    // Load initial data
    loadKPIData();
    loadChartData();
    
    // Set up event listeners
    document.getElementById('countryFilter').addEventListener('change', filterData);
    document.getElementById('uploadForm').addEventListener('submit', handleFileUpload);
    document.getElementById('forumForm').addEventListener('submit', postForumComment);
    
    // If user is System Admin, initialize user management
    if (user.role === 'System Admin') {
        initUserManagement();
    }
    
    // Track user activity
    logActivity('Accessed dashboard');
});

// Initialize dashboard based on user role
function initDashboard() {
    const role = user.role;
    
    // Hide/show elements based on role
    switch(role) {
        case 'System Admin':
            // Show all elements
            break;
        case 'Theme Admin':
            // Hide user management
            document.querySelectorAll('.user-management').forEach(el => el.style.display = 'none');
            break;
        case 'Project Manager':
            // Show only project-related elements
            document.getElementById('ganttChart').style.display = 'block';
            document.querySelectorAll('canvas:not(#ganttChart)').forEach(el => el.style.display = 'none');
            break;
        case 'Field Officer':
            // Show only data entry elements
            document.getElementById('uploadForm').style.display = 'block';
            document.querySelectorAll('canvas, #kpiDashboard, #reportOutput').forEach(el => el.style.display = 'none');
            break;
        case 'Data Analyst':
            // Show only data visualization elements
            document.getElementById('exportData').style.display = 'block';
            document.getElementById('uploadForm').style.display = 'none';
            break;
        case 'Partner':
            // Show only contract-specified elements
            document.getElementById('uploadForm').style.display = 'none';
            break;
    }
}

// User Management Functions
function initUserManagement() {
    // Add user management section to the DOM
    const userManagementHTML = `
        <div class="user-management">
            <h2>User Management</h2>
            <button onclick="showAddUserForm()">Add New User</button>
            <div id="addUserForm" class="user-form" style="display: none;">
                <h3>Add User</h3>
                <form id="userForm">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" required>
                    </div>
                    <div class="form-group">
                        <label for="role">Role</label>
                        <select id="role" required>
                            <option value="">Select Role</option>
                            <option value="Theme Admin">Theme Admin</option>
                            <option value="Project Manager">Project Manager</option>
                            <option value="Field Officer">Field Officer</option>
                            <option value="Data Analyst">Data Analyst</option>
                            <option value="Partner">Partner</option>
                        </select>
                    </div>
                    <div class="form-group" id="themeGroup" style="display: none;">
                        <label for="theme">Theme</label>
                        <select id="theme">
                            <option value="all">All Themes</option>
                            <option value="ECONOMIC GROWTH">Economic Growth</option>
                            <option value="SMALL CITIES">Small Cities</option>
                            <option value="CLIMATE">Climate And Oceans</option>
                            <option value="YOUTH">Youth</option>
                            <option value="GOVERNANCE">Governance And Peace</option>
                            <option value="HEALTH">Health</option>
                            <option value="EDUCATION">Education</option>
                        </select>
                    </div>
                    <div class="form-group" id="countryGroup" style="display: none;">
                        <label for="country">Country</label>
                        <select id="country">
                            ${Object.entries(countries).map(([code, name]) => 
                                `<option value="${code}">${name}</option>`).join('')}
                        </select>
                    </div>
                    <button type="submit">Save User</button>
                </form>
            </div>
            <table class="user-table">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Theme/Country</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="userTableBody">
                    <!-- Users will be loaded here -->
                </tbody>
            </table>
        </div>
    `;
    
    document.querySelector('.main-content').insertAdjacentHTML('afterbegin', userManagementHTML);
    
    // Load users
    loadUsers();
    
    // Set up event listeners for user form
    document.getElementById('role').addEventListener('change', function() {
        const role = this.value;
        const themeGroup = document.getElementById('themeGroup');
        const countryGroup = document.getElementById('countryGroup');
        
        themeGroup.style.display = role === 'Theme Admin' ? 'block' : 'none';
        countryGroup.style.display = role === 'Field Officer' ? 'block' : 'none';
    });
    
    document.getElementById('userForm').addEventListener('submit', saveUser);
}

function showAddUserForm() {
    document.getElementById('addUserForm').style.display = 'block';
}

function loadUsers() {
    // In a real app, this would be an API call
    // For demo, we'll use mock data
    const mockUsers = [
        { id: 1, username: 'admin1', email: 'admin1@commonwealth.org', role: 'Theme Admin', theme: 'ECONOMIC GROWTH', country: '' },
        { id: 2, username: 'pm1', email: 'pm1@commonwealth.org', role: 'Project Manager', theme: '', country: '' },
        { id: 3, username: 'field1', email: 'field1@commonwealth.org', role: 'Field Officer', theme: '', country: 'KEN' },
        { id: 4, username: 'analyst1', email: 'analyst1@commonwealth.org', role: 'Data Analyst', theme: '', country: '' },
        { id: 5, username: 'partner1', email: 'partner1@org.org', role: 'Partner', theme: '', country: '' }
    ];
    
    const tbody = document.getElementById('userTableBody');
    tbody.innerHTML = '';
    
    mockUsers.forEach(user => {
        const themeOrCountry = user.role === 'Theme Admin' ? user.theme : 
                             (user.role === 'Field Officer' ? countries[user.country] : 'N/A');
        
        const row = `
            <tr>
                <td>${user.username}</td>
                <td>${user.email}</td>
                <td>${user.role}</td>
                <td>${themeOrCountry}</td>
                <td>
                    <button onclick="editUser(${user.id})">Edit</button>
                    <button onclick="deleteUser(${user.id})">Delete</button>
                    <button onclick="viewActivity(${user.id})">Activity</button>
                </td>
            </tr>
        `;
        
        tbody.insertAdjacentHTML('beforeend', row);
    });
}

function saveUser(e) {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const role = document.getElementById('role').value;
    const theme = document.getElementById('theme').value;
    const country = document.getElementById('country').value;
    
    // Validate inputs
    if (!username || !email || !password || !role) {
        alert('Please fill all required fields');
        return;
    }
    
    // In a real app, this would be an API call to save the user
    console.log('Saving user:', { username, email, role, theme, country });
    
    // Show success message
    alert('User saved successfully');
    
    // Reset form and reload users
    document.getElementById('userForm').reset();
    document.getElementById('addUserForm').style.display = 'none';
    loadUsers();
    
    // Log activity
    logActivity(`Added new user: ${username} (${role})`);
}

function editUser(id) {
    // In a real app, this would fetch user data and populate the form
    console.log('Editing user with ID:', id);
    
    // For demo, we'll just show the form
    document.getElementById('addUserForm').style.display = 'block';
    document.getElementById('userForm').scrollIntoView();
    
    // Log activity
    logActivity(`Edited user with ID: ${id}`);
}

function deleteUser(id) {
    if (confirm('Are you sure you want to delete this user?')) {
        // In a real app, this would be an API call
        console.log('Deleting user with ID:', id);
        
        // Show success message
        alert('User deleted successfully');
        
        // Reload users
        loadUsers();
        
        // Log activity
        logActivity(`Deleted user with ID: ${id}`);
    }
}

function viewActivity(id) {
    // In a real app, this would fetch user activity
    console.log('Viewing activity for user with ID:', id);
    
    // For demo, we'll show mock activity
    const mockActivity = [
        { timestamp: '2023-05-01 10:30', action: 'Logged in' },
        { timestamp: '2023-05-01 11:15', action: 'Viewed dashboard' },
        { timestamp: '2023-05-01 12:30', action: 'Uploaded data' },
        { timestamp: '2023-05-01 14:45', action: 'Logged out' }
    ];
    
    const activityHTML = mockActivity.map(act => 
        `<p>${act.timestamp} - ${act.action}</p>`
    ).join('');
    
    alert(`Activity for user ID ${id}:\n\n${activityHTML}`);
}

// Settings Functions
function showSettingsModal() {
    const modalHTML = `
        <div id="settingsModal" class="modal">
            <div class="modal-content">
                <div class="modal-header">
                    <h2>System Settings</h2>
                    <span class="close" onclick="closeModal()">&times;</span>
                </div>
                <div class="modal-body">
                    <p>To modify system settings, please enter your admin secret code:</p>
                    <input type="password" id="adminCode" placeholder="Enter secret code">
                    <button onclick="verifyAdminCode()">Verify</button>
                    <div id="settingsForm" style="display: none; margin-top: 20px;">
                        <h3>System Configuration</h3>
                        <div class="form-group">
                            <label for="systemName">System Name</label>
                            <input type="text" id="systemName" value="Commonwealth Dashboard">
                        </div>
                        <div class="form-group">
                            <label for="maintenanceMode">Maintenance Mode</label>
                            <input type="checkbox" id="maintenanceMode">
                        </div>
                        <div class="form-group">
                            <label for="dataRetention">Data Retention (days)</label>
                            <input type="number" id="dataRetention" value="365">
                        </div>
                        <button onclick="saveSettings()">Save Settings</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', modalHTML);
    document.getElementById('settingsModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('settingsModal').style.display = 'none';
    document.getElementById('settingsModal').remove();
}

function verifyAdminCode() {
    const code = document.getElementById('adminCode').value;
    
    // In a real app, this would verify against a stored hash
    if (code === 'Commonwealth2023') { // Demo code
        document.getElementById('settingsForm').style.display = 'block';
    } else {
        alert('Invalid admin code');
    }
}

function saveSettings() {
    const systemName = document.getElementById('systemName').value;
    const maintenanceMode = document.getElementById('maintenanceMode').checked;
    const dataRetention = document.getElementById('dataRetention').value;
    
    // In a real app, this would save to the server
    console.log('Saving settings:', { systemName, maintenanceMode, dataRetention });
    
    alert('Settings saved successfully');
    closeModal();
    
    // Log activity
    logActivity('Updated system settings');
}

// Activity Logging
function logActivity(action) {
    const timestamp = new Date().toISOString();
    const activityLog = document.getElementById('activityLog');
    
    // In a real app, this would send to the server
    console.log(`[${timestamp}] ${user.username}: ${action}`);
    
    // Display in activity log section
    if (activityLog) {
        const activityItem = document.createElement('p');
        activityItem.textContent = `[${new Date(timestamp).toLocaleString()}] ${action}`;
        activityLog.appendChild(activityItem);
    }
}


// Dashboard Functions
function loadKPIData() {
    // Mock KPI data
    const kpiData = [
        { name: 'Active Projects', value: 24, change: '+2%' },
        { name: 'Data Entries', value: 1563, change: '+15%' },
        { name: 'Countries Active', value: 32, change: '0%' },
        { name: 'Themes Covered', value: 7, change: '0%' },
        { name: 'Users Online', value: 8, change: '-1%' }
    ];
    
    const kpiDashboard = document.getElementById('kpiDashboard');
    if (kpiDashboard) {
        kpiDashboard.innerHTML = kpiData.map(kpi => `
            <div class="kpi-card">
                <div class="kpi-label">${kpi.name}</div>
                <div class="kpi-value">${kpi.value}</div>
                <div class="kpi-change">${kpi.change}</div>
            </div>
        `).join('');
    }
}

function loadChartData() {
    // Mock chart data
    const countries = ['Kenya', 'India', 'UK', 'Canada', 'Australia'];
    const povertyData = [23.4, 21.9, 12.4, 9.3, 11.7];
    const exportsData = [45, 78, 92, 65, 88];
    
    // Initialize charts
    createBarChart('povertyChart', 'Poverty Rate (%)', countries, povertyData);
    createBarChart('exportsChart', 'Exports (Billion USD)', countries, exportsData);
    
    // Other charts would be initialized similarly
}

function createBarChart(canvasId, label, labels, data) {
    const ctx = document.getElementById(canvasId).getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: label,
                data: data,
                backgroundColor: [
                    'rgba(26, 62, 114, 0.7)', // Commonwealth blue
                    'rgba(255, 215, 0, 0.7)',   // Commonwealth gold
                    'rgba(46, 139, 87, 0.7)',   // Commonwealth green
                    'rgba(178, 34, 52, 0.7)',   // Commonwealth red
                    'rgba(108, 180, 238, 0.7)'  // Commonwealth light blue
                ],
                borderColor: [
                    'rgba(26, 62, 114, 1)',
                    'rgba(255, 215, 0, 1)',
                    'rgba(46, 139, 87, 1)',
                    'rgba(178, 34, 52, 1)',
                    'rgba(108, 180, 238, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

function filterData() {
    const country = document.getElementById('countryFilter').value;
    console.log('Filtering data for country:', country);
    
    // In a real app, this would reload data from the server
    loadKPIData();
    loadChartData();
    
    // Log activity
    logActivity(`Filtered data by country: ${country === 'all' ? 'All Countries' : countries[country]}`);
}

function generateReport(dataType) {
    console.log('Generating report for:', dataType);
    
    // In a real app, this would generate a proper report
    const reportOutput = document.getElementById('reportOutput');
    reportOutput.innerHTML = `
        <h3>${dataType.charAt(0).toUpperCase() + dataType.slice(1)} Report</h3>
        <p>Generated on ${new Date().toLocaleString()}</p>
        <p>This is a sample report for ${dataType} data. In a real application, this would contain detailed analysis and visualizations.</p>
    `;
    
    // Log activity
    logActivity(`Generated ${dataType} report`);
}

function drawGanttChart() {
    console.log('Drawing Gantt chart');
    
    // In a real app, this would show actual project timelines
    const ctx = document.getElementById('ganttChart').getContext('2d');
    
    // Sample Gantt chart data
    const projects = [
        { name: 'Economic Survey', start: 1, end: 10 },
        { name: 'Climate Study', start: 5, end: 15 },
        { name: 'Youth Program', start: 8, end: 20 }
    ];
    
    // Simple Gantt chart implementation
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: projects.map(p => p.name),
            datasets: [{
                label: 'Project Timeline',
                data: projects.map(p => p.end - p.start),
                backgroundColor: 'rgba(26, 62, 114, 0.7)',
                borderColor: 'rgba(26, 62, 114, 1)',
                borderWidth: 1,
                barPercentage: 0.5
            }]
        },
        options: {
            indexAxis: 'y',
            scales: {
                x: {
                    beginAtZero: true,
                    max: 30,
                    title: {
                        display: true,
                        text: 'Days'
                    }
                }
            }
        }
    });
    
    document.getElementById('ganttChart').style.display = 'block';
    
    // Log activity
    logActivity('Viewed project timeline (Gantt chart)');
}

function exportData(format) {
    console.log(`Exporting data as ${format}`);
    
    // In a real app, this would generate actual export data
    alert(`Data exported as ${format.toUpperCase()} successfully`);
    
    // Log activity
    logActivity(`Exported data as ${format.toUpperCase()}`);
}

function handleFileUpload(e) {
    e.preventDefault();
    
    const formData = new FormData(e.target);
    const dataType = formData.get('dataType');
    const country = formData.get('country');
    
    console.log('Uploading file for:', dataType, 'in', country);
    
    // In a real app, this would upload to the server
    alert('File uploaded successfully. Data will be processed shortly.');
    
    // Reset form
    e.target.reset();
    
    // Log activity
    logActivity(`Uploaded ${dataType} data for ${country === 'all' ? 'all countries' : countries[country]}`);
}

function postForumComment(e) {
    e.preventDefault();
    
    const content = e.target.content.value;
    console.log('Posting forum comment:', content);
    
    // In a real app, this would save to the server
    const forumPosts = document.getElementById('forumPosts');
    const postHTML = `
        <div class="forum-post">
            <p><strong>${user.username}</strong> (${new Date().toLocaleString()}):</p>
            <p>${content}</p>
        </div>
    `;
    
    forumPosts.insertAdjacentHTML('afterbegin', postHTML);
    
    // Reset form
    e.target.reset();
    
    // Log activity
    logActivity('Posted forum comment');
}

function trackLocation() {
    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
            position => {
                const { latitude, longitude } = position.coords;
                document.getElementById('locationData').innerHTML = `
                    <p>Your current location: Latitude ${latitude.toFixed(4)}, Longitude ${longitude.toFixed(4)}</p>
                `;
                
                // Log activity
                logActivity('Tracked location');
            },
            error => {
                console.error('Error getting location:', error);
                alert('Unable to retrieve your location');
            }
        );
    } else {
        alert('Geolocation is not supported by your browser');
    }
}

// Theme toggle functionality
function toggleTheme() {
    document.body.classList.toggle('dark');
    const isDark = document.body.classList.contains('dark');
    localStorage.setItem('theme', isDark ? 'dark' : 'light');
    
    // Log activity
    logActivity(`Switched to ${isDark ? 'dark' : 'light'} mode`);
}

// Initialize theme from localStorage
const savedTheme = localStorage.getItem('theme');
if (savedTheme === 'dark') {
    document.body.classList.add('dark');
}