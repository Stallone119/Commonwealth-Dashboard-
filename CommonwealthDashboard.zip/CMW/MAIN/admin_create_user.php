<?php
session_start();
require_once __DIR__ . '/../DATABASE/db_connect.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'System Admin') {
    header('Location: verify_admin.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $role = $_POST['role'];
    $country = $_POST['country'];
    $theme = $_POST['theme'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $mode = $_POST['mode'];

    $sql = "INSERT INTO users (username, password, role, country, theme, email, phone, mode) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssssss', $username, $password, $role, $country, $theme, $email, $phone, $mode);
    if ($stmt->execute()) {
        $user_id = $_SESSION['user']['id'];
        $sql = "INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details) VALUES (?, ?, 'users', ?, ?)";
        $stmt = $conn->prepare($sql);
        $action = 'Created user';
        $details = json_encode(['username' => $username, 'role' => $role]);
        $stmt->bind_param('isis', $user_id, $action, $conn->insert_id, $details);
        $stmt->execute();
        $success = "User created successfully";
    } else {
        $error = "Error creating user: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create User - Commonwealth Dashboard</title>
    <link rel="stylesheet" href="admin_create_user.css">
    <link rel="manifest" href="../JS/manifest.json">
</head>
<body>
    <nav>
        <a href="index.php">Dashboard</a>
        <a href="../MAIN/admin_create_user.php">Create User</a>
        <a href="../SETTINGS/settings.php">Settings</a>
        <a href="../SETTINGS/logout.php">Logout</a>
    </nav>
    <div class="container">
        <h1>Create User Account</h1>
        <form method="POST">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <label for="role">Role:</label>
            <select id="role" name="role" required>
                <option value="Thematic Admin">Thematic Admin</option>
                <option value="Program Manager">Program Manager</option>
                <option value="Field Officer">Field Officer</option>
                <option value="Data Analyst">Data Analyst</option>
                <option value="Partner">Partner</option>
            </select>
            <label for="country">Country:</label>
            <select id="country" name="country" required>
                <option value="all">All Countries</option>
                <!-- Populated by JavaScript -->
            </select>
            <label for="theme">Theme:</label>
            <select id="theme" name="theme" required>
                <option value="all">All Themes</option>
                <option value="economic">Economic</option>
                <option value="sids">SIDS</option>
                <option value="climate">Climate</option>
                <option value="youth">Youth</option>
                <option value="education">Education</option>
                <option value="health">Health</option>
            </select>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone" required>
            <label for="mode">Mode:</label>
            <select id="mode" name="mode">
                <option value="light">Light</option>
                <option value="dark">Dark</option>
            </select>
            <button type="submit">Create User</button>
            <?php if (isset($success)) echo "<p class='success'>$success</p>"; ?>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
        </form>
    </div>
    <script src="admin_create_user.js"></script>
    <script>
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('../JS/sw.js');
        }
    </script>
</body>
</html>