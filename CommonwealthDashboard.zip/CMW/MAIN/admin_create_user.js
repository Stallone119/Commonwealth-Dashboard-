// Commonwealth countries for the dropdown
const commonwealthCountries = [
    "Antigua and Barbuda", "Australia", "Bahamas", "Bangladesh", "Barbados", 
    "Belize", "Botswana", "Brunei", "Cameroon", "Canada", "Cyprus", 
    "Dominica", "Eswatini", "Fiji", "Gambia", "Ghana", "Grenada", 
    "Guyana", "India", "Jamaica", "Kenya", "Kiribati", "Lesotho", 
    "Malawi", "Malaysia", "Maldives", "Malta", "Mauritius", 
    "Mozambique", "Namibia", "Nauru", "New Zealand", "Nigeria", 
    "Pakistan", "Papua New Guinea", "Rwanda", "Saint Kitts and Nevis", 
    "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", 
    "Seychelles", "Sierra Leone", "Singapore", "Solomon Islands", 
    "South Africa", "Sri Lanka", "Tanzania", "Tonga", "Trinidad and Tobago", 
    "Tuvalu", "Uganda", "United Kingdom", "Vanuatu", "Zambia"
];

document.addEventListener('DOMContentLoaded', function() {
    // Populate country dropdown
    const countrySelect = document.getElementById('country');
    commonwealthCountries.forEach(country => {
        const option = document.createElement('option');
        option.value = country.toLowerCase().replace(/\s+/g, '_');
        option.textContent = country;
        countrySelect.appendChild(option);
    });

    // Form validation
    const form = document.querySelector('form');
    form.addEventListener('submit', function(event) {
        let isValid = true;
        
        // Validate password strength
        const password = document.getElementById('password').value;
        if (password.length < 8) {
            alert('Password must be at least 8 characters long');
            isValid = false;
        }
        
        // Validate email format
        const email = document.getElementById('email').value;
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            alert('Please enter a valid email address');
            isValid = false;
        }
        
        // Validate phone number
        const phone = document.getElementById('phone').value;
        const phoneRegex = /^[\d\s\+\-\(\)]{10,}$/;
        if (!phoneRegex.test(phone)) {
            alert('Please enter a valid phone number');
            isValid = false;
        }
        
        if (!isValid) {
            event.preventDefault();
        }
    });

    // Theme toggle functionality (for future dark mode implementation)
    const modeSelect = document.getElementById('mode');
    modeSelect.addEventListener('change', function() {
        if (this.value === 'dark') {
            document.body.classList.add('dark-mode');
        } else {
            document.body.classList.remove('dark-mode');
        }
    });
});

// Service Worker registration
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/sw.js').then(registration => {
            console.log('ServiceWorker registration successful');
        }).catch(err => {
            console.log('ServiceWorker registration failed: ', err);
        });
    });
}