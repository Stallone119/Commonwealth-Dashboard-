<?php
session_start();
if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] !== 'System Admin' && $_SESSION['user']['theme'] !== 'all')) {
    header('Location: verify_admin.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Commonwealth Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/PapaParse/5.3.0/papaparse.min.js"></script>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #7296ccff;
            color: #333;
        }
        
        .sidebar {
            width: 250px;
            background-color: #1a3e72;
            color: white;
            position: fixed;
            height: 100%;
            overflow-y: auto;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            transition: all 0.3s;
        }
        
        .logo-container {
            padding: 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255,255,255,0.1);
        }
        
        .logo {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            margin-bottom: 15px;
        }
        
        .user-info {
            font-size: 14px;
            color: #fff;
        }
        
        nav {
            padding: 20px 0;
        }
        
        nav a {
            display: block;
            padding: 12px 20px;
            color: rgba(255,255,255,0.8);
            text-decoration: none;
            transition: all 0.3s;
            font-size: 15px;
        }
        
        nav a:hover, nav a.active {
            background-color: rgba(255,255,255,0.1);
            color: white;
        }
        
        .main-content {
            margin-left: 250px;
            padding: 30px;
            background-color: #f5f7fa;
        }
        
        .charts-container {
            display: grid;
            grid-template-columns: 1fr;
            gap: 30px;
            margin-top: 30px;
        }
        
        .chart-section {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.05);
            padding: 20px;
        }
        
        .chart-section h2 {
            color: #1a3e72;
            font-size: 22px;
            margin-bottom: 20px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }
        .chart-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr); /* Exactly 2 columns */
    grid-template-rows: repeat(5, auto); /* Maximum 5 rows (10 charts total) */
    gap: 15px; /* Reduced gap for a more compact layout */
    max-height: 1000px; /* Optional: limit height to prevent overflow */
    overflow-y: auto; /* Allow scrolling if more than 10 charts */
}

.chart-card {
    background-color: #f9f9f9;
    border-radius: 6px;
    padding: 10px; /* Reduced padding */
    box-shadow: 0 1px 5px rgba(0,0,0,0.05);
    min-height: 200px; /* Smaller height for compact charts */
}

.chart-title {
    margin-top: 0;
    margin-bottom: 10px; /* Reduced margin */
    color: #1a3e72;
    font-size: 14px; /* Smaller font size */
}

.chart-grid canvas {
    max-height: 150px; /* Smaller canvas height */
    width: 100%;
}
        
        .kpi-dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }
        
        .kpi-card {
            background-color: white;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            text-align: center;
        }
        
        .kpi-label {
            font-size: 14px;
            color: #666;
            margin-bottom: 5px;
        }
        
        .kpi-value {
            font-size: 24px;
            font-weight: bold;
            color: #1a3e72;
            margin-bottom: 5px;
        }
        
        .kpi-change {
            font-size: 12px;
            color: #4CAF50;
        }
        
        .kpi-change.negative {
            color: #F44336;
        }
        
        .controls {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }
        
        select, button {
            padding: 10px 15px;
            border-radius: 4px;
            border: 1px solid #ddd;
            background-color: white;
            font-size: 14px;
        }
        
        button {
            background-color: #1a3e72;
            color: white;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        button:hover {
            background-color: #15325e;
        }
        
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 8px;
            width: 80%;
            max-width: 600px;
        }
        
        .close {
            color: #aaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        
        .close:hover {
            color: black;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: 500;
        }
        
        .form-group input, .form-group select {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        
        .user-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        
        .user-table th, .user-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .user-table th {
            background-color: #f5f7fa;
            font-weight: 600;
        }
        
        .forum-post {
            background-color: white;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            min-height: 100px;
            margin-bottom: 10px;
        }
        
        /* Dark mode styles */
        body.dark {
            background-color: #121212;
            color: #e0e0e0;
        }
        
        body.dark .main-content {
            background-color: #121212;
        }
        
        body.dark .chart-section,
        body.dark .chart-card,
        body.dark .kpi-card,
        body.dark .forum-post {
            background-color: #1e1e1e;
            color: #e0e0e0;
        }
        
        body.dark .chart-section h2 {
            color: #e0e0e0;
            border-bottom-color: #444;
        }
        
        body.dark .kpi-label {
            color: #b0b0b0;
        }
        
        body.dark select,
        body.dark input,
        body.dark textarea {
            background-color: #2d2d2d;
            color: #e0e0e0;
            border-color: #444;
        }
        
        body.dark .user-table th,
        body.dark .user-table td {
            border-color: #444;
        }
        
        body.dark .user-table th {
            background-color: #2d2d2d;
        }
    </style>
</head>
<body class="<?php echo $_SESSION['user']['mode']; ?>">
    <div class="sidebar">
        <div class="logo-container">
            <img src="icon.jpg" alt="Commonwealth Logo" class="logo">
            <div class="user-info">
                <span>[Profile Pic: <?php echo $_SESSION['user']['username']; ?>]</span>
                <p><?php echo $_SESSION['user']['username']; ?> (<?php echo $_SESSION['user']['role']; ?>) 
                   <span data-theme="<?php echo $_SESSION['user']['theme']; ?>" 
                         data-country="<?php echo $_SESSION['user']['country']; ?>"></span></p>
            </div>
        </div>
        <nav>
            <a href="index.php" class="active">Overview</a>
            <a href="../ECONOMIC GROWTH/economics.php">Economic Growth</a>
            <a href="../SMALL CITIES/sids.html">SIDS</a>
            <a href="../CLIMATE/climate.html">Climate And Oceans</a>
            <a href="../YOUTH/youth.html">Youth</a>
            <a href="../GOVERNANCE/governance.html">Governance And Peace</a>
            <a href="../HEALTH/health.php">Health</a>
            <a href="../EDUCATION/education.php">Education</a>
            <a href="admin_create_user.php">Create new User</a>
            <a href="../SETTINGS/settings.php">Settings</a>
            <a href="../SETTINGS/logout.php">Logout</a>
        </nav>
    </div>
    <div class="main-content">
        <h1>Commonwealth Dashboard</h1>
        
        <!-- User Management Section (Visible only to System Admin after verification) -->
        <div id="userManagementSection" style="display: none;">
            <h2>User Management</h2>
            <button onclick="showAddUserForm()">Add New User</button>
            
            <div id="addUserForm" class="user-form" style="display: none;">
                <h3>Add User</h3>
                <form id="userForm">
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" id="username" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="email" id="email" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" id="password" required>
                    </div>
                    <div class="form-group">
                        <label for="role">Role</label>
                        <select id="role" required onchange="toggleRoleFields()">
                            <option value="">Select Role</option>
                            <option value="Theme Admin">Theme Admin</option>
                            <option value="Project Manager">Project Manager</option>
                            <option value="Field Officer">Field Officer</option>
                            <option value="Data Analyst">Data Analyst</option>
                            <option value="Partner">Partner</option>
                        </select>
                    </div>
                    <div class="form-group" id="themeGroup" style="display: none;">
                        <label for="theme">Theme</label>
                        <select id="theme">
                            <option value="all">All Themes</option>
                            <option value="ECONOMIC GROWTH">Economic Growth</option>
                            <option value="SMALL CITIES">Small Cities</option>
                            <option value="CLIMATE">Climate And Oceans</option>
                            <option value="YOUTH">Youth</option>
                            <option value="GOVERNANCE">Governance And Peace</option>
                            <option value="HEALTH">Health</option>
                            <option value="EDUCATION">Education</option>
                        </select>
                    </div>
                    <div class="form-group" id="countryGroup" style="display: none;">
                        <label for="country">Country</label>
                        <select id="country">
                            <?php
                            $countries = [
                                'ATG' => 'Antigua and Barbuda', 'AUS' => 'Australia', 'BHS' => 'Bahamas', 'BGD' => 'Bangladesh', 'BRB' => 'Barbados',
                                'BWA' => 'Botswana', 'BRN' => 'Brunei', 'CAN' => 'Canada', 'CMR' => 'Cameroon', 'CYP' => 'Cyprus',
                                'DMA' => 'Dominica', 'FJI' => 'Fiji', 'GMB' => 'Gambia', 'GHA' => 'Ghana', 'GRD' => 'Grenada',
                                'GUY' => 'Guyana', 'IND' => 'India', 'JAM' => 'Jamaica', 'KEN' => 'Kenya', 'KIR' => 'Kiribati',
                                'LSO' => 'Lesotho', 'MWI' => 'Malawi', 'MYS' => 'Malaysia', 'MDV' => 'Maldives', 'MLT' => 'Malta',
                                'MUS' => 'Mauritius', 'MOZ' => 'Mozambique', 'NAM' => 'Namibia', 'NRU' => 'Nauru', 'NZL' => 'New Zealand',
                                'NGA' => 'Nigeria', 'PAK' => 'Pakistan', 'PNG' => 'Papua New Guinea', 'RWA' => 'Rwanda', 'KNA' => 'Saint Kitts and Nevis',
                                'LCA' => 'Saint Lucia', 'VCT' => 'Saint Vincent and the Grenadines', 'WSM' => 'Samoa', 'SYC' => 'Seychelles', 'SLE' => 'Sierra Leone',
                                'SGP' => 'Singapore', 'SLB' => 'Solomon Islands', 'ZAF' => 'South Africa', 'LKA' => 'Sri Lanka', 'SWZ' => 'Eswatini',
                                'TZA' => 'Tanzania', 'TON' => 'Tonga', 'TTO' => 'Trinidad and Tobago', 'TUV' => 'Tuvalu', 'UGA' => 'Uganda',
                                'GBR' => 'United Kingdom', 'VUT' => 'Vanuatu', 'ZMB' => 'Zambia', 'ZWE' => 'Zimbabwe'
                            ];
                            foreach ($countries as $code => $name) {
                                echo "<option value='$code'>$name</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <button type="submit">Save User</button>
                </form>
            </div>
            
            <table class="user-table">
                <thead>
                    <tr>
                        <th>Username</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Theme/Country</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="userTableBody">
                    <!-- Users will be loaded here dynamically -->
                </tbody>
            </table>
        </div>

        <div class="controls">
            <select id="countryFilter">
                <option value="all">All Countries</option>
                <?php
                foreach ($countries as $code => $name) {
                    echo "<option value='$code'>$name</option>";
                }
                ?>
            </select>
            <select id="chartType">
                <option value="bar">Bar Chart</option>
                <option value="pie">Pie Chart</option>
                <option value="line">Line Chart</option>
                <option value="radar">Radar Chart</option>
            </select>
            <select id="yearFilter">
                <option value="2023">2023</option>
                <option value="2022">2022</option>
                <option value="2021">2021</option>
                <option value="2020">2020</option>
            </select>
            <button onclick="filterData()">Apply Filters</button>
            <button onclick="exportData('csv')">Export Data</button>
            <button onclick="generateReport()">Generate Report</button>
        </div>
        
        <main class="dashboard-main">
            <section id="overview" class="dashboard-section active">
                <div class="charts-container">
                    <!-- Economic Indicators -->
                    <section class="chart-section">
                        <h2>Economic Indicators</h2>
                        <div class="chart-grid">
                            <div class="chart-card">
                                <h3 class="chart-title">Poverty Rate (% of population)</h3>
                                <canvas id="povertyChart" height="300"></canvas>
                            </div>
                            <div class="chart-card">
                                <h3 class="chart-title">Exports (Billion USD)</h3>
                                <canvas id="exportsChart" height="300"></canvas>
                            </div>
                            <div class="chart-card">
                                <h3 class="chart-title">Foreign Direct Investment (Billion USD)</h3>
                                <canvas id="fdiChart" height="300"></canvas>
                            </div>
                        </div>
                    </section>
                    
                    <!-- Climate Indicators -->
                    <section class="chart-section">
                        <h2>Climate Indicators</h2>
                        <div class="chart-grid">
                            <div class="chart-card">
                                <h3 class="chart-title">Climate Adaptation Index</h3>
                                <canvas id="adaptationChart" height="300"></canvas>
                            </div>
                            <div class="chart-card">
                                <h3 class="chart-title">Climate Mitigation Index</h3>
                                <canvas id="mitigationChart" height="300"></canvas>
                            </div>
                            <div class="chart-card">
                                <h3 class="chart-title">Climate Resilience Index</h3>
                                <canvas id="resilienceChart" height="300"></canvas>
                            </div>
                            <div class="chart-card">
                                <h3 class="chart-title">CO2 Emissions (metric tons per capita)</h3>
                                <canvas id="emissionsChart" height="300"></canvas>
                            </div>
                            <div class="chart-card">
                                <h3 class="chart-title">Renewable Energy (% of total)</h3>
                                <canvas id="renewablesChart" height="300"></canvas>
                            </div>
                            <div class="chart-card">
                                <h3 class="chart-title">Climate Finance Received (Million USD)</h3>
                                <canvas id="climateFinanceChart" height="300"></canvas>
                            </div>
                        </div>
                    </section>
                    
                    <!-- Youth Indicators -->
                    <section class="chart-section">
                        <h2>Youth Indicators</h2>
                        <div class="chart-grid">
                            <div class="chart-card">
                                <h3 class="chart-title">Youth Employment Rate (%)</h3>
                                <canvas id="youthEmploymentChart" height="300"></canvas>
                            </div>
                            <div class="chart-card">
                                <h3 class="chart-title">Youth Participation Rate (%)</h3>
                                <canvas id="participationChart" height="300"></canvas>
                            </div>
                        </div>
                    </section>
                    
                    <!-- Education Indicators -->
                    <section class="chart-section">
                        <h2>Education Indicators</h2>
                        <div class="chart-grid">
                            <div class="chart-card">
                                <h3 class="chart-title">School Enrollment Rate (%)</h3>
                                <canvas id="enrollmentChart" height="300"></canvas>
                            </div>
                            <div class="chart-card">
                                <h3 class="chart-title">Literacy Rate (%)</h3>
                                <canvas id="literacyChart" height="300"></canvas>
                            </div>
                            <div class="chart-card">
                                <h3 class="chart-title">STEM Graduates (% of total)</h3>
                                <canvas id="stemChart" height="300"></canvas>
                            </div>
                            <div class="chart-card">
                                <h3 class="chart-title">Digital Learning Access (%)</h3>
                                <canvas id="digitalLearningChart" height="300"></canvas>
                            </div>
                        </div>
                    </section>
                    
                    <!-- Health Indicators -->
                    <section class="chart-section">
                        <h2>Health Indicators</h2>
                        <div class="chart-grid">
                            <div class="chart-card">
                                <h3 class="chart-title">Maternal Mortality Rate (per 100,000)</h3>
                                <canvas id="maternalChart" height="300"></canvas>
                            </div>
                            <div class="chart-card">
                                <h3 class="chart-title">Vaccination Coverage (%)</h3>
                                <canvas id="vaccinationChart" height="300"></canvas>
                            </div>
                            <div class="chart-card">
                                <h3 class="chart-title">Healthcare Access Index</h3>
                                <canvas id="healthcareChart" height="300"></canvas>
                            </div>
                        </div>
                    </section>
                    
                    <!-- Additional Charts -->
                    <section class="chart-section">
                        <h2>Additional Charts</h2>
                        <div class="chart-grid">
                            <div class="chart-card">
                                <h3 class="chart-title">Project Timeline</h3>
                                <canvas id="ganttChart" height="300"></canvas>
                            </div>
                            <div class="chart-card">
                                <h3 class="chart-title">Thematic Distribution</h3>
                                <canvas id="pieChart" height="300"></canvas>
                            </div>
                        </div>
                    </section>
                </div>
            </section>
        </main>
        
        <div id="reportOutput" class="chart-card" style="margin-top: 30px; display: none;"></div>
        
        <form id="uploadForm" enctype="multipart/form-data" class="chart-card" style="margin-top: 30px; padding: 20px;">
            <h3>Upload Data</h3>
            <div class="form-group">
                <input type="file" name="document" accept=".csv,.xlsx,.xls" required>
            </div>
            <div class="form-group">
                <select name="dataType" required>
                    <option value="">Select Data Type</option>
                    <option value="poverty">Poverty</option>
                    <option value="exports">Exports</option>
                    <option value="fdi">FDI</option>
                    <option value="adaptation">Adaptation</option>
                    <option value="mitigation">Mitigation</option>
                    <option value="resilience">Resilience</option>
                    <option value="emissions">Emissions</option>
                    <option value="renewables">Renewables</option>
                    <option value="climateFinance">Climate Finance</option>
                    <option value="youthEmployment">Youth Employment</option>
                    <option value="enrollment">Enrollment</option>
                    <option value="participation">Participation</option>
                    <option value="literacy">Literacy</option>
                    <option value="stem">STEM</option>
                    <option value="digitalLearning">Digital Learning</option>
                    <option value="maternal">Maternal</option>
                    <option value="vaccination">Vaccination</option>
                    <option value="healthcare">Healthcare</option>
                </select>
            </div>
            <div class="form-group">
                <select name="country" id="uploadCountry" required>
                    <option value="all">All Countries</option>
                    <?php foreach ($countries as $code => $name) {
                        echo "<option value='$code'>$name</option>";
                    } ?>
                </select>
            </div>
            <input type="hidden" name="dashboard" value="all">
            <button type="submit">Upload Document</button>
        </form>
        
        <div id="analysisResults" class="chart-card" style="margin-top: 30px; padding: 20px;"></div>
        
        <div class="chart-card" style="margin-top: 30px; padding: 20px;">
            <h3>Discussion Forum</h3>
            <form id="forumForm">
                <div class="form-group">
                    <textarea name="content" placeholder="Post a comment..." required></textarea>
                </div>
                <button type="submit">Post</button>
            </form>
            <div id="forumPosts" style="margin-top: 20px;"></div>
        </div>
        
        <div class="chart-card" style="margin-top: 30px; padding: 20px;">
            <h3>Activity Log</h3>
            <div id="activityLog"></div>
        </div>
        
        <div id="locationData" class="chart-card" style="margin-top: 30px; padding: 20px;"></div>

        <!-- Admin Verification Modal -->
        <div id="adminCodeModal" class="modal" style="display: none;">
            <div class="modal-content">
                <span class="close" onclick="closeAdminModal()">×</span>
                <h2>Admin Verification</h2>
                <p>Please enter your admin secret code to proceed:</p>
                <input type="password" id="adminSecretCode" placeholder="Enter secret code">
                <button onclick="verifyAdminCode()">Submit</button>
            </div>
        </div>

        <!-- User Activity Modal -->
        <div id="userActivityModal" class="modal" style="display: none;">
            <div class="modal-content">
                <span class="close" onclick="closeActivityModal()">×</span>
                <h2>User Activity</h2>
                <div id="activityContent"></div>
            </div>
        </div>

        <script>
            // JavaScript code remains unchanged
            const user = <?php echo json_encode($_SESSION['user'] ?? []); ?>;
            const countries = <?php echo json_encode($countries); ?>;
            
            const chartColors = [
                '#1a3e72', '#ffd700', '#2e8b57', '#b22234', '#6cb4ee', '#8a2be2',
                '#ff6347', '#20b2aa', '#daa520', '#778899', '#ff69b4', '#3cb371',
                '#4169e1', '#d2691e', '#9370db', '#ff4500', '#32cd32', '#ba55d3',
                '#4682b4', '#9acd32'
            ];
            
            function initDashboard() {
                const role = user.role;
                switch(role) {
                    case 'System Admin':
                        break;
                    case 'Theme Admin':
                        document.getElementById('userManagementSection').style.display = 'none';
                        break;
                    case 'Project Manager':
                        document.getElementById('ganttChart').style.display = 'block';
                        break;
                    case 'Field Officer':
                        document.getElementById('uploadForm').style.display = 'block';
                        break;
                    case 'Data Analyst':
                        document.getElementById('exportData').style.display = 'block';
                        document.getElementById('uploadForm').style.display = 'none';
                        break;
                    case 'Partner':
                        document.getElementById('uploadForm').style.display = 'none';
                        break;
                }
                loadAllCharts();
            }
            
            function toggleRoleFields() {
                const role = document.getElementById('role').value;
                document.getElementById('themeGroup').style.display = role === 'Theme Admin' ? 'block' : 'none';
                document.getElementById('countryGroup').style.display = role === 'Field Officer' ? 'block' : 'none';
            }
            
            function showAddUserForm() {
                document.getElementById('addUserForm').style.display = 'block';
            }
            
            function loadUsers() {
                const mockUsers = [
                    { id: 1, username: 'admin1', email: 'admin1@commonwealth.org', role: 'Theme Admin', theme: 'ECONOMIC GROWTH', country: '' },
                    { id: 2, username: 'pm1', email: 'pm1@commonwealth.org', role: 'Project Manager', theme: '', country: '' },
                    { id: 3, username: 'field1', email: 'field1@commonwealth.org', role: 'Field Officer', theme: '', country: 'KEN' },
                    { id: 4, username: 'analyst1', email: 'analyst1@commonwealth.org', role: 'Data Analyst', theme: '', country: '' },
                    { id: 5, username: 'partner1', email: 'partner1@org.org', role: 'Partner', theme: '', country: '' }
                ];
                
                const tbody = document.getElementById('userTableBody');
                tbody.innerHTML = '';
                
                mockUsers.forEach(user => {
                    const themeOrCountry = user.role === 'Theme Admin' ? user.theme : 
                                         (user.role === 'Field Officer' ? countries[user.country] : 'N/A');
                    const row = `
                        <tr>
                            <td>${user.username}</td>
                            <td>${user.email}</td>
                            <td>${user.role}</td>
                            <td>${themeOrCountry}</td>
                            <td>
                                <button onclick="editUser(${user.id})">Edit</button>
                                <button onclick="deleteUser(${user.id})">Delete</button>
                                <button onclick="showActivityModal(${user.id})">Activity</button>
                            </td>
                        </tr>
                    `;
                    tbody.insertAdjacentHTML('beforeend', row);
                });
            }
            
            function saveUser(e) {
                e.preventDefault();
                const username = document.getElementById('username').value;
                const email = document.getElementById('email').value;
                const password = document.getElementById('password').value;
                const role = document.getElementById('role').value;
                const theme = document.getElementById('theme').value;
                const country = document.getElementById('country').value;
                
                if (!username || !email || !password || !role) {
                    alert('Please fill all required fields');
                    return;
                }
                
                console.log('Saving user:', { username, email, role, theme, country });
                alert('User saved successfully');
                document.getElementById('userForm').reset();
                document.getElementById('addUserForm').style.display = 'none';
                loadUsers();
                logActivity(`Added new user: ${username} (${role})`);
            }
            
            function editUser(id) {
                console.log('Editing user with ID:', id);
                document.getElementById('addUserForm').style.display = 'block';
                document.getElementById('userForm').scrollIntoView();
                logActivity(`Edited user with ID: ${id}`);
            }
            
            function deleteUser(id) {
                if (confirm('Are you sure you want to delete this user?')) {
                    console.log('Deleting user with ID:', id);
                    alert('User deleted successfully');
                    loadUsers();
                    logActivity(`Deleted user with ID: ${id}`);
                }
            }
            
            function showAdminModal() {
                document.getElementById('adminCodeModal').style.display = 'block';
            }
            
            function closeAdminModal() {
                document.getElementById('adminCodeModal').style.display = 'none';
            }
            
            function verifyAdminCode() {
                const code = document.getElementById('adminSecretCode').value;
                if (code === 'Commonwealth2023') {
                    document.getElementById('userManagementSection').style.display = 'block';
                    closeAdminModal();
                    loadUsers();
                } else {
                    alert('Invalid admin code');
                }
            }
            
            function showActivityModal(userId) {
                document.getElementById('activityContent').innerHTML = `
                    <h3>Activity for User ID: ${userId}</h3>
                    <ul>
                        <li>2023-05-01 10:30 - Logged in</li>
                        <li>2023-05-01 11:15 - Viewed dashboard</li>
                        <li>2023-05-01 12:30 - Uploaded data</li>
                        <li>2023-05-01 14:45 - Logged out</li>
                    </ul>
                `;
                document.getElementById('userActivityModal').style.display = 'block';
            }
            
            function closeActivityModal() {
                document.getElementById('userActivityModal').style.display = 'none';
            }
            
            function loadKPIData() {
                const kpiData = [
                    { name: 'Active Projects', value: 24, change: '+2%' },
                    { name: 'Data Entries', value: 1563, change: '+15%' },
                    { name: 'Countries Active', value: 56, change: '0%' },
                    { name: 'Themes Covered', value: 7, change: '0%' },
                    { name: 'Users Online', value: 8, change: '-1%' }
                ];
                
                const kpiDashboard = document.getElementById('kpiDashboard');
                if (kpiDashboard) {
                    kpiDashboard.innerHTML = kpiData.map(kpi => `
                        <div class="kpi-card">
                            <div class="kpi-label">${kpi.name}</div>
                            <div class="kpi-value">${kpi.value}</div>
                            <div class="kpi-change ${kpi.change.includes('-') ? 'negative' : ''}">${kpi.change}</div>
                        </div>
                    `).join('');
                }
            }
            
            function loadAllCharts() {
                createBarChart('povertyChart', 'Poverty Rate (% of population)', 
                    ['India', 'Nigeria', 'Bangladesh', 'Kenya', 'Ghana'], 
                    [21.9, 40.1, 24.3, 36.1, 23.4], '%');
                createLineChart('exportsChart', 'Exports (Billion USD)', 
                    ['2020', '2021', '2022'], 
                    [
                        {label: 'India', data: [275, 395, 420]},
                        {label: 'Nigeria', data: [45, 52, 48]},
                        {label: 'Australia', data: [250, 310, 290]}
                    ], 'B USD');
                createPieChart('fdiChart', 'Foreign Direct Investment (Billion USD)', 
                    ['UK', 'India', 'Singapore', 'South Africa'], 
                    [1500, 64, 110, 5], 'B USD');
                createRadarChart('adaptationChart', 'Climate Adaptation Index (0-100)', 
                    ['Canada', 'Maldives', 'Kenya'], 
                    [75, 60, 55], 'points');
                createRadarChart('mitigationChart', 'Climate Mitigation Index (0-100)', 
                    ['Canada', 'Maldives', 'Kenya'], 
                    [80, 45, 50], 'points');
                createRadarChart('resilienceChart', 'Climate Resilience Index (0-100)', 
                    ['Canada', 'Maldives', 'Kenya'], 
                    [78, 50, 58], 'points');
                createBarChart('emissionsChart', 'CO2 Emissions (metric tons per capita)', 
                    ['USA', 'India', 'UK'], 
                    [15.5, 1.9, 5.6], 'tons');
                createStackedBarChart('renewablesChart', 'Renewable Energy (% of total)', 
                    ['Germany', 'India'], 
                    [
                        {label: 'Solar', data: [10, 5]},
                        {label: 'Wind', data: [25, 8]},
                        {label: 'Hydro', data: [5, 12]}
                    ], '%');
                createAreaChart('climateFinanceChart', 'Climate Finance Received (Million USD)', 
                    ['2020', '2021'], 
                    [
                        {label: 'SIDS', data: [2.1, 2.5]},
                        {label: 'Africa', data: [5.3, 6.0]}
                    ], 'M USD');
                createBarChart('youthEmploymentChart', 'Youth Employment Rate (%)', 
                    ['UK', 'Ghana'], 
                    [75, 50], '%');
                createBarChart('enrollmentChart', 'School Enrollment Rate (%)', 
                    ['India', 'Nigeria', 'Bangladesh', 'Kenya', 'Ghana'], 
                    [92, 85, 89, 78, 83], '%');
                createBarChart('participationChart', 'Youth Participation Rate (%)', 
                    ['UK', 'Ghana'], 
                    [65, 45], '%');
                createBarChart('literacyChart', 'Literacy Rate (%)', 
                    ['India', 'Nigeria', 'Bangladesh', 'Kenya', 'Ghana'], 
                    [74, 62, 72, 78, 76], '%');
                createBarChart('stemChart', 'STEM Graduates (% of total)', 
                    ['UK', 'Ghana'], 
                    [30, 15], '%');
                createBarChart('digitalLearningChart', 'Digital Learning Access (%)', 
                    ['India', 'Nigeria', 'Bangladesh', 'Kenya', 'Ghana'], 
                    [65, 58, 62, 59, 63], '%');
                createBarChart('maternalChart', 'Maternal Mortality Rate (per 100,000)', 
                    ['Canada', 'Pakistan'], 
                    [8, 140], 'per 100k');
                createBarChart('vaccinationChart', 'Vaccination Coverage (%)', 
                    ['Canada', 'Pakistan'], 
                    [95, 65], '%');
                createBarChart('healthcareChart', 'Healthcare Access Index (0-100)', 
                    ['Canada', 'Pakistan'], 
                    [92, 48], 'points');
                createGanttChart();
                createThematicPieChart();
            }

            function createBarChart(canvasId, label, labels, data, unit = '') {
                const ctx = document.getElementById(canvasId).getContext('2d');
                if (window[canvasId + 'Instance']) {
                    window[canvasId + 'Instance'].destroy();
                }
                window[canvasId + 'Instance'] = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: `${label} (${unit})`,
                            data: data,
                            backgroundColor: labels.map((_, i) => chartColors[i % chartColors.length]),
                            borderColor: labels.map((_, i) => chartColors[i % chartColors.length]),
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: {
                                beginAtZero: true,
                                title: { display: true, text: unit }
                            }
                        },
                        plugins: {
                            legend: { display: false },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return `${context.label}: ${context.raw} ${unit}`;
                                    }
                                }
                            }
                        }
                    }
                });
            }

            function createLineChart(canvasId, label, labels, datasets, unit = '') {
                const ctx = document.getElementById(canvasId).getContext('2d');
                if (window[canvasId + 'Instance']) {
                    window[canvasId + 'Instance'].destroy();
                }
                const chartDatasets = datasets.map((dataset, i) => ({
                    label: dataset.label,
                    data: dataset.data,
                    borderColor: chartColors[i % chartColors.length],
                    backgroundColor: chartColors[i % chartColors.length],
                    borderWidth: 2,
                    fill: false
                }));
                window[canvasId + 'Instance'] = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: chartDatasets
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: { beginAtZero: true, title: { display: true, text: unit } }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return `${context.dataset.label}: ${context.raw} ${unit}`;
                                    }
                                }
                            }
                        }
                    }
                });
            }

            function createPieChart(canvasId, label, labels, data, unit = '') {
                const ctx = document.getElementById(canvasId).getContext('2d');
                if (window[canvasId + 'Instance']) {
                    window[canvasId + 'Instance'].destroy();
                }
                window[canvasId + 'Instance'] = new Chart(ctx, {
                    type: 'pie',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: `${label} (${unit})`,
                            data: data,
                            backgroundColor: labels.map((_, i) => chartColors[i % chartColors.length]),
                            borderColor: '#fff',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { position: 'right' },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        const total = context.dataset.data.reduce((acc, val) => acc + val, 0);
                                        const value = context.raw;
                                        const percentage = Math.round((value / total) * 100);
                                        return `${context.label}: ${value} ${unit} (${percentage}%)`;
                                    }
                                }
                            }
                        }
                    }
                });
            }

            function createRadarChart(canvasId, label, labels, data, unit = '') {
                const ctx = document.getElementById(canvasId).getContext('2d');
                if (window[canvasId + 'Instance']) {
                    window[canvasId + 'Instance'].destroy();
                }
                window[canvasId + 'Instance'] = new Chart(ctx, {
                    type: 'radar',
                    data: {
                        labels: labels,
                        datasets: [{
                            label: `${label} (${unit})`,
                            data: data,
                            backgroundColor: 'rgba(26, 62, 114, 0.2)',
                            borderColor: '#1a3e72',
                            borderWidth: 2,
                            pointBackgroundColor: '#1a3e72',
                            pointBorderColor: '#fff',
                            pointHoverBackgroundColor: '#fff',
                            pointHoverBorderColor: '#1a3e72'
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            r: { angleLines: { display: true }, suggestedMin: 0, suggestedMax: 100 }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return `${context.label}: ${context.raw} ${unit}`;
                                    }
                                }
                            }
                        }
                    }
                });
            }

            function createStackedBarChart(canvasId, label, labels, datasets, unit = '') {
                const ctx = document.getElementById(canvasId).getContext('2d');
                if (window[canvasId + 'Instance']) {
                    window[canvasId + 'Instance'].destroy();
                }
                const chartDatasets = datasets.map((dataset, i) => ({
                    label: dataset.label,
                    data: dataset.data,
                    backgroundColor: chartColors[i % chartColors.length],
                    borderColor: chartColors[i % chartColors.length],
                    borderWidth: 1
                }));
                window[canvasId + 'Instance'] = new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: labels,
                        datasets: chartDatasets
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            x: { stacked: true },
                            y: { stacked: true, beginAtZero: true, title: { display: true, text: unit } }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return `${context.dataset.label}: ${context.raw} ${unit}`;
                                    }
                                }
                            }
                        }
                    }
                });
            }

            function createAreaChart(canvasId, label, labels, datasets, unit = '') {
                const ctx = document.getElementById(canvasId).getContext('2d');
                if (window[canvasId + 'Instance']) {
                    window[canvasId + 'Instance'].destroy();
                }
                const chartDatasets = datasets.map((dataset, i) => ({
                    label: dataset.label,
                    data: dataset.data,
                    backgroundColor: `${chartColors[i % chartColors.length]}33`,
                    borderColor: chartColors[i % chartColors.length],
                    borderWidth: 2,
                    fill: true
                }));
                window[canvasId + 'Instance'] = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: labels,
                        datasets: chartDatasets
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            y: { beginAtZero: true, title: { display: true, text: unit } }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return `${context.dataset.label}: ${context.raw} ${unit}`;
                                    }
                                }
                            }
                        }
                    }
                });
            }

            function createGanttChart() {
                const ctx = document.getElementById('ganttChart').getContext('2d');
                const projects = [
                    { name: 'Economic Survey', start: 1, end: 10, color: chartColors[0] },
                    { name: 'Climate Study', start: 5, end: 15, color: chartColors[1] },
                    { name: 'Youth Program', start: 8, end: 20, color: chartColors[2] },
                    { name: 'Health Initiative', start: 12, end: 25, color: chartColors[3] },
                    { name: 'Education Reform', start: 18, end: 30, color: chartColors[4] }
                ];
                new Chart(ctx, {
                    type: 'bar',
                    data: {
                        labels: projects.map(p => p.name),
                        datasets: [{
                            label: 'Project Duration (days)',
                            data: projects.map(p => p.end - p.start),
                            backgroundColor: projects.map(p => p.color),
                            borderColor: projects.map(p => p.color),
                            borderWidth: 1,
                            barPercentage: 0.5
                        }]
                    },
                    options: {
                        indexAxis: 'y',
                        responsive: true,
                        maintainAspectRatio: false,
                        scales: {
                            x: { beginAtZero: true, max: 35, title: { display: true, text: 'Days' } }
                        },
                        plugins: {
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        const project = projects[context.dataIndex];
                                        return `${project.name}: Day ${project.start} to ${project.end} (${context.raw} days)`;
                                    }
                                }
                            }
                        }
                    }
                });
            }

            function createThematicPieChart() {
                const ctx = document.getElementById('pieChart').getContext('2d');
                const themes = [
                    { name: 'Economic Growth', value: 35 },
                    { name: 'Youth & Gender', value: 25 },
                    { name: 'Governance', value: 20 },
                    { name: 'Climate', value: 15 },
                    { name: 'Health', value: 5 }
                ];
                new Chart(ctx, {
                    type: 'pie',
                    data: {
                        labels: themes.map(t => t.name),
                        datasets: [{
                            data: themes.map(t => t.value),
                            backgroundColor: themes.map((_, i) => chartColors[i % chartColors.length]),
                            borderColor: '#fff',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: {
                            legend: { position: 'right' },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        const total = context.dataset.data.reduce((acc, val) => acc + val, 0);
                                        const value = context.raw;
                                        const percentage = Math.round((value / total) * 100);
                                        return `${context.label}: ${value}% (${percentage}%)`;
                                    }
                                }
                            }
                        }
                    }
                });
            }
            
            function filterData() {
                const country = document.getElementById('countryFilter').value;
                const year = document.getElementById('yearFilter').value;
                console.log('Filtering data for country:', country, 'and year:', year);
                loadKPIData();
                loadAllCharts();
                logActivity(`Filtered data by country: ${country === 'all' ? 'All Countries' : countries[country]} and year: ${year}`);
            }
            
            function generateReport() {
                const reportOutput = document.getElementById('reportOutput');
                reportOutput.style.display = 'block';
                reportOutput.innerHTML = `
                    <h3>Commonwealth Comprehensive Report</h3>
                    <p>Generated on ${new Date().toLocaleString()}</p>
                    <p>This report contains data for all 56 Commonwealth nations across all indicators.</p>
                    <h4>Key Findings</h4>
                    <ul>
                        <li>Average poverty rate across Commonwealth: 23.4%</li>
                        <li>Total exports: $1.2 trillion USD</li>
                        <li>Average climate adaptation index: 65.2 points</li>
                        <li>Youth employment rate: 58.7%</li>
                        <li>Average literacy rate: 82.3%</li>
                    </ul>
                    <h4>Recommendations</h4>
                    <ol>
                        <li>Increase investment in climate adaptation for small island states</li>
                        <li>Expand digital learning initiatives to improve education access</li>
                        <li>Develop targeted youth employment programs</li>
                        <li>Strengthen healthcare systems in developing member states</li>
                    </ol>
                    <div style="margin-top: 20px;">
                        <button onclick="window.print()">Print Report</button>
                        <button onclick="exportReport('pdf')">Export as PDF</button>
                    </div>
                `;
                logActivity('Generated comprehensive report');
            }
            
            function exportReport(format) {
                console.log(`Exporting report as ${format}`);
                alert(`Report exported as ${format.toUpperCase()} successfully`);
                logActivity(`Exported report as ${format.toUpperCase()}`);
            }
            
            function exportData(format) {
                console.log(`Exporting data as ${format}`);
                alert(`Data exported as ${format.toUpperCase()} successfully`);
                logActivity(`Exported data as ${format.toUpperCase()}`);
            }
            
            function handleFileUpload(e) {
                e.preventDefault();
                const formData = new FormData(e.target);
                const dataType = formData.get('dataType');
                const country = formData.get('country');
                console.log('Uploading file for:', dataType, 'in', country);
                alert('File uploaded successfully. Data will be processed shortly.');
                e.target.reset();
                logActivity(`Uploaded ${dataType} data for ${country === 'all' ? 'all countries' : countries[country]}`);
            }
            
            function postForumComment(e) {
                e.preventDefault();
                const content = e.target.content.value;
                console.log('Posting forum comment:', content);
                const forumPosts = document.getElementById('forumPosts');
                const postHTML = `
                    <div class="forum-post">
                        <p><strong>${user.username}</strong> (${new Date().toLocaleString()}):</p>
                        <p>${content}</p>
                    </div>
                `;
                forumPosts.insertAdjacentHTML('afterbegin', postHTML);
                e.target.reset();
                logActivity('Posted forum comment');
            }
            
            function trackLocation() {
                if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition(
                        position => {
                            const { latitude, longitude } = position.coords;
                            document.getElementById('locationData').innerHTML = `
                                <p>Your current location: Latitude ${latitude.toFixed(4)}, Longitude ${longitude.toFixed(4)}</p>
                                <p>This information can be used to provide location-specific data and services.</p>
                            `;
                            logActivity('Tracked location');
                        },
                        error => {
                            console.error('Error getting location:', error);
                            alert('Unable to retrieve your location');
                        }
                    );
                } else {
                    alert('Geolocation is not supported by your browser');
                }
            }
            
            function logActivity(action) {
                const timestamp = new Date().toISOString();
                const activityLog = document.getElementById('activityLog');
                console.log(`[${timestamp}] ${user.username}: ${action}`);
                if (activityLog) {
                    const activityItem = document.createElement('p');
                    activityItem.textContent = `[${new Date(timestamp).toLocaleString()}] ${user.username}: ${action}`;
                    activityLog.appendChild(activityItem);
                }
            }
            
            document.addEventListener('DOMContentLoaded', function() {
                initDashboard();
                loadKPIData();
                document.getElementById('countryFilter').addEventListener('change', filterData);
                document.getElementById('chartType').addEventListener('change', loadAllCharts);
                document.getElementById('yearFilter').addEventListener('change', filterData);
                document.getElementById('uploadForm').addEventListener('submit', handleFileUpload);
                document.getElementById('forumForm').addEventListener('submit', postForumComment);
                document.getElementById('userForm')?.addEventListener('submit', saveUser);
                if (user.role === 'System Admin') {
                    showAdminModal();
                }
            });
            
            if ('serviceWorker' in navigator) {
                navigator.serviceWorker.register('/sw.js');
            }
        </script>
    </div>
</body>
</html>