<?php
session_start();

// Database connection - using a more reliable path
require_once __DIR__ . '/../DATABASE/db_connect.php';

if (isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $secret_code = $_POST['secret_code'];
    $sql = "SELECT * FROM users WHERE username = 'admin' AND role = 'System Admin'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();
        if (password_verify($secret_code, $admin['password'])) {
            $_SESSION['user'] = $admin;
            header('Location: index.php');
            exit;
        } else {
            $error = "Invalid secret code";
        }
    } else {
        $error = "Admin account not found";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Verification - Commonwealth Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <link rel="manifest" href="/manifest.json">
</head>
<body>
    <div class="container">
        <h1>Admin Verification</h1>
        <form method="POST">
            <label for="secret_code">Secret Code:</label>
            <input type="password" id="secret_code" name="secret_code" required>
            <button type="submit">Verify</button>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
        </form>
    </div>
    <script>
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/sw.js');
        }
    </script>
</body>
</html>