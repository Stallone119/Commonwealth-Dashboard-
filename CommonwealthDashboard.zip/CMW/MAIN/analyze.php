<?php
session_start();
require_once 'db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] !== 'System Admin' && $_SESSION['user']['theme'] !== 'all')) {
    echo json_encode(['status' => 'error', 'error' => 'Access Denied']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $dataType = $_POST['dataType'] ?? '';
    $country = $_POST['country'] ?? 'all';
    $dashboardMap = [
        'poverty' => 'economic', 'exports' => 'economic', 'fdi' => 'economic',
        'adaptation' => 'sids', 'mitigation' => 'sids', 'resilience' => 'sids',
        'emissions' => 'climate', 'renewables' => 'climate', 'climateFinance' => 'climate',
        'youthEmployment' => 'youth', 'enrollment' => 'youth', 'participation' => 'youth',
        'literacy' => 'education', 'stem' => 'education', 'digitalLearning' => 'education',
        'maternal' => 'health', 'vaccination' => 'health', 'healthcare' => 'health'
    ];

    if (!isset($_FILES['document']) || !isset($dashboardMap[$dataType])) {
        echo json_encode(['status' => 'error', 'error' => 'Invalid input']);
        exit;
    }

    $dashboard = $dashboardMap[$dataType];
    $metric = $dataType;
    $value = rand(10, 100); // Mock value for demo
    $target = $value * 1.5;
    $year = 2025;
    $target_year = 2030;
    $baseline = 0.0;

    $sql = "INSERT INTO kpi_data (dashboard, metric, country, year, value, target, baseline, target_year) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('sssidddi', $dashboard, $metric, $country, $year, $value, $target, $baseline, $target_year);
    if ($stmt->execute()) {
        echo json_encode(['status' => 'success', 'message' => "Uploaded $dataType data for $country"]);
    } else {
        echo json_encode(['status' => 'error', 'error' => 'Failed to save data']);
    }
    $stmt->close();
}
$conn->close();
?>