<?php
require_once 'db_connect.php';
header('Content-Type: application/json');
session_start();

if (!isset($_SESSION['user'])) {
    echo json_encode(['error' => 'Unauthorized']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $user_id = $_SESSION['user']['id'];
    $activity = $data['activity'];
    $latitude = isset($data['latitude']) ? $data['latitude'] : null;
    $longitude = isset($data['longitude']) ? $data['longitude'] : null;
    $ip_address = $_SERVER['REMOTE_ADDR'];
    $sql = "INSERT INTO user_activity (user_id, activity, latitude, longitude, ip_address, created_at) VALUES (?, ?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('isdds', $user_id, $activity, $latitude, $longitude, $ip_address);
    $stmt->execute();
    echo json_encode(['status' => 'success']);
} else {
    $sql = "SELECT activity, created_at FROM user_activity WHERE user_id = ? ORDER BY created_at DESC";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('i', $_SESSION['user']['id']);
    $stmt->execute();
    $result = $stmt->get_result();
    $logs = $result->fetch_all(MYSQLI_ASSOC);
    echo json_encode($logs);
}
?>