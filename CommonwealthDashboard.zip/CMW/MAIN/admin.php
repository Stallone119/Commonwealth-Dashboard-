<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Commonwealth Dashboard - Admin Panel</title>
    <link rel="stylesheet" href="style.css">
    <link rel="manifest" href="/manifest.json">
</head>
<body>
    <div class="container">
        <h1>Admin Panel</h1>
        <nav>
            <a href="index.php">Dashboard</a>
            <a href="#" onclick="logout()">Logout</a>
        </nav>
        <h2>Manage Users</h2>
        <form id="createUserForm">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <label for="role">Role:</label>
            <select id="role" name="role" required>
                <option value="Thematic Admin">Thematic Admin</option>
                <option value="Program Manager">Program Manager</option>
                <option value="Field Officer">Field Officer</option>
                <option value="Data Analyst">Data Analyst</option>
                <option value="Partner">Partner</option>
            </select>
            <label for="country">Country:</label>
            <select id="country" name="country" required></select>
            <label for="theme">Theme:</label>
            <select id="theme" name="theme" required>
                <option value="economic">Economic</option>
                <option value="sids">SIDS</option>
                <option value="climate">Climate</option>
                <option value="youth">Youth</option>
                <option value="education">Education</option>
                <option value="health">Health</option>
            </select>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <label for="phone">Phone:</label>
            <input type="text" id="phone" name="phone" required>
            <label for="mode">Mode:</label>
            <select id="mode" name="mode">
                <option value="light">Light</option>
                <option value="dark">Dark</option>
            </select>
            <button type="submit">Create User</button>
        </form>
        <h3>Existing Users</h3>
        <table id="userTable">
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Country</th>
                    <th>Theme</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Mode</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody></tbody>
        </table>
        <div id="notificationArea"></div>
    </div>
    <script src="script.js"></script>
    <script>
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/sw.js');
        }
    </script>
</body>
</html>