<?php
session_start();
require_once 'db_connect.php';

if (isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf_token = $_POST['csrf_token'] ?? '';
    $password = $_POST['password'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $mode = $_POST['mode'] ?? '';

    // CSRF token validation
    if (!isset($_SESSION['csrf_token']) || $csrf_token !== $_SESSION['csrf_token']) {
        $error = "Invalid request";
    } elseif (strlen($password) < 8) {
        $error = "Password must be at least 8 characters";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format";
    } elseif (!preg_match('/^\+?[1-9]\d{1,14}$/', $phone)) {
        $error = "Invalid phone number";
    } elseif (!in_array($mode, ['light', 'dark'])) {
        $error = "Invalid theme mode";
    } else {
        // Check if admin exists
        $sql = "SELECT * FROM users WHERE username = 'admin' AND role = 'System Admin'";
        $result = $conn->query($sql);
        $admin_exists = $result->num_rows > 0;

        // Prepare admin data
        $username = 'admin';
        $role = 'System Admin';
        $country = 'all';
        $theme = 'all';
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Insert or update admin account
        if ($admin_exists) {
            $sql = "UPDATE users SET password = ?, email = ?, phone = ?, mode = ? WHERE username = ? AND role = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssss", $hashed_password, $email, $phone, $mode, $username, $role);
        } else {
            $sql = "INSERT INTO users (username, password, role, country, theme, email, phone, mode) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssss", $username, $hashed_password, $role, $country, $theme, $email, $phone, $mode);
        }

        if ($stmt->execute()) {
            $_SESSION['user'] = [
                'username' => $username,
                'role' => $role,
                'country' => $country,
                'theme' => $theme,
                'email' => $email,
                'phone' => $phone,
                'mode' => $mode
            ];
            header('Location: index.php');
            exit;
        } else {
            $error = "Failed to save admin account";
        }
        $stmt->close();
    }
}
$conn->close();

// CSRF token generation
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Creation - Commonwealth Dashboard</title>
    <link rel="stylesheet" href="style.css">
    <link rel="manifest" href="/manifest.json">
</head>
<body>
    <div class="container">
        <h1>Admin Creation</h1>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['csrf_token']); ?>">
            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <label for="phone">Phone Number:</label>
            <input type="text" id="phone" name="phone" required>
            <label for="mode">Theme Mode:</label>
            <select id="mode" name="mode" required>
                <option value="light">Light</option>
                <option value="dark">Dark</option>
            </select>
            <button type="submit">Create</button>
            <?php if (isset($error)) echo "<p class='error'>$error</p>"; ?>
        </form>
    </div>
    <script>
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('/sw.js');
        }
    </script>
</body>
</html>