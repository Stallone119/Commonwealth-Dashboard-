<?php
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['document'])) {
    $file = $_FILES['document'];
    $filename = $file['name'];
    $fileType = pathinfo($filename, PATHINFO_EXTENSION);

    // Mock analysis logic
    $analysis = [
        'filename' => $filename,
        'climateMentions' => rand(10, 50),
        'oceanMentions' => rand(5, 30),
        'sdgAlignment' => 'Goal 13: Climate Action, Goal 14: Life Below Water'
    ];

    if (in_array($fileType, ['docx', 'pdf', 'txt'])) {
        move_uploaded_file($file['tmp_name'], 'uploads/' . $filename);
        echo json_encode($analysis);
    } else {
        echo json_encode(['error' => 'Unsupported file type']);
    }
} else {
    echo json_encode(['error' => 'No file uploaded']);
}
?>