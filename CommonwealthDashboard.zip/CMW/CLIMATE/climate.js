// Commonwealth countries list
const commonwealthCountries = [
    "Antigua and Barbuda", "Australia", "Bahamas", "Bangladesh", "Barbados", "Belize", "Botswana", "Brunei",
    "Cameroon", "Canada", "Cyprus", "Dominica", "Eswatini", "Fiji", "Gabon", "Gambia", "Ghana", "Grenada",
    "Guyana", "India", "Jamaica", "Kenya", "Kiribati", "Lesotho", "Malawi", "Malaysia", "Maldives", "Malta",
    "Mauritius", "Mozambique", "Namibia", "Nauru", "New Zealand", "Nigeria", "Pakistan", "Papua New Guinea",
    "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "Seychelles",
    "Sierra Leone", "Singapore", "Solomon Islands", "South Africa", "Sri Lanka", "Tanzania", "Togo", "Tonga",
    "Trinidad and Tobago", "Tuvalu", "Uganda", "United Kingdom", "Vanuatu", "Zambia"
];

// Mock data for charts
const ndcData = {
    labels: ['2023', '2024', '2025', '2026', '2030'],
    datasets: [{
        label: 'Countries Supported',
        data: [10, 20, 30, 40, 50],
        backgroundColor: '#ffd700',
        borderColor: '#003087',
        borderWidth: 2
    }]
};

const plasticData = {
    labels: ['2023', '2024', '2025', '2026', '2027'],
    datasets: [{
        label: 'Plastic Pollution Reduction (%)',
        data: [5, 10, 15, 18, 20],
        backgroundColor: '#005566',
        borderColor: '#003087',
        borderWidth: 2
    }]
};

const marineData = {
    labels: ['2023', '2024', '2025', '2026', '2030'],
    datasets: [{
        label: 'Marine Area Conserved (%)',
        data: [10, 15, 20, 25, 30],
        backgroundColor: '#e6e6fa',
        borderColor: '#003087',
        borderWidth: 2
    }]
};

// Initialize Line Charts
const ctx1 = document.getElementById('ndcChart').getContext('2d');
new Chart(ctx1, {
    type: 'line',
    data: ndcData,
    options: { responsive: true }
});

const ctx2 = document.getElementById('plasticChart').getContext('2d');
new Chart(ctx2, {
    type: 'line',
    data: plasticData,
    options: { responsive: true }
});

const ctx3 = document.getElementById('marineChart').getContext('2d');
new Chart(ctx3, {
    type: 'line',
    data: marineData,
    options: { responsive: true }
});

// KPI Calculations
function calculateKPI(data, target, baseline, targetYear, currentYear) {
    const progress = ((data[data.length - 1] - baseline) / (target - baseline)) * 100;
    const yearsLeft = targetYear - currentYear;
    const annualProgressNeeded = (target - data[data.length - 1]) / yearsLeft;
    return { progress: progress.toFixed(2), annualProgressNeeded: annualProgressNeeded.toFixed(2) };
}

// Mock KPI Data Fetching
function fetchKPI() {
    const country = document.getElementById('countryFilter').value;
    const kpiDashboard = document.getElementById('kpiDashboard');
    
    // Mock data (replace with DeskTrack/Tableau API)
    const mockData = {
        ndc: [10, 20, 30],
        plastic: [5, 10, 15],
        marine: [10, 15, 20],
        mangroveHectares: 300,
        cleanupHours: 2000
    };

    const ndcKPI = calculateKPI(mockData.ndc, 50, 0, 2030, 2025);
    const plasticKPI = calculateKPI(mockData.plastic, 20, 0, 2027, 2025);
    const marineKPI = calculateKPI(mockData.marine, 30, 0, 2030, 2025);

    kpiDashboard.innerHTML = `
        <p><strong>${country === 'all' ? 'All Countries' : country}</strong></p>
        <p>NDC Implementation: ${mockData.ndc[mockData.ndc.length - 1]} countries 
           (Progress: ${ndcKPI.progress}% of target, ${ndcKPI.annualProgressNeeded} countries/year needed)</p>
        <p>Plastic Pollution Reduction: ${mockData.plastic[mockData.plastic.length - 1]}% 
           (Progress: ${plasticKPI.progress}% of target, ${plasticKPI.annualProgressNeeded}%/year needed)</p>
        <p>Marine Conservation: ${mockData.marine[mockData.marine.length - 1]}% 
           (Progress: ${marineKPI.progress}% of target, ${marineKPI.annualProgressNeeded}%/year needed)</p>
        <p>Mangrove Restoration: ${mockData.mangroveHectares} hectares (DeskTrack)</p>
        <p>Cleanup Crew Hours: ${mockData.cleanupHours} (Zoho Shifts)</p>
    `;

    // Simulate monday.com alert for KPI deviations
    if (ndcKPI.progress < 90 || plasticKPI.progress < 90 || marineKPI.progress < 90) {
        alert('KPI Alert: One or more metrics are below target (monday.com)');
    }
}

// Gantt Chart for Implementation Roadmap
function drawGanttChart() {
    const ctxGantt = document.getElementById('ganttChart').getContext('2d');
    new Chart(ctxGantt, {
        type: 'gantt',
        data: {
            datasets: [{
                label: 'Implementation Roadmap',
                data: [
                    { x: '2025-01-01', x2: '2025-06-30', y: 'Core Platform', taskName: 'Core Platform' },
                    { x: '2025-07-01', x2: '2026-06-30', y: 'Module Development', taskName: 'Module Development' },
                    { x: '2026-07-01', x2: '2026-12-31', y: 'Pilot Testing', taskName: 'Pilot Testing' },
                    { x: '2027-01-01', x2: '2027-12-31', y: 'Full Deployment', taskName: 'Full Deployment' }
                ],
                backgroundColor: '#005566',
                borderColor: '#003087',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    type: 'time',
                    time: { unit: 'month' }
                }
            }
        }
    });
}

// Pie Chart for KPI Distribution
function drawPieChart(type) {
    const ctxPie = document.getElementById('pieChart').getContext('2d');
    const data = type === 'ndc' ? {
        labels: ['Africa', 'Asia', 'Caribbean', 'Pacific'],
        datasets: [{
            data: [20, 15, 10, 5],
            backgroundColor: ['#ffd700', '#003087', '#005566', '#e6e6fa']
        }]
    } : type === 'plastic' ? {
        labels: ['Africa', 'Asia', 'Caribbean', 'Pacific'],
        datasets: [{
            data: [8, 5, 4, 3],
            backgroundColor: ['#ffd700', '#003087', '#005566', '#e6e6fa']
        }]
    } : {
        labels: ['Africa', 'Asia', 'Caribbean', 'Pacific'],
        datasets: [{
            data: [12, 8, 6, 4],
            backgroundColor: ['#ffd700', '#003087', '#005566', '#e6e6fa']
        }]
    };

    new Chart(ctxPie, {
        type: 'pie',
        data: data,
        options: { responsive: true }
    });
}

// Heat Map for KPI Progress
function drawHeatMap() {
    const svg = d3.select('#heatMap').selectAll('*').remove();
    const svgElement = d3.select('#heatMap')
        .append('svg')
        .attr('width', 600)
        .attr('height', 400);

    const mockHeatMapData = commonwealthCountries.slice(0, 10).map(country => ({
        country,
        ndc: Math.random() * 50,
        plastic: Math.random() * 20,
        marine: Math.random() * 30
    }));

    const xScale = d3.scaleBand()
        .domain(mockHeatMapData.map(d => d.country))
        .range([0, 600])
        .padding(0.05);

    const yScale = d3.scaleBand()
        .domain(['NDC', 'Plastic', 'Marine'])
        .range([0, 400])
        .padding(0.05);

    const colorScale = d3.scaleSequential(d3.interpolateBlues)
        .domain([0, 50]);

    svgElement.selectAll('rect')
        .data(mockHeatMapData.flatMap(d => [
            { country: d.country, metric: 'NDC', value: d.ndc },
            { country: d.country, metric: 'Plastic', value: d.plastic },
            { country: d.country, metric: 'Marine', value: d.marine }
        ]))
        .enter()
        .append('rect')
        .attr('x', d => xScale(d.country))
        .attr('y', d => yScale(d.metric))
        .attr('width', xScale.bandwidth())
        .attr('height', yScale.bandwidth())
        .attr('fill', d => colorScale(d.value));

    svgElement.selectAll('text')
        .data(mockHeatMapData.flatMap(d => [
            { country: d.country, metric: 'NDC', value: d.ndc },
            { country: d.country, metric: 'Plastic', value: d.plastic },
            { country: d.country, metric: 'Marine', value: d.marine }
        ]))
        .enter()
        .append('text')
        .attr('x', d => xScale(d.country) + xScale.bandwidth() / 2)
        .attr('y', d => yScale(d.metric) + yScale.bandwidth() / 2)
        .attr('text-anchor', 'middle')
        .attr('dy', '0.35em')
        .text(d => d.value.toFixed(1))
        .attr('fill', '#fff');
}

// Sankey Diagram
function drawSankeyDiagram(type) {
    d3.select('#sankeyDiagram').selectAll('*').remove();
    const svg = d3.select('#sankeyDiagram')
        .append('svg')
        .attr('width', 600)
        .attr('height', 400);

    const sankeyData = type === 'ndc' ? {
        nodes: [{ name: 'Emissions' }, { name: 'Reduction' }, { name: 'NDC Targets' }],
        links: [{ source: 0, target: 1, value: 40 }, { source: 1, target: 2, value: 30 }]
    } : type === 'plastic' ? {
        nodes: [{ name: 'Waste' }, { name: 'Cleanup' }, { name: 'Reduction' }],
        links: [{ source: 0, target: 1, value: 25 }, { source: 1, target: 2, value: 15 }]
    } : {
        nodes: [{ name: 'Marine Areas' }, { name: 'Conservation' }, { name: 'Protected' }],
        links: [{ source: 0, target: 1, value: 35 }, { source: 1, target: 2, value: 20 }]
    };

    const sankey = d3.sankey()
        .nodeWidth(15)
        .nodePadding(10)
        .extent([[1, 1], [600 - 1, 400 - 6]]);

    const { nodes, links } = sankey(sankeyData);

    svg.append('g')
        .selectAll('rect')
        .data(nodes)
        .enter()
        .append('rect')
        .attr('x', d => d.x0)
        .attr('y', d => d.y0)
        .attr('height', d => d.y1 - d.y0)
        .attr('width', d => d.x1 - d.x0)
        .attr('fill', '#005566');

    svg.append('g')
        .selectAll('path')
        .data(links)
        .enter()
        .append('path')
        .attr('d', d3.sankeyLinkHorizontal())
        .attr('stroke', '#ffd700')
        .attr('stroke-width', d => Math.max(1, d.width))
        .attr('fill', 'none')
        .attr('opacity', 0.5);

    svg.append('g')
        .selectAll('text')
        .data(nodes)
        .enter()
        .append('text')
        .attr('x', d => d.x0 - 6)
        .attr('y', d => (d.y1 + d.y0) / 2)
        .attr('dy', '0.35em')
        .attr('text-anchor', 'end')
        .text(d => d.name)
        .attr('fill', '#003087');
}

// Report Generation
function generateReport(type) {
    const reportOutput = document.getElementById('reportOutput');
    const chartType = document.getElementById('chartType').value;
    
    document.getElementById('ganttChart').style.display = 'none';
    document.getElementById('pieChart').style.display = 'none';
    document.getElementById('heatMap').style.display = 'none';
    document.getElementById('sankeyDiagram').style.display = 'none';

    let reportContent = '';
    switch (type) {
        case 'ndc':
            reportContent = 'NDC Implementation Report: 30 countries supported in 2025 (Tableau)';
            break;
        case 'plastic':
            reportContent = 'Plastic Pollution Report: 15% reduction achieved in 2025 (Tableau)';
            break;
        case 'marine':
            reportContent = 'Marine Conservation Report: 20% of marine areas conserved in 2025 (Tableau)';
            break;
    }
    reportOutput.innerHTML = `<p>${reportContent}</p>`;

    if (chartType === 'gantt') {
        document.getElementById('ganttChart').style.display = 'block';
        drawGanttChart();
    } else if (chartType === 'pie') {
        document.getElementById('pieChart').style.display = 'block';
        drawPieChart(type);
    } else if (chartType === 'heatmap') {
        document.getElementById('heatMap').style.display = 'block';
        drawHeatMap();
    } else if (chartType === 'sankey') {
        document.getElementById('sankeyDiagram').style.display = 'block';
        drawSankeyDiagram(type);
    }
}

// Document Analysis
document.getElementById('documentUploadForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const fileInput = document.getElementById('documentInput');
    const file = fileInput.files[0];
    const documentAnalysis = document.getElementById('documentAnalysis');

    if (file) {
        const formData = new FormData();
        formData.append('document', file);

        fetch('analyze_document.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            documentAnalysis.innerHTML = `
                <p>Document Analysis (JOUROFF):</p>
                <p>File: ${data.filename}</p>
                <p>Climate Mentions: ${data.climateMentions}</p>
                <p>Ocean Mentions: ${data.oceanMentions}</p>
                <p>SDG Alignment: ${data.sdgAlignment}</p>
            `;
            drawPieChartWithDocumentData(data);
        })
        .catch(error => {
            documentAnalysis.innerHTML = `<p>Error analyzing document: ${error.message}</p>`;
        });
    } else {
        documentAnalysis.innerHTML = '<p>Please select a file to analyze.</p>';
    }
});

// Pie Chart for Document Analysis
function drawPieChartWithDocumentData(data) {
    const ctxPie = document.getElementById('pieChart').getContext('2d');
    new Chart(ctxPie, {
        type: 'pie',
        data: {
            labels: ['Climate Mentions', 'Ocean Mentions'],
            datasets: [{
                data: [data.climateMentions, data.oceanMentions],
                backgroundColor: ['#ffd700', '#005566']
            }]
        },
        options: { responsive: true }
    });
    document.getElementById('pieChart').style.display = 'block';
}

// Load Forum Posts
function loadForumPosts() {
    const forumPosts = document.getElementById('forumPosts');
    forumPosts.innerHTML = `
        <p>Post 1: Discussing mangrove restoration strategies (Teamwork)</p>
        <p>Post 2: Plastic cleanup crew scheduling (Zoho Shifts)</p>
    `;
}

document.getElementById('forumPostForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('submit_post.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        alert(data);
        loadForumPosts();
    });
});

window.onload = loadForumPosts;