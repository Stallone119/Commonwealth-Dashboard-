<?php
require_once 'db_connect.php';
header('Content-Type: application/json');

$sql = "SELECT iso_code, name FROM countries ORDER BY name";
$result = $conn->query($sql);
$countries = $result->fetch_all(MYSQLI_ASSOC);
echo json_encode($countries);
?>