<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$host = 'localhost';
$username = 'root';
$password = ''; // Empty for XAMPP default
$database = 'commonwealth_dashboard';

// Create connection (removed duplicate database name)
$conn = new mysqli($host, $username, $password, $database);

// Check connection with improved error reporting
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error . 
        ". Error code: " . $conn->connect_errno);
}

// Set charset to utf8mb4 for full Unicode support
if (!$conn->set_charset("utf8mb4")) {
    die("Error loading character set utf8mb4: " . $conn->error);
}

// Optional: Set timezone if needed
date_default_timezone_set('UTC');
?>