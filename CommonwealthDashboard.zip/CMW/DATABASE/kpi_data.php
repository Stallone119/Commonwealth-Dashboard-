<?php
session_start();
require_once 'db_connect.php';

header('Content-Type: application/json');

if (!isset($_SESSION['user']) || ($_SESSION['user']['role'] !== 'System Admin' && $_SESSION['user']['theme'] !== 'all')) {
    echo json_encode(['status' => 'error', 'error' => 'Access Denied']);
    exit;
}

$dataType = $_GET['dataType'] ?? '';
$country = $_GET['country'] ?? 'all';
$dashboardMap = [
    'poverty' => 'economic', 'exports' => 'economic', 'fdi' => 'economic',
    'adaptation' => 'sids', 'mitigation' => 'sids', 'resilience' => 'sids',
    'emissions' => 'climate', 'renewables' => 'climate', 'climateFinance' => 'climate',
    'youthEmployment' => 'youth', 'enrollment' => 'youth', 'participation' => 'youth',
    'literacy' => 'education', 'stem' => 'education', 'digitalLearning' => 'education',
    'maternal' => 'health', 'vaccination' => 'health', 'healthcare' => 'health'
];

if (!isset($dashboardMap[$dataType])) {
    echo json_encode(['status' => 'error', 'error' => 'Invalid data type']);
    exit;
}

$dashboard = $dashboardMap[$dataType];
$sql = $country === 'all' ?
    "SELECT metric, value FROM kpi_data WHERE dashboard = ? AND metric = ?" :
    "SELECT metric, value FROM kpi_data WHERE dashboard = ? AND metric = ? AND country = ?";
$stmt = $conn->prepare($sql);
if ($country === 'all') {
    $stmt->bind_param('ss', $dashboard, $dataType);
} else {
    $stmt->bind_param('sss', $dashboard, $dataType, $country);
}
$stmt->execute();
$result = $stmt->get_result();

$data = [];
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}
echo json_encode(['status' => 'success', 'data' => $data]);
$stmt->close();
$conn->close();
?>