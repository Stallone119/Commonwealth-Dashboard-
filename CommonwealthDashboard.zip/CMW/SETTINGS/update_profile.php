<?php
session_start();
require_once '../DATABASE/db_connect.php';

if (!isset($_SESSION['user'])) {
    header('HTTP/1.1 401 Unauthorized');
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$response = ['success' => false, 'message' => ''];

try {
    $userId = $_SESSION['user']['id'];
    
    // Handle file upload
    $profilePicPath = $_SESSION['user']['profile_pic'] ?? '';
    if (!empty($_FILES['profile_pic']['name'])) {
        $uploadDir = 'uploads/profiles/';
        if (!file_exists($uploadDir)) {
            mkdir($uploadDir, 0777, true);
        }
        
        $fileName = uniqid() . '_' . basename($_FILES['profile_pic']['name']);
        $targetPath = $uploadDir . $fileName;
        
        if (move_uploaded_file($_FILES['profile_pic']['tmp_name'], $targetPath)) {
            // Delete old profile picture if it exists and isn't the default
            if (!empty($profilePicPath) && strpos($profilePicPath, 'default-profile.jpg') === false) {
                @unlink($profilePicPath);
            }
            $profilePicPath = $targetPath;
        }
    }
    
    // Update other fields
    $name = $_POST['name'] ?? $_SESSION['user']['name'];
    $email = $_POST['email'] ?? $_SESSION['user']['email'];
    $phone = $_POST['phone'] ?? $_SESSION['user']['phone'] ?? '';
    
    // Validate inputs
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        throw new Exception('Invalid email format');
    }
    
    $sql = "UPDATE users SET name = ?, email = ?, phone = ?, profile_pic = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param('ssssi', $name, $email, $phone, $profilePicPath, $userId);
    
    if ($stmt->execute()) {
        // Update session data
        $_SESSION['user']['name'] = $name;
        $_SESSION['user']['email'] = $email;
        $_SESSION['user']['phone'] = $phone;
        $_SESSION['user']['profile_pic'] = $profilePicPath;
        
        $response = [
            'success' => true,
            'message' => 'Profile updated successfully',
            'newProfilePic' => $profilePicPath,
            'name' => $name
        ];
    } else {
        throw new Exception('Failed to update profile');
    }
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

header('Content-Type: application/json');
echo json_encode($response);
?>