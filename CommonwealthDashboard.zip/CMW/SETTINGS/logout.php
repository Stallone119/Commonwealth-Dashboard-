<?php
// logout.php - Commonwealth Dashboard Logout Handler

// Strict error reporting for development
error_reporting(E_ALL);
ini_set('display_errors', 0); // Disable in production

// Security headers
header("X-Frame-Options: DENY");
header("X-Content-Type-Options: nosniff");
header("X-XSS-Protection: 1; mode=block");
header("Referrer-Policy: strict-origin-when-cross-origin");

// Start secure session
session_start([
    'name' => 'CommonwealthSecureSession',
    'cookie_httponly' => true,
    'cookie_secure' => true, // Enable in production with HTTPS
    'cookie_samesite' => 'Strict',
    'use_strict_mode' => true
]);

// Regenerate session ID to prevent session fixation
session_regenerate_id(true);

// Unset all session variables
$_SESSION = array();

// Destroy the session
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params["path"],
        $params["domain"],
        $params["secure"],
        $params["httponly"]
    );
}

session_destroy();

// Commonwealth-themed logout page before redirect
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logging Out - Commonwealth Dashboard</title>
    <style>
        /* Commonwealth Colors */
        :root {
            --commonwealth-blue: #012169;
            --commonwealth-gold: #FFD700;
            --commonwealth-red: #C8102E;
            --commonwealth-green: #00843D;
            --commonwealth-light-blue: #6CACE4;
            --commonwealth-white: #FFFFFF;
            --commonwealth-black: #000000;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background-color: var(--commonwealth-blue);
            color: var(--commonwealth-white);
            text-align: center;
        }
        
        .logout-container {
            background-color: var(--commonwealth-white);
            padding: 3rem;
            border-radius: 8px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            max-width: 500px;
            width: 90%;
            color: var(--commonwealth-blue);
        }
        
        h1 {
            color: var(--commonwealth-red);
            margin-bottom: 1.5rem;
        }
        
        .spinner {
            border: 4px solid var(--commonwealth-light-blue);
            border-top: 4px solid var(--commonwealth-gold);
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 2rem auto;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .commonwealth-logo {
            max-width: 150px;
            margin-bottom: 1rem;
        }
    </style>
</head>
<body>
    <div class="logout-container">
        <img src="../SETTINGS/icon.jpg" alt="Commonwealth Logo" class="commonwealth-logo">
        <h1>Logging Out</h1>
        <p>You are being securely logged out of the Commonwealth Dashboard.</p>
        <p>Please wait while we redirect you...</p>
        <div class="spinner"></div>
    </div>

    <script>
        // Redirect after a brief delay to show logout message
        setTimeout(function() {
            window.location.href = "../MAIN/verify_admin.php";
        }, 2000);
        
        // Clear client-side storage
        if (window.localStorage) {
            localStorage.clear();
        }
        if (window.sessionStorage) {
            sessionStorage.clear();
        }
        
        // Clear service worker cache if exists
        if ('serviceWorker' in navigator && 'caches' in window) {
            caches.keys().then(function(cacheNames) {
                cacheNames.forEach(function(cacheName) {
                    caches.delete(cacheName);
                });
            });
        }
    </script>
</body>
</html>
<?php
// Ensure no further code is executed
exit;
?>