<?php
session_start();
require_once __DIR__ . '/../DATABASE/db_connect.php';

if (!isset($_SESSION['user'])) {
    header('Location: index.php');
    exit;
}
$user = $_SESSION['user'];

// Handle both theme mode updates and profile updates
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check which form was submitted
    if (isset($_POST['mode'])) {
        // Theme mode update
        $mode = $_POST['mode'];
        $sql = "UPDATE users SET mode = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param('si', $mode, $user['id']);
        $stmt->execute();
        $_SESSION['user']['mode'] = $mode;
        header('Location: settings.php');
        exit;
    } elseif (isset($_POST['name'])) {
        // Profile update
        $response = ['success' => false, 'message' => ''];
        
        try {
            $userId = $user['id'];
            $name = $_POST['name'];
            $email = $_POST['email'];
            $phone = $_POST['phone'] ?? '';
            $profilePicPath = $user['profile_pic'] ?? '';
            
            // Handle file upload if present
            if (!empty($_FILES['profile_pic']['name'])) {
                $uploadDir = 'uploads/profiles/';
                if (!file_exists($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }
                
                $fileName = uniqid() . '_' . basename($_FILES['profile_pic']['name']);
                $targetPath = $uploadDir . $fileName;
                
                // Validate image file
                $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
                $fileType = mime_content_type($_FILES['profile_pic']['tmp_name']);
                
                if (!in_array($fileType, $allowedTypes)) {
                    throw new Exception('Only JPG, PNG, and GIF images are allowed.');
                }
                
                if ($_FILES['profile_pic']['size'] > 2 * 1024 * 1024) { // 2MB max
                    throw new Exception('Image size must be less than 2MB.');
                }
                
                if (move_uploaded_file($_FILES['profile_pic']['tmp_name'], $targetPath)) {
                    // Delete old profile picture if it exists and isn't the default
                    if (!empty($profilePicPath) && strpos($profilePicPath, 'default-profile.jpg') === false) {
                        @unlink($profilePicPath);
                    }
                    $profilePicPath = $targetPath;
                } else {
                    throw new Exception('Failed to upload profile picture.');
                }
            }
            
            // Validate email
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception('Invalid email format');
            }
            
            // Update database
            $sql = "UPDATE users SET name = ?, email = ?, phone = ?, profile_pic = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('ssssi', $name, $email, $phone, $profilePicPath, $userId);
            
            if ($stmt->execute()) {
                // Update session data
                $_SESSION['user']['name'] = $name;
                $_SESSION['user']['email'] = $email;
                $_SESSION['user']['phone'] = $phone;
                $_SESSION['user']['profile_pic'] = $profilePicPath;
                
                $response = [
                    'success' => true,
                    'message' => 'Profile updated successfully',
                    'newProfilePic' => $profilePicPath
                ];
            } else {
                throw new Exception('Failed to update profile: ' . $conn->error);
            }
        } catch (Exception $e) {
            $response['message'] = $e->getMessage();
        }
        
        // Return JSON response for AJAX request
        header('Content-Type: application/json');
        echo json_encode($response);
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Commonwealth Dashboard</title>
    <link rel="stylesheet" href="settings.css">
    <link rel="manifest" href="../JS/manifest.json">
</head>
<body>
    <nav>
        <a href="../MAIN/index.php">Dashboard</a>
        <?php if ($user['role'] === 'System Admin') { ?>
            <a href="../MAIN/admin_create_user.php">Create User</a>
        <?php } ?>
        <a href="logout.php">Logout</a>
    </nav>
       <div class="container">
    <h1>Settings</h1>
    
    <!-- Theme Mode Form -->
    <form method="POST" class="theme-form">
        <h2>Theme Settings</h2>
        <label for="mode">Theme Mode:</label>
        <select id="mode" name="mode">
            <option value="light" <?= $user['mode'] === 'light' ? 'selected' : '' ?>>Light</option>
            <option value="dark" <?= $user['mode'] === 'dark' ? 'selected' : '' ?>>Dark</option>
        </select>
        <button type="submit">Save Theme</button>
    </form>
    
    <!-- Profile Settings Form -->
    <div class="profile-section">
        <h2>Profile Settings</h2>
        <form id="profile-form" method="POST" enctype="multipart/form-data">
            <div class="profile-header">
                <img src="<?= !empty($user['profile_pic']) ? $user['profile_pic'] : 'default-profile.jpg' ?>" 
                     alt="Profile Picture" class="profile-picture">
                <div class="profile-upload">
                    <input type="file" id="profile-pic" name="profile_pic" accept="image/*" style="display: none;">
                    <button type="button" class="btn btn-secondary" 
                            onclick="document.getElementById('profile-pic').click()">
                        Change Photo
                    </button>
                    <img id="profile-preview" alt="Preview">
                </div>
            </div>
            
           <div class="form-group">
    <label for="name">Full Name</label>
    <input type="text" id="name" name="name" 
           value="<?= htmlspecialchars($user['name'] ?? '') ?>" readonly>
</div>

<div class="form-group">
    <label for="email">Email</label>
    <input type="email" id="email" name="email" 
           value="<?= htmlspecialchars($user['email'] ?? '') ?>" readonly>
</div>

<div class="form-group">
    <label for="phone">Phone Number</label>
    <input type="tel" id="phone" name="phone" 
           value="<?= htmlspecialchars($user['phone'] ?? '') ?>" readonly>
</div>

<div class="form-group">
    <label for="role">Role</label>
    <input type="text" id="role" name="role" 
           value="<?= htmlspecialchars($user['role'] ?? '') ?>" readonly>
</div>
                
                <div class="form-actions">
                    <button type="button" id="edit-profile-btn" class="btn btn-primary">Edit Profile</button>
                    <button type="submit" id="save-profile-btn" class="btn btn-primary" style="display: none;">Save Changes</button>
                    <button type="button" id="cancel-profile-btn" class="btn btn-secondary" style="display: none;">Cancel</button>
                </div>
            </div>
        </form>
    </div>
</div>
    
    <script src="settings.js"></script>
    <script>
        // Profile picture upload preview
        document.getElementById('profile-pic').addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(event) {
                    document.getElementById('profile-preview').src = event.target.result;
                    document.getElementById('profile-preview').style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        });
        
        // Toggle edit mode
        document.getElementById('edit-profile-btn').addEventListener('click', function() {
            const inputs = document.querySelectorAll('#profile-form input[type="text"], #profile-form input[type="email"], #profile-form input[type="tel"]');
            inputs.forEach(input => input.removeAttribute('readonly'));
            document.getElementById('profile-pic').style.display = 'block';
            this.style.display = 'none';
            document.getElementById('save-profile-btn').style.display = 'inline-block';
            document.getElementById('cancel-profile-btn').style.display = 'inline-block';
        });
        
        document.getElementById('cancel-profile-btn').addEventListener('click', function() {
            const inputs = document.querySelectorAll('#profile-form input[type="text"], #profile-form input[type="email"], #profile-form input[type="tel"]');
            inputs.forEach(input => input.setAttribute('readonly', true));
            document.getElementById('profile-pic').style.display = 'none';
            document.getElementById('edit-profile-btn').style.display = 'inline-block';
            document.getElementById('save-profile-btn').style.display = 'none';
            this.style.display = 'none';
            document.getElementById('profile-form').reset();
        });
        
        // Handle profile form submission
        document.getElementById('profile-form').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('settings.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    if (data.newProfilePic) {
                        document.querySelector('.profile-picture').src = data.newProfilePic;
                    }
                    // Reset edit mode
                    document.getElementById('cancel-profile-btn').click();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('An error occurred while updating the profile.');
            });
        });
        
        // Service Worker Registration
        if ('serviceWorker' in navigator) {
            navigator.serviceWorker.register('../JS/sw.js');
        }
    </script>
</body>
</html>