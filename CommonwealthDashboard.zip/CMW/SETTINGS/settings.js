document.addEventListener('DOMContentLoaded', function() {
    // Apply theme based on user preference
    applyTheme();
    
    // Theme mode form submission
    const themeForm = document.querySelector('.theme-form');
    if (themeForm) {
        themeForm.addEventListener('submit', function(e) {
            e.preventDefault();
            this.submit();
        });
    }
    
    // Profile picture preview
    const profilePicInput = document.getElementById('profile-pic');
    if (profilePicInput) {
        profilePicInput.addEventListener('change', function(e) {
            const file = e.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(event) {
                    const preview = document.getElementById('profile-preview');
                    preview.src = event.target.result;
                    preview.style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        });
    }
    
    // Toggle edit mode
    const editProfileBtn = document.getElementById('edit-profile-btn');
    const saveProfileBtn = document.getElementById('save-profile-btn');
    const cancelProfileBtn = document.getElementById('cancel-profile-btn');
    
    if (editProfileBtn) {
        editProfileBtn.addEventListener('click', function() {
            const inputs = document.querySelectorAll('#profile-form input[type="text"], #profile-form input[type="email"], #profile-form input[type="tel"]');
            inputs.forEach(input => input.removeAttribute('readonly'));
            
            document.getElementById('profile-pic').style.display = 'block';
            this.style.display = 'none';
            saveProfileBtn.style.display = 'inline-block';
            cancelProfileBtn.style.display = 'inline-block';
        });
    }
    
    if (cancelProfileBtn) {
        cancelProfileBtn.addEventListener('click', function() {
            const inputs = document.querySelectorAll('#profile-form input[type="text"], #profile-form input[type="email"], #profile-form input[type="tel"]');
            inputs.forEach(input => {
                input.setAttribute('readonly', true);
                // Reset to original values if needed
                // You might want to implement this based on your needs
            });
            
            document.getElementById('profile-pic').style.display = 'none';
            document.getElementById('profile-preview').style.display = 'none';
            editProfileBtn.style.display = 'inline-block';
            saveProfileBtn.style.display = 'none';
            this.style.display = 'none';
            document.getElementById('profile-form').reset();
        });
    }
    
    // Handle profile form submission
    const profileForm = document.getElementById('profile-form');
    if (profileForm) {
        profileForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('settings.php', {
                method: 'POST',
                body: formData
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json();
            })
            .then(data => {
                if (data.success) {
                    showNotification(data.message, 'success');
                    
                    if (data.newProfilePic) {
                        document.querySelector('.profile-picture').src = data.newProfilePic;
                    }
                    
                    // Reset edit mode
                    cancelProfileBtn.click();
                } else {
                    showNotification('Error: ' + data.message, 'error');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showNotification('An error occurred while updating the profile.', 'error');
            });
        });
    }
    
    // Service Worker Registration
    if ('serviceWorker' in navigator) {
        navigator.serviceWorker.register('/sw.js')
            .then(registration => {
                console.log('ServiceWorker registration successful with scope: ', registration.scope);
            })
            .catch(error => {
                console.log('ServiceWorker registration failed: ', error);
            });
    }
});

function applyTheme() {
    // This would be set based on the user's preference from the database
    // For now, we'll check for a dark mode preference
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const userMode = document.body.getAttribute('data-user-mode');
    
    if (userMode === 'dark' || (prefersDark && userMode !== 'light')) {
        document.body.classList.add('dark-mode');
    }
}

function showNotification(message, type) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('fade-out');
        setTimeout(() => {
            notification.remove();
        }, 500);
    }, 3000);
}

// Add dark mode styles if needed
const style = document.createElement('style');
style.textContent = `
    .dark-mode {
        background-color: #121212;
        color: #e0e0e0;
    }
    
    .dark-mode .theme-form,
    .dark-mode .profile-section {
        background-color: #1e1e1e;
        color: #e0e0e0;
    }
    
    .dark-mode h1,
    .dark-mode h2 {
        color: var(--commonwealth-light-blue);
    }
    
    .dark-mode input,
    .dark-mode select {
        background-color: #2d2d2d;
        color: #e0e0e0;
        border-color: #444;
    }
    
    .notification {
        position: fixed;
        bottom: 20px;
        right: 20px;
        padding: 15px 25px;
        border-radius: 5px;
        color: white;
        z-index: 1000;
        animation: slideIn 0.5s ease-out;
    }
    
    .notification.success {
        background-color: var(--commonwealth-green);
    }
    
    .notification.error {
        background-color: var(--commonwealth-red);
    }
    
    .notification.fade-out {
        animation: fadeOut 0.5s ease-out;
    }
    
    @keyframes slideIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
    }
    
    @keyframes fadeOut {
        from { opacity: 1; }
        to { opacity: 0; }
    }
`;
document.head.appendChild(style);