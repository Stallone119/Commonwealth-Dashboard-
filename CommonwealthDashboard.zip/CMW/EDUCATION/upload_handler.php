<?php
session_start();

// Validate CSRF token
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    http_response_code(403);
    die("Invalid CSRF token");
}

// Validate required fields
if (empty($_POST['dataType']) || empty($_POST['country']) || empty($_FILES['document'])) {
    http_response_code(400);
    die("All fields are required");
}

// File upload validation
$allowedTypes = ['text/csv', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
$fileType = $_FILES['document']['type'];
$fileExt = strtolower(pathinfo($_FILES['document']['name'], PATHINFO_EXTENSION));

if (!in_array($fileType, $allowedTypes) || !in_array($fileExt, ['csv', 'xls', 'xlsx'])) {
    http_response_code(400);
    die("Invalid file type. Only CSV, XLS, and XLSX files are allowed.");
}

// File size limit (5MB)
if ($_FILES['document']['size'] > 5242880) {
    http_response_code(400);
    die("File size exceeds 5MB limit");
}

// Create upload directory if it doesn't exist
$uploadDir = 'uploads/';
if (!file_exists($uploadDir)) {
    mkdir($uploadDir, 0755, true);
}

// Generate unique filename
$filename = uniqid() . '_' . preg_replace('/[^A-Za-z0-9_\-]/', '_', $_FILES['document']['name']);
$destination = $uploadDir . $filename;

// Move uploaded file
if (!move_uploaded_file($_FILES['document']['tmp_name'], $destination)) {
    http_response_code(500);
    die("Failed to upload file");
}

// In a real application, you would process the file here
// For this example, we'll just log the metadata
$logData = [
    'timestamp' => date('Y-m-d H:i:s'),
    'filename' => $filename,
    'original_name' => $_FILES['document']['name'],
    'data_type' => $_POST['dataType'],
    'country' => $_POST['country'],
    'dashboard' => $_POST['dashboard'],
    'ip' => $_SERVER['REMOTE_ADDR']
];

file_put_contents('upload_log.txt', json_encode($logData) . PHP_EOL, FILE_APPEND);

// Return success response
header('Content-Type: application/json');
echo json_encode([
    'success' => true,
    'message' => 'File uploaded successfully',
    'filename' => $filename,
    'dataType' => $_POST['dataType'],
    'country' => $_POST['country']
]);
?>