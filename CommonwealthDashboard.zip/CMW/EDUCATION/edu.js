// DOM Ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize charts
    initLiteracyChart();
    initStemChart();
    initDigitalLearningChart();
    
    // Navigation handling
    setupNavigation();
    
    // Form submissions
    setupFormHandlers();
});

// Chart Initialization
function initLiteracyChart() {
    const ctx = document.getElementById('literacyChart').getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['2015', '2018', '2020', '2022', '2024'],
            datasets: [{
                label: 'Literacy Rate (%)',
                data: [72, 76, 79, 82, 85],
                borderColor: '#3498db',
                backgroundColor: 'rgba(52, 152, 219, 0.1)',
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: false,
                    min: 60,
                    max: 100
                }
            }
        }
    });
}

function initStemChart() {
    const ctx = document.getElementById('stemChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['2015', '2018', '2020', '2022', '2024'],
            datasets: [{
                label: 'STEM Graduates',
                data: [45000, 58000, 65000, 72000, 80000],
                backgroundColor: '#2ecc71',
                borderColor: '#27ae60',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

function initDigitalLearningChart() {
    const ctx = document.getElementById('digitalLearningChart').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Digital Access', 'Traditional Learning', 'Hybrid'],
            datasets: [{
                data: [45, 30, 25],
                backgroundColor: [
                    '#e74c3c',
                    '#f39c12',
                    '#9b59b6'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            cutout: '70%'
        }
    });
}

// Navigation
function setupNavigation() {
    // Tab switching
    const navLinks = document.querySelectorAll('nav a');
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            // In a real app, this would load the linked page
            alert('Navigation to ' + this.textContent + ' would happen here');
        });
    });
    
    // Section switching could be added here if needed
}

// Form Handlers
function setupFormHandlers() {
    // Forum post submission
    const forumForm = document.getElementById('forumForm');
    if (forumForm) {
        forumForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitPost(this);
        });
    }
    
    // File upload form
    const uploadForm = document.getElementById('uploadForm');
    if (uploadForm) {
        uploadForm.addEventListener('submit', function(e) {
            e.preventDefault();
            uploadFile(this);
        });
    }
    
    // Report generation buttons
    document.querySelectorAll('#reports button').forEach(button => {
        button.addEventListener('click', function() {
            const reportType = this.getAttribute('onclick').match(/'([^']+)'/)[1];
            generateReport(reportType);
        });
    });
    
    // KPI refresh button
    const refreshBtn = document.querySelector('#kpi button');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function() {
            fetchKPI('education');
        });
    }
}

// AJAX Functions
function submitPost(form) {
    const formData = new FormData(form);
    
    fetch(form.action, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert('Post submitted successfully!');
            form.reset();
            // In a real app, you would update the forum posts display
        } else {
            alert('Error: ' + (data.message || 'Failed to submit post'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while submitting the post');
    });
}

function uploadFile(form) {
    const formData = new FormData(form);
    
    fetch(form.action, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            const resultsDiv = document.getElementById('analysisResults');
            resultsDiv.innerHTML = `
                <div class="card">
                    <h3>Analysis Results</h3>
                    <p><strong>File:</strong> ${data.filename}</p>
                    <p><strong>Data Type:</strong> ${data.dataType}</p>
                    <p><strong>Country:</strong> ${data.country}</p>
                    <p>File uploaded and analysis started successfully.</p>
                </div>
            `;
            form.reset();
        } else {
            alert('Error: ' + (data.message || 'Failed to upload file'));
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('An error occurred while uploading the file');
    });
}

function fetchKPI(dashboard) {
    const countryFilter = document.getElementById('countryFilter').value;
    const kpiDashboard = document.getElementById('kpiDashboard');
    
    // Simulate API call
    kpiDashboard.innerHTML = '<p>Loading KPI data...</p>';
    
    setTimeout(() => {
        // Mock data - in a real app, this would come from an API
        const mockData = {
            education: {
                indicators: [
                    { name: 'Primary Enrollment', current: 89, target: 95, trend: 'up' },
                    { name: 'Secondary Enrollment', current: 76, target: 85, trend: 'up' },
                    { name: 'Teacher Ratio', current: 28, target: 20, trend: 'down' },
                    { name: 'Gender Parity', current: 0.96, target: 1.0, trend: 'up' }
                ]
            }
        };
        
        let html = '<div class="cards">';
        mockData[dashboard].indicators.forEach(indicator => {
            const progress = Math.min(100, Math.round((indicator.current / indicator.target) * 100));
            const trendIcon = indicator.trend === 'up' ? '↑' : '↓';
            const trendClass = indicator.trend === 'up' ? 'positive' : 'negative';
            
            html += `
                <div class="card">
                    <h3>${indicator.name}</h3>
                    <div class="progress-container">
                        <div class="progress-bar" style="width: ${progress}%"></div>
                    </div>
                    <p>Current: ${indicator.current} | Target: ${indicator.target}</p>
                    <p class="${trendClass}">Trend: ${trendIcon}</p>
                </div>
            `;
        });
        html += '</div>';
        
        if (countryFilter !== 'all') {
            html += `<p>Showing data filtered for country code: ${countryFilter}</p>`;
        }
        
        kpiDashboard.innerHTML = html;
    }, 800);
}

function generateReport(reportType) {
    const chartType = document.getElementById('chartType').value;
    const outputDiv = document.getElementById('reportOutput');
    
    outputDiv.innerHTML = '<p>Generating report... This may take a moment.</p>';
    
    // Hide all chart containers
    document.getElementById('pieChart').style.display = 'none';
    document.getElementById('heatMap').style.display = 'none';
    document.getElementById('sankeyDiagram').style.display = 'none';
    
    // Simulate report generation
    setTimeout(() => {
        let reportContent = '';
        
        switch (chartType) {
            case 'pie':
                reportContent = generatePieChart(reportType);
                break;
            case 'heatmap':
                reportContent = generateHeatMap(reportType);
                break;
            case 'sankey':
                reportContent = generateSankeyDiagram(reportType);
                break;
        }
        
        outputDiv.innerHTML = `
            <h3>${reportType} Report (${chartType})</h3>
            ${reportContent}
            <p class="report-meta">Report generated on ${new Date().toLocaleString()}</p>
        `;
    }, 1200);
}

// Report Generation Helpers
function generatePieChart(reportType) {
    const canvas = document.getElementById('pieChart');
    canvas.style.display = 'block';
    
    // Mock data based on report type
    let data;
    if (reportType === 'literacy') {
        data = {
            labels: ['Urban', 'Rural', 'Male', 'Female'],
            datasets: [{
                data: [85, 65, 78, 72],
                backgroundColor: ['#3498db', '#2ecc71', '#e74c3c', '#f39c12']
            }]
        };
    } else if (reportType === 'stem') {
        data = {
            labels: ['Engineering', 'Math', 'Science', 'Technology'],
            datasets: [{
                data: [45, 20, 25, 10],
                backgroundColor: ['#3498db', '#2ecc71', '#e74c3c', '#f39c12']
            }]
        };
    } else { // digitalLearning
        data = {
            labels: ['Online Courses', 'Digital Tools', 'E-books', 'VR Learning'],
            datasets: [{
                data: [40, 30, 20, 10],
                backgroundColor: ['#3498db', '#2ecc71', '#e74c3c', '#f39c12']
            }]
        };
    }
    
    // Create or update chart
    if (window.pieChart) {
        window.pieChart.data = data;
        window.pieChart.update();
    } else {
        const ctx = canvas.getContext('2d');
        window.pieChart = new Chart(ctx, {
            type: 'pie',
            data: data,
            options: {
                responsive: true
            }
        });
    }
    
    return '<p>Distribution shown in pie chart above.</p>';
}

function generateHeatMap(reportType) {
    const container = document.getElementById('heatMap');
    container.style.display = 'block';
    container.innerHTML = `
        <div class="heat-map">
            <p>Heat map visualization would appear here for ${reportType} data.</p>
            <p>In a real implementation, this would use a library like D3.js to create an interactive heat map.</p>
        </div>
    `;
    
    return '<p>Heat map visualization displayed above.</p>';
}

function generateSankeyDiagram(reportType) {
    const container = document.getElementById('sankeyDiagram');
    container.style.display = 'block';
    container.innerHTML = `
        <div class="sankey-diagram">
            <p>Sankey diagram visualization would appear here for ${reportType} data.</p>
            <p>In a real implementation, this would use D3.js to show flows and relationships in the data.</p>
        </div>
    `;
    
    return '<p>Sankey diagram visualization displayed above.</p>';
}