<?php
session_start();

// Validate CSRF token
if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
    http_response_code(403);
    die("Invalid CSRF token");
}

// Validate input
if (empty($_POST['post'])) {
    http_response_code(400);
    die("Post content is required");
}

// Sanitize input
$postContent = htmlspecialchars(trim($_POST['post']), ENT_QUOTES, 'UTF-8');

// In a real application, you would save to a database here
// For this example, we'll just append to a simple text file
$filePath = 'posts.txt';
$postData = [
    'timestamp' => date('Y-m-d H:i:s'),
    'content' => $postContent,
    'ip' => $_SERVER['REMOTE_ADDR']
];

file_put_contents($filePath, json_encode($postData) . PHP_EOL, FILE_APPEND);

// Return success response
header('Content-Type: application/json');
echo json_encode(['success' => true, 'message' => 'Post submitted successfully']);
?>