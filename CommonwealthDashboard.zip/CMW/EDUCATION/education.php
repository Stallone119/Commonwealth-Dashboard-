<?php
$countries = [ 
    ['code' => 'ATG', 'name' => 'Antigua and Barbuda'], ['code' => 'AUS', 'name' => 'Australia'],
    ['code' => 'BHS', 'name' => 'Bahamas'], ['code' => 'BGD', 'name' => 'Bangladesh'],
    ['code' => 'BRB', 'name' => 'Barbados'], ['code' => 'BLZ', 'name' => 'Belize'],
    ['code' => 'BWA', 'name' => 'Botswana'], ['code' => 'BRN', 'name' => 'Brunei'],
    ['code' => 'CMR', 'name' => 'Cameroon'], ['code' => 'CAN', 'name' => 'Canada'],
    ['code' => 'CYP', 'name' => 'Cyprus'], ['code' => 'DMA', 'name' => 'Dominica'],
    ['code' => 'SWZ', 'name' => 'Eswatini'], ['code' => 'FJI', 'name' => 'Fiji'],
    ['code' => 'GAB', 'name' => 'Gabon'], ['code' => 'GMB', 'name' => 'Gambia'],
    ['code' => 'GHA', 'name' => 'Ghana'], ['code' => 'GRD', 'name' => 'Grenada'],
    ['code' => 'GUY', 'name' => 'Guyana'], ['code' => 'IND', 'name' => 'India'],
    ['code' => 'JAM', 'name' => 'Jamaica'], ['code' => 'KEN', 'name' => 'Kenya'],
    ['code' => 'KIR', 'name' => 'Kiribati'], ['code' => 'LSO', 'name' => 'Lesotho'],
    ['code' => 'MWI', 'name' => 'Malawi'], ['code' => 'MYS', 'name' => 'Malaysia'],
    ['code' => 'MDV', 'name' => 'Maldives'], ['code' => 'MLT', 'name' => 'Malta'],
    ['code' => 'MUS', 'name' => 'Mauritius'], ['code' => 'MOZ', 'name' => 'Mozambique'],
    ['code' => 'NAM', 'name' => 'Namibia'], ['code' => 'NRU', 'name' => 'Nauru'],
    ['code' => 'NZL', 'name' => 'New Zealand'], ['code' => 'NGA', 'name' => 'Nigeria'],
    ['code' => 'PAK', 'name' => 'Pakistan'], ['code' => 'PNG', 'name' => 'Papua New Guinea'],
    ['code' => 'RWA', 'name' => 'Rwanda'], ['code' => 'KNA', 'name' => 'Saint Kitts and Nevis'],
    ['code' => 'LCA', 'name' => 'Saint Lucia'], ['code' => 'VCT', 'name' => 'Saint Vincent and the Grenadines'],
    ['code' => 'WSM', 'name' => 'Samoa'], ['code' => 'SYC', 'name' => 'Seychelles'],
    ['code' => 'SLE', 'name' => 'Sierra Leone'], ['code' => 'SGP', 'name' => 'Singapore'],
    ['code' => 'SLB', 'name' => 'Solomon Islands'], ['code' => 'ZAF', 'name' => 'South Africa'],
    ['code' => 'LKA', 'name' => 'Sri Lanka'], ['code' => 'TZA', 'name' => 'Tanzania'],
    ['code' => 'TGO', 'name' => 'Togo'], ['code' => 'TON', 'name' => 'Tonga'],
    ['code' => 'TTO', 'name' => 'Trinidad and Tobago'], ['code' => 'TUV', 'name' => 'Tuvalu'],
    ['code' => 'UGA', 'name' => 'Uganda'], ['code' => 'GBR', 'name' => 'United Kingdom'],
    ['code' => 'VUT', 'name' => 'Vanuatu'], ['code' => 'ZMB', 'name' => 'Zambia']
];

// Generate CSRF token
session_start();
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$csrf_token = $_SESSION['csrf_token'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Education Dashboard</title>
    <link rel="stylesheet" href="edu.css">
    <script src="https://d3js.org/d3.v7.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chartjs-chart-gantt"></script>
    <script src="https://cdn.workbox.googleapis.com/v6.5.4/workbox-sw.js"></script>
</head>
<body>
    <div class="container">
        <header>
            <h1>Education Dashboard</h1>
            <nav>
                <a href="../ECONOMIC GROWTH/economics.php">Economic Growth</a>
                <a href="../SMALL CITIES/sids.html">SIDS</a>
                <a href="../CLIMATE/climate.html">Climate and Oceans</a>
                <a href="../YOUTH/youth.html">Youth and Gender</a>
                <a href="../GOVERNANCE/governance.html">Governance and Peace</a>
                <a href="../HEALTH/health.php">Health</a>
            </nav>
        </header>

        <section id="overview" class="section active">
            <h2>Overview</h2>
            <div class="cards">
                <div class="card">
                    <h3>Literacy Rate</h3>
                    <p>Target: 95% by 2030</p>
                    <canvas id="literacyChart"></canvas>
                </div>
                <div class="card">
                    <h3>STEM Graduates</h3>
                    <p>Target: 100,000 by 2030</p>
                    <canvas id="stemChart"></canvas>
                </div>
                <div class="card">
                    <h3>Digital Learning</h3>
                    <p>Target: 80% by 2030</p>
                    <canvas id="digitalLearningChart"></canvas>
                </div>
            </div>
        </section>

        <section id="kpi" class="section">
            <h2>KPI Tracking</h2>
            <div class="controls">
                <select id="countryFilter">
                    <option value="all">All Countries</option>
                    <?php foreach ($countries as $country): ?>
                        <option value="<?php echo htmlspecialchars($country['code']); ?>">
                            <?php echo htmlspecialchars($country['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <button onclick="fetchKPI('education')">Refresh</button>
            </div>
            <div id="kpiDashboard"></div>
        </section>

        <section id="reports" class="section">
            <h2>Reports</h2>
            <div class="controls">
                <select id="chartType">
                    <option value="pie">Pie Chart</option>
                    <option value="heatmap">Heat Map</option>
                    <option value="sankey">Sankey Diagram</option>
                </select>
                <button onclick="generateReport('literacy')">Literacy Report</button>
                <button onclick="generateReport('stem')">STEM Report</button>
                <button onclick="generateReport('digitalLearning')">Digital Learning Report</button>
            </div>
            <div id="reportOutput"></div>
            <canvas id="pieChart" style="display: none;"></canvas>
            <div id="heatMap" style="display: none;"></div>
            <div id="sankeyDiagram" style="display: none;"></div>
        </section>

        <section id="collaboration" class="section">
            <h2>Collaboration (Asana)</h2>
            <form id="forumForm" action="submit_post.php" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <textarea name="post" placeholder="Share ideas..." required></textarea>
                <button type="submit">Post</button>
            </form>
            <div id="forumPosts"></div>
        </section>

        <section id="documents" class="section">
            <h2>Document Analysis (Salesforce)</h2>
            <form id="uploadForm" enctype="multipart/form-data" action="upload_handler.php" method="POST">
                <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                <input type="file" name="document" accept=".csv,.xlsx,.xls" required>
                <select name="dataType" required>
                    <option value="">Select Type</option>
                    <option value="literacy">Literacy Data</option>
                    <option value="stem">STEM Data</option>
                    <option value="digital">Digital Learning Data</option>
                </select>
                <select name="country" required>
                    <option value="">Select Country</option>
                    <?php foreach ($countries as $country): ?>
                        <option value="<?php echo htmlspecialchars($country['code']); ?>">
                            <?php echo htmlspecialchars($country['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <input type="hidden" name="dashboard" value="education">
                <button type="submit">Analyze</button>
            </form>
            <div id="analysisResults"></div>
        </section>

        <footer>
            <p>Powered by Microsoft Project, Asana, Salesforce, Power BI, Clockify</p>
        </footer>
    </div>
    <script src="edu.js"></script>
</body>
</html>