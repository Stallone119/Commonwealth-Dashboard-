// Commonwealth countries list
const commonwealthCountries = [
    "Antigua and Barbuda", "Australia", "Bahamas", "Bangladesh", "Barbados", "Belize", "Botswana", "Brunei",
    "Cameroon", "Canada", "Cyprus", "Dominica", "Eswatini", "Fiji", "Gabon", "Gambia", "Ghana", "Grenada",
    "Guyana", "India", "Jamaica", "Kenya", "Kiribati", "Lesotho", "Malawi", "Malaysia", "Maldives", "Malta",
    "Mauritius", "Mozambique", "Namibia", "Nauru", "New Zealand", "Nigeria", "Pakistan", "Papua New Guinea",
    "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "Seychelles",
    "Sierra Leone", "Singapore", "Solomon Islands", "South Africa", "Sri Lanka", "Tanzania", "Togo", "Tonga",
    "Trinidad and Tobago", "Tuvalu", "Uganda", "United Kingdom", "Vanuatu", "Zambia"
];

// Mock data for charts
const youthParticipationData = {
    labels: ['2023', '2024', '2025', '2026', '2027'],
    datasets: [{
        label: 'Youth Participation (%)',
        data: [10, 15, 20, 22, 25],
        backgroundColor: '#ffd700',
        borderColor: '#003087',
        borderWidth: 2
    }]
};

const unemploymentData = {
    labels: ['2023', '2024', '2025', '2026', '2030'],
    datasets: [{
        label: 'Youth Unemployment (%)',
        data: [20, 18, 17, 16, 15],
        backgroundColor: '#005566',
        borderColor: '#003087',
        borderWidth: 2
    }]
};

const womenRepresentationData = {
    labels: ['2023', '2024', '2025', '2026', '2029'],
    datasets: [{
        label: 'Women Representation (%)',
        data: [25, 28, 32, 35, 40],
        backgroundColor: '#e6e6fa',
        borderColor: '#003087',
        borderWidth: 2
    }]
};

// Initialize Line Charts
const ctx1 = document.getElementById('youthParticipationChart').getContext('2d');
new Chart(ctx1, {
    type: 'line',
    data: youthParticipationData,
    options: { responsive: true }
});

const ctx2 = document.getElementById('unemploymentChart').getContext('2d');
new Chart(ctx2, {
    type: 'line',
    data: unemploymentData,
    options: { responsive: true }
});

const ctx3 = document.getElementById('womenRepresentationChart').getContext('2d');
new Chart(ctx3, {
    type: 'line',
    data: womenRepresentationData,
    options: { responsive: true }
});

// KPI Calculations
function calculateKPI(data, target, baseline, targetYear, currentYear) {
    const progress = ((data[data.length - 1] - baseline) / (target - baseline)) * 100;
    const yearsLeft = targetYear - currentYear;
    const annualProgressNeeded = (target - data[data.length - 1]) / yearsLeft;
    return { progress: progress.toFixed(2), annualProgressNeeded: annualProgressNeeded.toFixed(2) };
}

// Mock KPI Data Fetching
function fetchKPI() {
    const country = document.getElementById('countryFilter').value;
    const kpiDashboard = document.getElementById('kpiDashboard');
    
    // Mock data (replace with Scoro/Workstatus API)
    const mockData = {
        participation: [10, 15, 20],
        unemployment: [20, 18, 17],
        women: [25, 28, 32],
        volunteerHours: 5000,
        budget: 1200000
    };

    const participationKPI = calculateKPI(mockData.participation, 25, 10, 2027, 2025);
    const unemploymentKPI = calculateKPI(mockData.unemployment, 15, 20, 2030, 2025);
    const womenKPI = calculateKPI(mockData.women, 40, 25, 2029, 2025);

    kpiDashboard.innerHTML = `
        <p><strong>${country === 'all' ? 'All Countries' : country}</strong></p>
        <p>Youth Participation: ${mockData.participation[mockData.participation.length - 1]}% 
           (Progress: ${participationKPI.progress}% of target, 
           ${participationKPI.annualProgressNeeded}%/year needed)</p>
        <p>Youth Unemployment: ${mockData.unemployment[mockData.unemployment.length - 1]}% 
           (Progress: ${unemploymentKPI.progress}% of target, 
           ${unemploymentKPI.annualProgressNeeded}%/year needed)</p>
        <p>Women Representation: ${mockData.women[mockData.women.length - 1]}% 
           (Progress: ${womenKPI.progress}% of target, 
           ${womenKPI.annualProgressNeeded}%/year needed)</p>
        <p>Volunteer Hours: ${mockData.volunteerHours} (Workstatus)</p>
        <p>Gender Budget Allocation: $${mockData.budget.toLocaleString()} (Scoro)</p>
    `;
    
    // Simulate monday.com alert if KPIs deviate >10%
    if (participationKPI.progress < 90 || unemploymentKPI.progress < 90 || womenKPI.progress < 90) {
        alert('KPI Alert: One or more metrics are below target (monday.com)');
    }
}

// Gantt Chart for Implementation Roadmap
function drawGanttChart() {
    const ctxGantt = document.getElementById('ganttChart').getContext('2d');
    new Chart(ctxGantt, {
        type: 'gantt',
        data: {
            datasets: [{
                label: 'Implementation Roadmap',
                data: [
                    { x: '2025-01-01', x2: '2025-06-30', y: 'Core Platform', taskName: 'Core Platform' },
                    { x: '2025-07-01', x2: '2026-06-30', y: 'Module Development', taskName: 'Module Development' },
                    { x: '2026-07-01', x2: '2026-12-31', y: 'Pilot Testing', taskName: 'Pilot Testing' },
                    { x: '2027-01-01', x2: '2027-12-31', y: 'Full Deployment', taskName: 'Full Deployment' }
                ],
                backgroundColor: '#005566',
                borderColor: '#003087',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    type: 'time',
                    time: { unit: 'month' }
                }
            }
        }
    });
}

// Pie Chart for KPI Distribution
function drawPieChart(type) {
    const ctxPie = document.getElementById('pieChart').getContext('2d');
    const data = type === 'youth' ? {
        labels: ['Africa', 'Asia', 'Caribbean', 'Pacific'],
        datasets: [{
            data: [30, 25, 20, 25],
            backgroundColor: ['#ffd700', '#003087', '#005566', '#e6e6fa']
        }]
    } : type === 'gender' ? {
        labels: ['Africa', 'Asia', 'Caribbean', 'Pacific'],
        datasets: [{
            data: [40, 20, 25, 15],
            backgroundColor: ['#ffd700', '#003087', '#005566', '#e6e6fa']
        }]
    } : {
        labels: ['Africa', 'Asia', 'Caribbean', 'Pacific'],
        datasets: [{
            data: [35, 30, 20, 15],
            backgroundColor: ['#ffd700', '#003087', '#005566', '#e6e6fa']
        }]
    };

    new Chart(ctxPie, {
        type: 'pie',
        data: data,
        options: { responsive: true }
    });
}

// Heat Map for KPI Progress Across Countries
function drawHeatMap() {
    const svg = d3.select('#heatMap')
        .append('svg')
        .attr('width', 600)
        .attr('height', 400);

    const mockHeatMapData = commonwealthCountries.slice(0, 10).map(country => ({
        country,
        participation: Math.random() * 25,
        unemployment: Math.random() * 20,
        women: Math.random() * 40
    }));

    const xScale = d3.scaleBand()
        .domain(mockHeatMapData.map(d => d.country))
        .range([0, 600])
        .padding(0.05);

    const yScale = d3.scaleBand()
        .domain(['Participation', 'Unemployment', 'Women'])
        .range([0, 400])
        .padding(0.05);

    const colorScale = d3.scaleSequential(d3.interpolateBlues)
        .domain([0, 40]);

    svg.selectAll('rect')
        .data(mockHeatMapData.flatMap(d => [
            { country: d.country, metric: 'Participation', value: d.participation },
            { country: d.country, metric: 'Unemployment', value: d.unemployment },
            { country: d.country, metric: 'Women', value: d.women }
        ]))
        .enter()
        .append('rect')
        .attr('x', d => xScale(d.country))
        .attr('y', d => yScale(d.metric))
        .attr('width', xScale.bandwidth())
        .attr('height', yScale.bandwidth())
        .attr('fill', d => colorScale(d.value));

    svg.selectAll('text')
        .data(mockHeatMapData.flatMap(d => [
            { country: d.country, metric: 'Participation', value: d.participation },
            { country: d.country, metric: 'Unemployment', value: d.unemployment },
            { country: d.country, metric: 'Women', value: d.women }
        ]))
        .enter()
        .append('text')
        .attr('x', d => xScale(d.country) + xScale.bandwidth() / 2)
        .attr('y', d => yScale(d.metric) + yScale.bandwidth() / 2)
        .attr('text-anchor', 'middle')
        .attr('dy', '0.35em')
        .text(d => d.value.toFixed(1))
        .attr('fill', '#fff');
}

// Sankey Diagram
function drawSankeyDiagram(type) {
    d3.select('#sankeyDiagram').selectAll('*').remove();
    const svg = d3.select('#sankeyDiagram')
        .append('svg')
        .attr('width', 600)
        .attr('height', 400);

    const sankeyData = type === 'youth' ? {
        nodes: [{ name: 'Youth' }, { name: 'Training' }, { name: 'Governance' }],
        links: [{ source: 0, target: 1, value: 50 }, { source: 1, target: 2, value: 30 }]
    } : type === 'gender' ? {
        nodes: [{ name: 'Budget' }, { name: 'Allocation' }, { name: 'Projects' }],
        links: [{ source: 0, target: 1, value: 40 }, { source: 1, target: 2, value: 25 }]
    } : {
        nodes: [{ name: 'Women' }, { name: 'Leadership' }, { name: 'Peace Processes' }],
        links: [{ source: 0, target: 1, value: 35 }, { source: 1, target: 2, value: 20 }]
    };

    const sankey = d3.sankey()
        .nodeWidth(15)
        .nodePadding(10)
        .extent([[1, 1], [600 - 1, 400 - 6]]);

    const { nodes, links } = sankey(sankeyData);

    svg.append('g')
        .selectAll('rect')
        .data(nodes)
        .enter()
        .append('rect')
        .attr('x', d => d.x0)
        .attr('y', d => d.y0)
        .attr('height', d => d.y1 - d.y0)
        .attr('width', d => d.x1 - d.x0)
        .attr('fill', '#005566');

    svg.append('g')
        .selectAll('path')
        .data(links)
        .enter()
        .append('path')
        .attr('d', d3.sankeyLinkHorizontal())
        .attr('stroke', '#ffd700')
        .attr('stroke-width', d => Math.max(1, d.width))
        .attr('fill', 'none')
        .attr('opacity', 0.5);

    svg.append('g')
        .selectAll('text')
        .data(nodes)
        .enter()
        .append('text')
        .attr('x', d => d.x0 - 6)
        .attr('y', d => (d.y1 + d.y0) / 2)
        .attr('dy', '0.35em')
        .attr('text-anchor', 'end')
        .text(d => d.name)
        .attr('fill', '#003087');
}

// Report Generation
function generateReport(type) {
    const reportOutput = document.getElementById('reportOutput');
    const chartType = document.getElementById('chartType').value;
    
    // Hide all charts
    document.getElementById('ganttChart').style.display = 'none';
    document.getElementById('pieChart').style.display = 'none';
    document.getElementById('heatMap').style.display = 'none';
    document.getElementById('sankeyDiagram').style.display = 'none';

    // Generate report content
    let reportContent = '';
    switch (type) {
        case 'youth':
            reportContent = 'Youth Participation Report: 20% participation rate across 10 countries (DevResults)';
            break;
        case 'gender':
            reportContent = 'Gender Budgeting Report: $1.2M allocated in 2025 (Scoro)';
            break;
        case 'women':
            reportContent = 'Women Representation Report: 32% in peace processes (Google Looker Studio)';
            break;
    }
    reportOutput.innerHTML = `<p>${reportContent}</p>`;

    // Draw selected chart
    if (chartType === 'gantt') {
        document.getElementById('ganttChart').style.display = 'block';
        drawGanttChart();
    } else if (chartType === 'pie') {
        document.getElementById('pieChart').style.display = 'block';
        drawPieChart(type);
    } else if (chartType === 'heatmap') {
        document.getElementById('heatMap').style.display = 'block';
        drawHeatMap();
    } else if (chartType === 'sankey') {
        document.getElementById('sankeyDiagram').style.display = 'block';
        drawSankeyDiagram(type);
    }
}

// Document Analysis
document.getElementById('documentUploadForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const fileInput = document.getElementById('documentInput');
    const file = fileInput.files[0];
    const documentAnalysis = document.getElementById('documentAnalysis');

    if (file) {
        const formData = new FormData();
        formData.append('document', file);

        fetch('analyze_document.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            documentAnalysis.innerHTML = `
                <p>Document Analysis (DevResults):</p>
                <p>File: ${data.filename}</p>
                <p>Youth Mentions: ${data.youthMentions}</p>
                <p>Gender Mentions: ${data.genderMentions}</p>
                <p>SDG Alignment: ${data.sdgAlignment}</p>
            `;
            // Update pie chart with document analysis data
            drawPieChartWithDocumentData(data);
        })
        .catch(error => {
            documentAnalysis.innerHTML = `<p>Error analyzing document: ${error.message}</p>`;
        });
    } else {
        documentAnalysis.innerHTML = '<p>Please select a file to analyze.</p>';
    }
});

// Pie Chart for Document Analysis
function drawPieChartWithDocumentData(data) {
    const ctxPie = document.getElementById('pieChart').getContext('2d');
    new Chart(ctxPie, {
        type: 'pie',
        data: {
            labels: ['Youth Mentions', 'Gender Mentions'],
            datasets: [{
                data: [data.youthMentions, data.genderMentions],
                backgroundColor: ['#ffd700', '#005566']
            }]
        },
        options: { responsive: true }
    });
    document.getElementById('pieChart').style.display = 'block';
}

// Load Forum Posts
function loadForumPosts() {
    const forumPosts = document.getElementById('forumPosts');
    forumPosts.innerHTML = `
        <p>Post 1: Discussing youth council initiatives (monday.com)</p>
        <p>Post 2: Gender equality policy suggestions</p>
    `;
}

document.getElementById('forumPostForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('submit_post.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        alert(data);
        loadForumPosts();
    });
});

window.onload = loadForumPosts;