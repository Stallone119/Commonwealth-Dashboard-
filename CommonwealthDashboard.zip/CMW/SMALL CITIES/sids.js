// Commonwealth countries list
const commonwealthCountries = [
    "Antigua and Barbuda", "Australia", "Bahamas", "Bangladesh", "Barbados", "Belize", "Botswana", "Brunei",
    "Cameroon", "Canada", "Cyprus", "Dominica", "Eswatini", "Fiji", "Gabon", "Gambia", "Ghana", "Grenada",
    "Guyana", "India", "Jamaica", "Kenya", "Kiribati", "Lesotho", "Malawi", "Malaysia", "Maldives", "Malta",
    "Mauritius", "Mozambique", "Namibia", "Nauru", "New Zealand", "Nigeria", "Pakistan", "Papua New Guinea",
    "Rwanda", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines", "Samoa", "Seychelles",
    "Sierra Leone", "Singapore", "Solomon Islands", "South Africa", "Sri Lanka", "Tanzania", "Togo", "Tonga",
    "Trinidad and Tobago", "Tuvalu", "Uganda", "United Kingdom", "Vanuatu", "Zambia"
];

// Populate country dropdown
const countrySelect = document.getElementById('countryFilter');
commonwealthCountries.forEach(country => {
    const option = document.createElement('option');
    option.value = country;
    option.textContent = country;
    countrySelect.appendChild(option);
});

// Mock data for charts
const climateFinanceData = {
    labels: ['2023', '2024', '2025', '2026', '2030'],
    datasets: [{
        label: 'Climate Finance Absorption (%)',
        data: [10, 20, 30, 40, 50],
        backgroundColor: '#FFD700',
        borderColor: '#1E3A8A',
        borderWidth: 2
    }]
};

const nonTourismGDPData = {
    labels: ['2023', '2024', '2025', '2026', '2030'],
    datasets: [{
        label: 'Non-Tourism GDP Growth (%)',
        data: [1, 2, 3, 4, 5],
        backgroundColor: '#3B82F6',
        borderColor: '#1E3A8A',
        borderWidth: 2
    }]
};

const digitalTransformationData = {
    labels: ['2023', '2024', '2025', '2026', '2030'],
    datasets: [{
        label: 'Digital Transformation (%)',
        data: [10, 20, 30, 40, 50],
        backgroundColor: '#F0F4FF',
        borderColor: '#1E3A8A',
        borderWidth: 2
    }]
};

// Initialize Line Charts
const ctx1 = document.getElementById('climateFinanceChart').getContext('2d');
new Chart(ctx1, {
    type: 'line',
    data: climateFinanceData,
    options: { responsive: true }
});

const ctx2 = document.getElementById('nonTourismGDPChart').getContext('2d');
new Chart(ctx2, {
    type: 'line',
    data: nonTourismGDPData,
    options: { responsive: true }
});

const ctx3 = document.getElementById('digitalTransformationChart').getContext('2d');
new Chart(ctx3, {
    type: 'line',
    data: digitalTransformationData,
    options: { responsive: true }
});

// KPI Calculations
function calculateKPI(data, target, baseline, targetYear, currentYear) {
    const progress = ((data[data.length - 1] - baseline) / (target - baseline)) * 100;
    const yearsLeft = targetYear - currentYear;
    const annualProgressNeeded = yearsLeft > 0 ? (target - data[data.length - 1]) / yearsLeft : 0;
    return { progress: progress.toFixed(2), annualProgressNeeded: annualProgressNeeded.toFixed(2) };
}

// Mock KPI Data Fetching
function fetchKPI() {
    const country = document.getElementById('countryFilter').value;
    const kpiDashboard = document.getElementById('kpiDashboard');
    
    // Mock data (replace with Workamajig/Perdoo API)
    const mockData = {
        climateFinance: [10, 20, 30],
        nonTourismGDP: [1, 2, 3],
        digitalTransformation: [10, 20, 30],
        projectsCompleted: 25,
        teamFeedback: 15
    };

    const climateKPI = calculateKPI(mockData.climateFinance, 50, 0, 2030, 2025);
    const gdpKPI = calculateKPI(mockData.nonTourismGDP, 5, 0, 2030, 2025);
    const digitalKPI = calculateKPI(mockData.digitalTransformation, 50, 0, 2030, 2025);

    kpiDashboard.innerHTML = `
        <p><strong>${country === 'all' ? 'All Countries' : country}</strong></p>
        <p>Climate Finance Absorption: ${mockData.climateFinance[mockData.climateFinance.length - 1]}% 
           (Progress: ${climateKPI.progress}% of target, ${climateKPI.annualProgressNeeded}%/year needed)</p>
        <p>Non-Tourism GDP Growth: ${mockData.nonTourismGDP[mockData.nonTourismGDP.length - 1]}% 
           (Progress: ${gdpKPI.progress}% of target, ${gdpKPI.annualProgressNeeded}%/year needed)</p>
        <p>Digital Transformation: ${mockData.digitalTransformation[mockData.digitalTransformation.length - 1]}% 
           (Progress: ${digitalKPI.progress}% of target, ${digitalKPI.annualProgressNeeded}%/year needed)</p>
        <p>Projects Completed: ${mockData.projectsCompleted} (Workamajig)</p>
        <p>Team Feedback Sessions: ${mockData.teamFeedback} (15Five)</p>
    `;

    // Simulate Perdoo alert for KPI deviations
    if (climateKPI.progress < 90 || gdpKPI.progress < 90 || digitalKPI.progress < 90) {
        alert('KPI Alert: One or more metrics are below target (Perdoo)');
    }
}

// Gantt Chart for Implementation Roadmap
function drawGanttChart() {
    const ctxGantt = document.getElementById('ganttChart').getContext('2d');
    new Chart(ctxGantt, {
        type: 'gantt',
        data: {
            datasets: [{
                label: 'Implementation Roadmap',
                data: [
                    { x: '2025-01-01', x2: '2025-06-30', y: 'Core Platform', taskName: 'Core Platform' },
                    { x: '2025-07-01', x2: '2026-06-30', y: 'Module Development', taskName: 'Module Development' },
                    { x: '2026-07-01', x2: '2026-12-31', y: 'Pilot Testing', taskName: 'Pilot Testing' },
                    { x: '2027-01-01', x2: '2027-12-31', y: 'Full Deployment', taskName: 'Full Deployment' }
                ],
                backgroundColor: '#3B82F6',
                borderColor: '#1E3A8A',
                borderWidth: 2
            }]
        },
        options: {
            responsive: true,
            scales: {
                x: {
                    type: 'time',
                    time: { unit: 'month' }
                }
            }
        }
    });
}

// Pie Chart for KPI Distribution
function drawPieChart(type) {
    const ctxPie = document.getElementById('pieChart').getContext('2d');
    const data = type === 'climate' ? {
        labels: ['Africa', 'Asia', 'Caribbean', 'Pacific'],
        datasets: [{
            data: [20, 15, 10, 5],
            backgroundColor: ['#FFD700', '#1E3A8A', '#3B82F6', '#F0F4FF']
        }]
    } : type === 'gdp' ? {
        labels: ['Africa', 'Asia', 'Caribbean', 'Pacific'],
        datasets: [{
            data: [2, 1, 1, 1],
            backgroundColor: ['#FFD700', '#1E3A8A', '#3B82F6', '#F0F4FF']
        }]
    } : {
        labels: ['Africa', 'Asia', 'Caribbean', 'Pacific'],
        datasets: [{
            data: [20, 15, 10, 5],
            backgroundColor: ['#FFD700', '#1E3A8A', '#3B82F6', '#F0F4FF']
        }]
    };

    new Chart(ctxPie, {
        type: 'pie',
        data: data,
        options: { responsive: true }
    });
}

// Heat Map for KPI Progress
function drawHeatMap() {
    const svg = d3.select('#heatMap').selectAll('*').remove();
    const svgElement = d3.select('#heatMap')
        .append('svg')
        .attr('width', 600)
        .attr('height', 400);

    const mockHeatMapData = commonwealthCountries.slice(0, 10).map(country => ({
        country,
        climateFinance: Math.random() * 50,
        nonTourismGDP: Math.random() * 5,
        digitalTransformation: Math.random() * 50
    }));

    const xScale = d3.scaleBand()
        .domain(mockHeatMapData.map(d => d.country))
        .range([0, 600])
        .padding(0.05);

    const yScale = d3.scaleBand()
        .domain(['Climate Finance', 'Non-Tourism GDP', 'Digital Transformation'])
        .range([0, 400])
        .padding(0.05);

    const colorScale = d3.scaleSequential(d3.interpolateBlues)
        .domain([0, 50]);

    svgElement.selectAll('rect')
        .data(mockHeatMapData.flatMap(d => [
            { country: d.country, metric: 'Climate Finance', value: d.climateFinance },
            { country: d.country, metric: 'Non-Tourism GDP', value: d.nonTourismGDP },
            { country: d.country, metric: 'Digital Transformation', value: d.digitalTransformation }
        ]))
        .enter()
        .append('rect')
        .attr('x', d => xScale(d.country))
        .attr('y', d => yScale(d.metric))
        .attr('width', xScale.bandwidth())
        .attr('height', yScale.bandwidth())
        .attr('fill', d => colorScale(d.value));

    svgElement.selectAll('text')
        .data(mockHeatMapData.flatMap(d => [
            { country: d.country, metric: 'Climate Finance', value: d.climateFinance },
            { country: d.country, metric: 'Non-Tourism GDP', value: d.nonTourismGDP },
            { country: d.country, metric: 'Digital Transformation', value: d.digitalTransformation }
        ]))
        .enter()
        .append('text')
        .attr('x', d => xScale(d.country) + xScale.bandwidth() / 2)
        .attr('y', d => yScale(d.metric) + yScale.bandwidth() / 2)
        .attr('text-anchor', 'middle')
        .attr('dy', '0.35em')
        .text(d => d.value.toFixed(1))
        .attr('fill', '#fff');
}

// Sankey Diagram
function drawSankeyDiagram(type) {
    d3.select('#sankeyDiagram').selectAll('*').remove();
    const svg = d3.select('#sankeyDiagram')
        .append('svg')
        .attr('width', 600)
        .attr('height', 400);

    const sankeyData = type === 'climate' ? {
        nodes: [{ name: 'Funding' }, { name: 'Projects' }, { name: 'Absorption' }],
        links: [{ source: 0, target: 1, value: 40 }, { source: 1, target: 2, value: 30 }]
    } : type === 'gdp' ? {
        nodes: [{ name: 'Investment' }, { name: 'Sectors' }, { name: 'Growth' }],
        links: [{ source: 0, target: 1, value: 25 }, { source: 1, target: 2, value: 15 }]
    } : {
        nodes: [{ name: 'Infrastructure' }, { name: 'Training' }, { name: 'Digitalization' }],
        links: [{ source: 0, target: 1, value: 35 }, { source: 1, target: 2, value: 20 }]
    };

    const sankey = d3.sankey()
        .nodeWidth(15)
        .nodePadding(10)
        .extent([[1, 1], [600 - 1, 400 - 6]]);

    const { nodes, links } = sankey(sankeyData);

    svg.append('g')
        .selectAll('rect')
        .data(nodes)
        .enter()
        .append('rect')
        .attr('x', d => d.x0)
        .attr('y', d => d.y0)
        .attr('height', d => d.y1 - d.y0)
        .attr('width', d => d.x1 - d.x0)
        .attr('fill', '#3B82F6');

    svg.append('g')
        .selectAll('path')
        .data(links)
        .enter()
        .append('path')
        .attr('d', d3.sankeyLinkHorizontal())
        .attr('stroke', '#FFD700')
        .attr('stroke-width', d => Math.max(1, d.width))
        .attr('fill', 'none')
        .attr('opacity', 0.5);

    svg.append('g')
        .selectAll('text')
        .data(nodes)
        .enter()
        .append('text')
        .attr('x', d => d.x0 - 6)
        .attr('y', d => (d.y1 + d.y0) / 2)
        .attr('dy', '0.35em')
        .attr('text-anchor', 'end')
        .text(d => d.name)
        .attr('fill', '#1E3A8A');
}

// Report Generation
function generateReport(type) {
    const reportOutput = document.getElementById('reportOutput');
    const chartType = document.getElementById('chartType').value;
    
    document.getElementById('ganttChart').style.display = 'none';
    document.getElementById('pieChart').style.display = 'none';
    document.getElementById('heatMap').style.display = 'none';
    document.getElementById('sankeyDiagram').style.display = 'none';

    let reportContent = '';
    switch (type) {
        case 'climate':
            reportContent = 'Climate Finance Report: 30% absorption achieved in 2025 (Smartsheet)';
            break;
        case 'gdp':
            reportContent = 'Non-Tourism GDP Report: 3% growth achieved in 2025 (Smartsheet)';
            break;
        case 'digital':
            reportContent = 'Digital Transformation Report: 30% progress in 2025 (Smartsheet)';
            break;
    }
    reportOutput.innerHTML = `<p>${reportContent}</p>`;

    if (chartType === 'gantt') {
        document.getElementById('ganttChart').style.display = 'block';
        drawGanttChart();
    } else if (chartType === 'pie') {
        document.getElementById('pieChart').style.display = 'block';
        drawPieChart(type);
    } else if (chartType === 'heatmap') {
        document.getElementById('heatMap').style.display = 'block';
        drawHeatMap();
    } else if (chartType === 'sankey') {
        document.getElementById('sankeyDiagram').style.display = 'block';
        drawSankeyDiagram(type);
    }
}

// Document Analysis
document.getElementById('documentUploadForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const fileInput = document.getElementById('documentInput');
    const file = fileInput.files[0];
    const documentAnalysis = document.getElementById('documentAnalysis');

    if (file) {
        const formData = new FormData();
        formData.append('document', file);

        fetch('analyze_document.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.error) {
                documentAnalysis.innerHTML = `<p>Error: ${data.error}</p>`;
            } else {
                documentAnalysis.innerHTML = `
                    <p>Document Analysis (Workamajig):</p>
                    <p>File: ${data.filename}</p>
                    <p>Climate Finance Mentions: ${data.climateFinanceMentions}</p>
                    <p>GDP Mentions: ${data.gdpMentions}</p>
                    <p>Digital Transformation Mentions: ${data.digitalMentions}</p>
                    <p>SDG Alignment: ${data.sdgAlignment}</p>
                `;
                drawPieChartWithDocumentData(data);
            }
        })
        .catch(error => {
            documentAnalysis.innerHTML = `<p>Error analyzing document: ${error.message}</p>`;
        });
    } else {
        documentAnalysis.innerHTML = '<p>Please select a file to analyze.</p>';
    }
});

// Pie Chart for Document Analysis
function drawPieChartWithDocumentData(data) {
    const ctxPie = document.getElementById('pieChart').getContext('2d');
    new Chart(ctxPie, {
        type: 'pie',
        data: {
            labels: ['Climate Finance', 'GDP', 'Digital Transformation'],
            datasets: [{
                data: [data.climateFinanceMentions, data.gdpMentions, data.digitalMentions],
                backgroundColor: ['#FFD700', '#3B82F6', '#1E3A8A']
            }]
        },
        options: { responsive: true }
    });
    document.getElementById('pieChart').style.display = 'block';
}

// Load Forum Posts
function loadForumPosts() {
    const forumPosts = document.getElementById('forumPosts');
    forumPosts.innerHTML = `
        <p>Post 1: Discussing climate finance strategies (15Five)</p>
        <p>Post 2: Digital transformation feedback (15Five)</p>
    `;
}

document.getElementById('forumPostForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('submit_post.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(data => {
        alert(data);
        loadForumPosts();
    });
});

// Workbox for offline caching
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        workbox.routing.registerRoute(
            /\.(?:html|css|js)$/,
            new workbox.strategies.StaleWhileRevalidate({ cacheName: 'static-resources' })
        );
        workbox.routing.registerRoute(
            /\.(?:png|jpg|jpeg|svg)$/,
            new workbox.strategies.CacheFirst({ cacheName: 'images' })
        );
        workbox.register();
    });
}

window.onload = loadForumPosts;